/* Set release version
 * See http://www.python-ldap.org/ for details.
 * $Id: version.h,v 1.4 2009/04/17 12:19:09 stroeder Exp $ */

#ifndef __h_version_
#define __h_version_


#include "common.h"
extern void LDAPinit_version( PyObject* d );

#endif /* __h_version_ */
