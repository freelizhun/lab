import nose
from htmloutput import HtmlOutput

if __name__ == '__main__':
        nose.main(addplugins=[HtmlOutput()])
