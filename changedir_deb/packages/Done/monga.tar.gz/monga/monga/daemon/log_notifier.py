from random import random
from time import time
from eventlet import sleep, Timeout
from swift.common.daemon import Daemon
from swift.common.utils import get_logger
from monga.common.utils import split_path
from paste.deploy import loadapp, appconfig
from monga.common.backend.mongo import MongoDBConnector    
from monga.common.pika_client import PikaClient
try:
    import simplejson as json
except ImportError:
    import json
    
class PathError(Exception):
    pass
    
class LogNotifier(Daemon):
    def __init__(self, conf):
        self.conf = conf
        self.logger = get_logger(conf, log_route = 'log-notifier')
        self.interval = int(conf.get('interval') or 3)
        self.mongo_path = conf.get('mongo_path', 'localhost')
        self.mongo_port = int(conf.get('mongo_port', 27017))
        self.db  = MongoDBConnector(self.mongo_path, self.mongo_port)
        self.handle_actions = ['CommitChunkUpload', 'FileCopy', 'FileMove',
                               'CreateFolder', 'FileDelete', 'UploadFile',
                               'Restore', 'CleanTenant']
        self.logger.info('Log-Notifier Start')
        self.pika   = PikaClient(self.logger, self.conf)
        self.notify_list = {}
        
    def remove_dlink(self, data, path):
        _links = self.db.find_dlink({'file_path' : path,
                                     'domain_id' : data['domain_id'],
                                     'tenant_id' : data['tenant_id'],
                                     'user_id'   : data['user_id']},
                                    multi = True)
        for _link in _links :
            self.db.delete_dlink(_link['_id'])
            
    def remove_shares(self, data, path):
        _shares = self.db.find_shared(data, 
                                      action = 'link', 
                                      path = path)
        for _share in _shares :
            if _share['link_path'].startswith(path):
                self.db.delete_shared(_share['_id'])
                               
    def basic_mode(self, data):
        #Get path from data
        res = self.check_shared_from_case(data)
        if not res :
            res = self.check_shared_to_case(data)
        if res :
            self.add_logs(data, res)
                               
    def CommitChunkUpload(self, data):
        self.logger.info('CommitChunkUpload')
        self.basic_mode(data)
        
    def CleanTenant(self, data):
        self.logger.info('CleantTenant')
        tenant_id = data['tenant_id']
        self.db.clean_records(tenant_id)
        self.db.update_log(data['_id'])
        
    def FileCopy(self, data):
        self.logger.info('FileCopy')
        self.basic_mode(data)
        
    def FileMove(self, data):
        self.logger.info('FileMove')
        self.basic_mode(data)
        #remove dlinks
        self.remove_dlink(data, data['from_path'])
        
    def CreateFolder(self, data):
        self.logger.info('CreateFolder')
        self.basic_mode(data)
        
    def FileDelete(self, data):
        self.logger.info('FileDelete')
        self.basic_mode(data)
        #remove dlinks
        self.remove_dlink(data, data['to_path'])
        self.remove_shares(data, data['to_path'])
    
    def UploadFile(self, data):
        self.logger.info('UploadFile')
        self.basic_mode(data)
        
    def Restore(self, data):
        self.logger.info('Restore')
        self.basic_mode(data)
        
    def find_action(self, action):
        if action in ['FileMove', 'FileCopy']:
            return 'UploadFile'
        else :
            return action
            
    def get_share_path(self, path):
        if not path.startswith('/'):
            path = '/' + path
        _path = path.split('/')
        try:
            _path.remove('')
        except ValueError:
            pass
        if len(_path) == 2:
            return '/' + _path[0], '/' + _path[1]
        elif len(_path) > 2:
            map_path = '/' + _path[0] + '/' +_path[1]
            del _path[0:2]
            new_path = '/' + '/'.join(_path)
            return map_path, new_path
        else :
            return None, None
        
    def add_logs(self, data, res):
        path = self.get_data_path(data)
        _res = None
        for _r in res:
            _res = _r
            _junk, _new_path = self.get_share_path(path)
            _path = _r['shared_path'] + unicode(_new_path)
            if not self.compare_to_source(data, _r) :
                #TODO
                _user = self.combine_user_info(_r, 'to')
                if not self.notify_list.get(_user['user_id'], None):
                    self.notify_list[_user['user_id']] = _user
                self.db.insert_log(_user, 
                                   self.find_action(data['action']),
                                   method   = data['method'],
                                   delta    = data['delta'],
                                   to_path  = _path,
                                   size     = data['file_size'],
                                   result   = True,
                                   is_share = True,
                                   notifier = True)
        if not self.compare_real_source(data, _res):
            #write log to origin source
            _path, _new_path = self.get_share_path(path)
            _share = self.db.find_shared(data, 'to', shared_path = _path,
                                         once = True, match = True)
            _user = self.combine_user_info(_r, 'link')
            if not self.notify_list.get(_user['user_id'], None):
                self.notify_list['user_id'] = _user
            self.db.insert_log(_user, 
                               self.find_action(data['action']),
                               method   = data['method'],
                               delta    = data['delta'],
                               to_path  = _share['link_path'] + _new_path,
                               size     = data['file_size'],
                               result   = True,
                               is_share = True,
                               notifier = True)
        
    def compare_real_source(self, src_one, src_two):
        if src_one['user_id'] == src_two['link_user_id'] and \
            src_one['tenant_id'] == src_two['link_tenant_id'] and \
            src_one['domain_id'] == src_two['link_domain_id'] :
            return True
        else:
            return False
            
    def compare_to_source(self, src_one, src_two):
        if src_one['user_id'] == src_two['to_user_id'] and \
            src_one['tenant_id'] == src_two['to_tenant_id'] and \
            src_one['domain_id'] == src_two['to_domain_id'] :
            return True
        else:
            return False
           
    def combine_user_info(self, src, _type = None):
        _str = ''
        if _type :
            _str = _type + '_'
        return {
            'user_id'     : src[ _str + 'user_id'     ],
            'user_name'   : src[ _str + 'user_name'   ],
            'tenant_id'   : src[ _str + 'tenant_id'   ],
            'tenant_name' : src[ _str + 'tenant_name' ],
            'domain_id'   : src[ _str + 'domain_id'   ],
            'domain_name' : src[ _str + 'domain_name' ],
        }
            
    def get_data_path(self, data):
        if data.get('to_path', None):
            return data['to_path']
        else:
            raise PathError()
    
    def check_shared_from_case(self, data):
        _path = split_path(data.get('to_path', None))
        _tmp = '/'
        for _p in _path:
            if _tmp == '/' :
                _tmp = _tmp + _p
            else :
                _tmp = _tmp + '/' + _p
            #Check share from other people
            _share = self.db.find_shared(data, 
                                         'to', 
                                         shared_path = _tmp, 
                                         once = True)
            if _share :
                return self.db.find_link_shared(_share)
        return None
        
    def check_shared_to_case(self, data):
        _path = split_path(data.get('to_path', None))
        _tmp = '/'
        _list = []
        for _p in _path:
            if _tmp == '/' :
                _tmp = _tmp + _p
            else :
                _tmp = _tmp + '/' + _p
            #Check share from other people
            _share = self.db.find_shared(data, 'from', path = _tmp, 
                                         once = True)
            if _share :
                return self.db.find_link_shared(_share)
        return None
                               
    def run_once(self, *args, **kwargs):
        lists = self.db.find_log({'notifier' : False}, limit = 5000)
        for _l in lists:
            if _l['action'] in self.handle_actions and _l['method'] != 'GET':
                #save into notify_list
                if not self.notify_list.get(_l['user_id'], None):
                    self.notify_list[_l['user_id']] = self.combine_user_info(_l)
                handler = getattr(self, _l['action'])
                try:
                    handler(_l)
                except PathError:
                    self.db.update_log(_l['_id'])
            self.db.update_log(_l['_id'])
        #notifiy by pika
        for _v in self.notify_list.itervalues() :
            self.pika.publish_msg(_v)
        self.notify_list = {}
    
    def run_forever(self, *args, **kwargs):
        sleep(random() * self.interval)
        while True:
            begin = time()
            try:
                self.run_once()
            except (Exception, Timeout):
                self.logger.exception(_('Unhandled exception'))
            elapsed = time() - begin
            if elapsed < self.interval:
                sleep(random() * (self.interval - elapsed))
