from random import random
from time import time
from eventlet import sleep, Timeout
from swift.common.daemon import Daemon
from swift.common.utils import get_logger
from paste.deploy import loadapp, appconfig
from monga.common.backend.mongo import MongoDBConnector  
try:
    import simplejson as json
except ImportError:
    import json
    
class ExpiredCleaner(Daemon):
    def __init__(self, conf):
        self.conf = conf
        self.logger = get_logger(conf, log_route = 'link-cleaner')
        self.interval = int(conf.get('interval') or 10)
        self.mongo_path = conf.get('mongo_path', 'localhost')
        self.mongo_port = int(conf.get('mongo_port', 27017))
        self.db  = MongoDBConnector(self.mongo_path, self.mongo_port)
        self.logger.info('Log-Cleaner Start')
                               
    def run_once(self, *args, **kwargs):
        query = {}
        query['expired_time'] = {'$lt' : int(round(time()))}
        #Clear expired links
        _links = self.db.find_dlink(query, multi = True)
        for _link in _links:
            self.db.delete_dlink(_link['_id'])
            self.logger.info('Clean Link Data ' + str(_link['_id']))
        #Clear expired locks
        _locks = self.db.find_expired_lock(query)
        for _lock in _locks:
            self.db.delete_expired_lock(_lock['_id'])
            self.logger.info('Clean Lock Data ' + str(_lock['_id']))
    
    def run_forever(self, *args, **kwargs):
        sleep(random() * self.interval)
        while True:
            begin = time()
            try:
                self.run_once()
            except (Exception, Timeout):
                self.logger.exception(_('Unhandled exception'))
            elapsed = time() - begin
            if elapsed < self.interval:
                sleep(random() * (self.interval - elapsed))
