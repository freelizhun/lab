from swift.common.utils import json, get_logger, split_path
from swift.common.swob import Request, Response
from swift.common.swob import HTTPBadRequest, HTTPMethodNotAllowed


class FakeUserMiddleware(object):

    def __init__(self, app, conf):
        self.app = app
        #self.logger = get_logger(conf, log_route='endpoints')

    def __call__(self, env, start_response):
        env['HTTP_X_DOMAIN_ID'] = 'domain_id'
        env['HTTP_X_DOMAIN_NAME'] = 'domain_name'
        env['HTTP_X_TENANT_ID'] = 'tenant_id'
        env['HTTP_X_TENANT_NAME'] = 'tenant_name'
        env['HTTP_X_USER_ID'] = 'user_id'
        env['HTTP_X_USER_NAME'] = 'user_name'
        '''
        env['HTTP_X_DOMAIN_ID'] = 'd1'
        env['HTTP_X_DOMAIN_NAME'] = 'd1'
        env['HTTP_X_TENANT_ID'] = 't1'
        env['HTTP_X_TENANT_NAME'] = 't1'
        env['HTTP_X_USER_ID'] = 'u1'
        env['HTTP_X_USER_NAME'] = 'u1'
        '''
        env['HTTP_X_ROLES'] = 'admin,member,guest'
        return self.app(env, start_response)

def filter_factory(global_conf, **local_conf):
    conf = global_conf.copy()
    conf.update(local_conf)

    def fakeuser_filter(app):
        return FakeUserMiddleware(app, conf)

    return fakeuser_filter
