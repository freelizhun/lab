from __future__ import with_statement
from swift.common.wsgi import WSGIContext
from swift.common.utils import json, get_logger, split_path, TRUE_VALUES
from swift.common.constraints import check_utf8
from swift.common.swob import Request, Response
from swift.common.swob import HTTPBadRequest, HTTPMethodNotAllowed, \
    HTTPPreconditionFailed
from monga.common.backend.mongo import MongoDBConnector
from monga.fileop.FileOp import FileOp
from monga.controller.base import Controller
from monga.common.utils import json_dump
import urllib
import time
import json

class DirectLinkMiddleware(WSGIContext, Controller):

    def __init__(self, app, conf):
        self.app = app
        self.conf = conf
        self.logger = get_logger(conf, log_route = 'DirectLink')
        self.logger.info('DirectLink Middleware Start')
        self.mongo_path = conf.get('mongo_path', 'localhost')
        self.mongo_port = int(conf.get('mongo_port', 27017))
        self.db  = MongoDBConnector(self.mongo_path, self.mongo_port)
        self.fileop = FileOp
        WSGIContext.__init__(self, app)
        
    def _check_utf8(self, req):
        try:
            if not check_utf8(req.path_info):
                self.logger.increment('errors')
                return HTTPPreconditionFailed(request=req,
                                              body='Invalid UTF8')
        except UnicodeError:
            self.logger.increment('errors')
            return HTTPPreconditionFailed(request=req, 
                                          body='Invalid UTF8')
        return None

    def __call__(self, env, start_response):
        req = Request(env)
        if req.path.startswith('/v1/links/') and req.method == 'GET':
            _check_utf8 = self._check_utf8(req)
            if _check_utf8 :
                return _check_utf8(env, start_response)
            #Split path
            _spath = split_path(req.path, 1, 4, True)
            _match_url = '/' + '/'.join(_spath[0:3])
            #Direct link
            pwd = req.headers.get('X-Public-Password', None)
            _link = self.db.find_dlink({'pwd' : pwd, 
                                        'match_url' : _match_url})
            if not _link:
                return self.app(env, start_response)
            fp = self.fileop(self.logger, self.conf)
            #real file path
            if _spath[3] :
                _real_path = _link['file_path'] + '/' + \
                             urllib.unquote(_spath[3]).decode('utf-8')
            else:
                _real_path = _link['file_path']
            _user, _path, is_share = self.check_shared(_link, _real_path)
            #Check path is folder or file
            _resp = fp.get_meta(_user, _path, req)
            if not self.get_result(_resp.status):
                return _resp(env, start_response)
            else : 
                _body = json.loads(_resp.body)
                if _body['is_dir'] :
                    #Modified path to link path
                    _body['path'] = _body['path'].replace(
                        _link['file_path'], _link['public_url'])
                    _new_content = []
                    for _content in _body['contents'] :
                        _content['path'] = _content['path'].replace(
                        _link['file_path'], _link['public_url'])
                        _new_content.append(_content)
                    _body['contents'] = _new_content
                    _resp.body = json_dump(_body)
                    self.db.insert_log(_user, 
                                       'DriectLinkListFiles',
                                       to_path  = _spath[3],
                                       result   = self.get_result(_resp.status),
                                       is_share = is_share)
                    return _resp(env, start_response)
            resp = fp.downloadData(_user, _path, req)
            _user['client_ip'] = env.get('REMOTE_ADDR', '')
            _user['device_name'] = env.get('HTTP_USER_AGENT', '')
            self.db.insert_log(_user, 
                               'DriectLinkDownloadFile',
                               to_path  = _link['public_url'],
                               size     = resp.headers.get('Content-Length', 0),
                               result   = self.get_result(resp.status),
                               is_share = is_share)
            return resp(env, start_response)
        return self.app(env, start_response)

def filter_factory(global_conf, **local_conf):
    conf = global_conf.copy()
    conf.update(local_conf)
    def directlink_filter(app):
        return DirectLinkMiddleware(app, conf)
    return directlink_filter
