from __future__ import with_statement
import time
import os, uuid, errno
import tempfile
from swift.common.swob import Request
from swift.common.utils import (get_logger, TRUE_VALUES)
from urllib import unquote, quote
from webob.exc import HTTPAccepted, HTTPBadRequest, HTTPConflict, \
    HTTPCreated, HTTPInternalServerError, HTTPNoContent, \
    HTTPNotFound, HTTPPreconditionFailed, HTTPMethodNotAllowed
from shutil import rmtree
from monga.common.ks_client import KeystoneClient

class Quota(object):
    def __init__(self, app, conf):
        self.app = app
        self.auth_url = conf.get('auth_url',
                                 'http://localhost:35357/v3/')
        self.auth_token = conf.get('auth_admin_token', 'ADMIN')
        self.default_quota = int(conf.get('default_quota', 5368709120))
        self.cache_timeout = int(conf.get('cache_timeout', 3600))
        self.ks = KeystoneClient(self.auth_url, self.auth_token)
        self.logger = get_logger(conf, log_route = 'GetTenantQuota')

    def __call__(self, env, start_response):
        req = Request(env)
        _cache = req.environ.get('swift.cache', None)
        tenant_id = req.headers['X-Project-Id']
        if _cache:
            _key = 'quota_' + tenant_id
            quota = _cache.get(_key)
            if not quota :
                quota = self.ks.get_tenant(tenant_id).get('quota',
                                                          self.default_quota)
                _cache.set(_key, quota, timeout = self.cache_timeout)
        else:
            quota = self.ks.get_tenant(tenant_id).get('quota',
                                                      self.default_quota)
        #Set quota in env
        env['HTTP_X_TENANT_QUOTA'] = quota
        return self.app(env, start_response)

def filter_factory(global_conf, **local_conf):
    conf = global_conf.copy()
    conf.update(local_conf)
    def exten_filter(app):
        return Quota(app, conf)
    return exten_filter
