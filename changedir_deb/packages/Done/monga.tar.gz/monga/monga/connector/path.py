# -*- coding: UTF-8 -*-
import os
from monga.connector.exception import InvalidParameter

MONGA_SYSTEM_LIBS={
'folder':'system',
'binary':'binary',
'tmp':'tmp',
'commit_helper_folder':'/tmp/monga/commit_bash_helper',
}

MONGA_TENANT_LIBS={
'home':'home',
'version':'version',
'trash':'trash',
'trash_version':'version',
}

class MongaSystemPath(object):

    @classmethod
    def get_system_commit_helper_folder(cls):
            return MONGA_SYSTEM_LIBS['commit_helper_folder']
    
    @classmethod
    def path_to_temp(cls, 
           access_point, tenant_id, temp_uuid=None):
        if not tenant_id or not access_point:
            raise InvalidParameter

        if temp_uuid is not None:
            return os.path.join(
                access_point,
                MONGA_SYSTEM_LIBS['folder'],
                tenant_id,
                MONGA_SYSTEM_LIBS['tmp'],
                temp_uuid
                )
        return os.path.join(
                access_point,
                MONGA_SYSTEM_LIBS['folder'],
                tenant_id,
                MONGA_SYSTEM_LIBS['tmp']
                )

    @classmethod
    def path_to_binary_folder(cls, access_point):
        if not access_point : raise InvalidParameter
        return os.path.join(
                access_point,
                MONGA_SYSTEM_LIBS['binary']
                )

    @classmethod
    def path_to_chunk(cls, access_point, chunk_id):
        if not access_point or not chunk_id: raise InvalidParameter
        return os.path.join(
                cls.path_to_binary_folder(access_point),
                chunk_id
                )

    @classmethod
    def get_system_relative_path(cls, 
            access_point, access_path):
        if not access_point or not access_path:
            raise InvalidParameter
        return u'/{0}'.format(unicode('/'.join(os.path.relpath(
            access_path,access_point).split('/')[2:])))

    @classmethod
    def path_to_tenant(cls, access_point, tenant_id):
        if not access_point or not tenant_id:
            raise InvalidParameter
        return os.path.join(access_point,tenant_id)

class MongaTenantPath(object):
    
    @classmethod
    def path_to_version_folder(cls, 
            access_point, tenant_id, file_path=None):
        if not access_point or not tenant_id :
            raise InvalidParameter
        return os.path.join(access_point, 
                tenant_id, MONGA_TENANT_LIBS['version'], 
                file_path
                )

    @classmethod
    def path_to_home_folder(cls, access_point, tenant_id):
        if not access_point or not tenant_id:
            raise InvalidParameter
        return os.path.join(access_point, 
                tenant_id, MONGA_TENANT_LIBS['home']
                )

    @classmethod
    def path_to_trash_folder(cls, access_point, tenant_id):
        if not access_point or not tenant_id:
            raise InvalidParameter
        return os.path.join(access_point, 
                tenant_id, MONGA_TENANT_LIBS['trash']
                )
    
    @classmethod
    def path_to_trash_version_folder(cls, access_point, tenant_id, path):
        if not access_point or not tenant_id or not path:
            raise InvalidParameter
        return os.path.join(access_point, 
                tenant_id, MONGA_TENANT_LIBS['trash'], 
                MONGA_TENANT_LIBS['trash_version'], path
                )
