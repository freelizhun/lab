# vim: tabstop=4 shiftwidth=4 softtabstop=4
# -*- coding: UTF-8 -*-
"""
Base Drivers for File Backend Storage 
$MOUNT_POINT
------------
    |-$BINARY
    ------------
        |-FDJKASSSSK3
        |-FDJKASSSSK3.count 
            ^-- add one line while one more file reference to this binary
                $echo ' '>>kkkk.count
                $wc -l kkkk.count
                1 kkkk.count
                $sed -i '$d' kkkk.count
                $wc -l kkkk.count
                0 kkkk.count
    |-$TENANT_ID
    ------------
        |-$VERSION
        ----------
            |-FOO
            ------
                |-BAR.txt
                ----------
                    |$VERSION_1
                    |$VERSION_2
            |-A.txt
            -------
                |-A.txt.12321
                |-A.txt.43434
        |-$HOME
        --------
            |-FOO
            ------
                |--BAR.txt <- metadata
            |-A.txt <- metadata
        |-$TRASH
        ---------
            |-$UUID <- Metadata of latest version
            |-$VERSION
            ----------
                |-$UUID
                -------
                    |-VERSION1
                    |-VERSION2

    |-$SYSTEM
    ----------
        |-$TENANT_ID
        ------------
            |-$TMP
CONF file
[backend]
type = nfs
share_path = 127.0.0.1:/nfs/share
access_point = /opt/monga
"""

import os
import gettext
import shutil
from monga.connector.path import MongaSystemPath as SPath
from monga.connector.path import MongaTenantPath as TPath
from monga.connector import utils
from monga.connector.exception import ProcessExecutionError
from monga.common.exception import FileNotFoundError as FileNotFound
from monga.common.exception import FileExistError as FileExists
from monga.common.exception import InvalidParameter
from monga.common.exception import StorageError
import inspect

gettext.install('connector', unicode=1)

class FileBackendBaseDriver(object):
    '''
    Base Driver for file based , LVM, NFS and etc, backend storage.
    '''
    def __init__(self, conf, logger, *args, **kwargs):
        self._logger = logger
        if not logger:
            self._logger.debug(_('Invalid Input for base.__init__'))
            raise InvalidParameter('INIT') 
        self._execute = utils.execute
        self._mount_path = unicode(conf.get('storage_mount_path','/tmp/monga'))
        self._access_point = unicode(conf.get('storage_access_point','/opt/monga'))
        self._access_folder = unicode(os.path.join(self._mount_path,'MongaStorage'))
        self._max_number_of_version = 5 

    def get_metadata(self, tenant_id, path='.', file_version=None, is_list=False):
        """
        Return eturn  metadata of file or folder
        
        :param tenant_id : Tenant ID
        :param path : System relative file path w/o tenant_id
        :param file_version : Particular version's metadata
        :param is_list : List all file/folder metadata under the path
        """
        #self._logger.debug('Enter base.get_metadata')
        if not tenant_id or not path:
            self._logger.debug(_('Invalid Input for base.get_metadata'))
            raise InvalidParameter('GET METADATA')
        tenant_id = unicode(tenant_id)
        path = unicode(path)
        path = unicode(self._get_normalize_path(path))
        #tenant_home = TPath.path_to_home_folder(
        #                self._access_point,tenant_id)
        access_path = os.path.join(
                        TPath.path_to_home_folder(
                                self._access_point,tenant_id)
                        ,path)
        self._check_path_exists(access_path)
        if os.path.isfile(access_path):
            if file_version is not None:
                path_to_version = TPath.path_to_version_folder(
                            self._access_point, tenant_id, path)
                access_path = os.path.join(path_to_version,file_version)
                self._check_path_exists(access_path)
            return self._get_file_metadata(access_path)
        return self._get_folder_metadata(access_path,is_list)

    def upload(self, tenant_id, temp_uuid, data, chunk_name):
        """
        Upload a chunk of file to Monga

        :param tenant_id : Tenant ID
        :param temp_uuid : A UUID to indicate a temp folder to store chunks.
        :param data : The binary data of chunk
        :param chunk_name : The chunk name.
        """
        #self._logger.debug('Enter base.upload')
        #1) save data to 
        #    $ACCESS_POINT/$SYSTEM/$TENANT_ID/$TMP/$TEMP_UUID/#CHUNK_NAME
        #2) add chuck to manifest list in metadata file, 
        #   Named after uuid.
        #Creates a temped file metadata.
        #At this point, we only need to record the manifest
        #{
        #    "manifest":[
        #        ,klsdfdwee
        #    ]},
        if not tenant_id or not temp_uuid or not chunk_name: 
            #or not data or not chunk_name:
            self._logger.debug(_('Invalid Input for base.upload'))
            raise InvalidParameter('UPLOAD')
        tenant_id = unicode(tenant_id)
        temp_uuid = unicode(temp_uuid)

        #$SYSTEM/$T_ID/%TMP
        path_to_temp = SPath.path_to_temp(
                    self._access_point, tenant_id, temp_uuid)

        if not self._path_exists(path_to_temp):
            self._create_folder(path_to_temp)
            #self._execute(self._logger, 'mkdir', '-p', path_to_temp)

        path_to_data = os.path.join(path_to_temp, chunk_name)
        try:
            with open(unicode(path_to_data), 'wb') as fd:
                utils.write_data(data, fd)
                #fd.write(data)
                #os.fdatasync(fd)
        except Exception as e:
            self._logger.debug(_(
                'Unable to to write data chunk, {0}'.format(path_to_data)))
            self._logger.debug(_(e))
            raise StorageError(e)
                
        path_to_metadata = os.path.join(path_to_temp, temp_uuid)
        if self._path_exists(path_to_metadata):
            # Read data first
            # Otherwise, open file in write mode will erase the file
            try:
                with open(unicode(path_to_metadata), 'r') as fd:
                    metadata = utils.read_metadata(fd)
            except Exception as e:
                self._logger.debug(_('Unable to read metadata ${0}'.format(
                            path_to_temp_metadata)))
                raise StorageError(e)
            metadata['manifest'].append(unicode(chunk_name))
            try:
                with open(unicode(path_to_metadata), 'w') as fd:
                    utils.write_metadata(metadata, fd)
            except Exception as e:
                self._logger.debug(_('Unable to write metadata: ${0}'.format(
                            os.path.join(path_to_home,save_path))))
                raise StorageError(e)
        else:
            # The first chunk for this file
            metadata = {'manifest':[unicode(chunk_name)]}
            try:
                with open(unicode(path_to_metadata), 'w') as fd:
                    utils.write_metadata(metadata, fd)
            except Exception as e:
                self._logger.debug(_('Unable to write metadata: ${0}'.format(
                            os.path.join(path_to_home,save_path))))
                raise StorageError(e)

    def list_uncommited_upload(self, tenant_id, temp_uuid):
        """
        List uncommited upload
        Return a list of chunk file size
        :param tenant_id : Tenant ID
        :param temp_uuid : A UUID to indicate a temp folder to store chunks.
        """
        if not tenant_id or not temp_uuid : 
            self._logger.debug(_('Invalid Input for base.upload'))
            raise InvalidParameter('LIST UNCOMMITED UPLOAD')
        tenant_id = unicode(tenant_id)
        temp_uuid = unicode(temp_uuid)

        #$SYSTEM/$T_ID/%TMP
        path_to_temp = SPath.path_to_temp(
                    self._access_point, tenant_id, temp_uuid)
        path_to_metadata = os.path.join(path_to_temp, temp_uuid)
        self._check_path_exists(path_to_temp, path_to_metadata)
        ret = []
        try:
            with open(path_to_metadata, 'r') as fd:
                meta = utils.read_metadata(fd)
            for chunk in meta['manifest']:
                ret.append(os.path.getsize(os.path.join(path_to_temp,chunk)))
        except Exception as e:
            raise StorageError(e)
        return ret
    
    def delete_uncommited_upload(self, tenant_id, temp_uuid):
        """
        Delete uncommited upload

        :param tenant_id : Tenant ID
        :param temp_uuid : A UUID to indicate a temp folder to store chunks.
        """
        if not tenant_id or not temp_uuid : 
            self._logger.debug(_('Invalid Input for base.upload'))
            raise InvalidParameter('UPLOAD')
        tenant_id = unicode(tenant_id)
        temp_uuid = unicode(temp_uuid)

        #$SYSTEM/$T_ID/%TMP
        path_to_temp = SPath.path_to_temp(
                    self._access_point, tenant_id, temp_uuid)
        self._check_path_exists(path_to_temp)
        self._delete(path_to_temp)

    def check_upload(self, tenant_id, temp_uuid ):
        """
        Upload a chunk of file to Monga
        Return current metadata
        :param tenant_id : Tenant ID
        :param temp_uuid : A UUID to indicate a temp folder to store chunks.
        """
        if not tenant_id or not temp_uuid : 
            self._logger.debug(_('Invalid Input for base.check_upload'))
            raise InvalidParameter('CHECK UPLOAD')
        tenant_id = unicode(tenant_id)
        temp_uuid = unicode(temp_uuid)
        #$SYSTEM/$T_ID/%TMP
        path_to_temp = SPath.path_to_temp(
                    self._access_point, tenant_id, temp_uuid)
        path_to_metadata = os.path.join(path_to_temp, temp_uuid)
        self._check_path_exists(path_to_temp, path_to_metadata)
        try:
            with open(unicode(path_to_metadata), 'r') as fd:
                return utils.read_metadata(fd)['manifest']
        except Exception as e:
            self._logger.debug(_('Unable to read metadata ${0}'.format(
                        path_to_metadata)))
            raise StorageError(e)

    def check_upload_temp_exists(self, tenant_id, hash_id):
        """
        Return True if someonce else is uploading same file

        :param tenant_id : Tenant ID
        :param hash_id : HASH(save_path)-
        """
        if not tenant_id or not hash_id :
            self._logger.debug(_('Invalid Input for base.check_upload_temp_exists'))
            raise InvalidParameter('CHECK UPLOAD TEMP EXISTS')
        tenant_id = unicode(tenant_id)
        hash_id = unicode(hash_id)

        #$SYSTEM/$T_ID/%TMP
        path_to_temp = SPath.path_to_temp(
                    self._access_point, tenant_id)
        if not self._path_exists(path_to_temp): 
            return False
        else:
            for f in os.listdir(path_to_temp):
                if f == hash_id: return True
        #if self._search_by_name(path_to_temp, '{0}'.format(hash_id)):
        #    return True 
        return False

    def commit(self, tenant_id, save_path, temp_uuid, 
            file_size, store_size, mtime=None, compress=False, encrypt=False):
        """
        Commit an upload operation. 
        Return metadata of the file.
        :param tenant_id : Tenant ID.
        :param save_path : Path to save the file's metadata
        :param temp_uuid : A UUID used to indicate the temp 
                            folder stored chunks relative to the file.
        :param file_size : Size of file in Bytes.
        :param store_size : Stored Size in Bytes. 
                            It may diff from file_size due to compression.
        :param compress : TRUE if file compressed.
        :param encrypt : TRUE if file encrypted.
        """
        #self._logger.debug('Enter base.commit')
        #*) Create file's metadate , 
        #    generate version number,
        #    and store it to save_path and %VERSIONING
        #if os.path.isabs(save_path) :
            # Remove the first slash
            # Otherwise os.path.join cannot point to right position
        #    save_path = save_path[1:] 
        # $SYSTEM/$T_ID/%TMP
        if not tenant_id or not save_path or not temp_uuid : 
            #or not file_size or not store_size:
            self._logger.debug(_('Invalid Input for base.commit'))
            raise InvalidParameter('COMMIT')
        tenant_id = unicode(tenant_id)
        save_path = unicode(save_path)
        save_path = unicode(self._get_normalize_path(save_path))
        path_to_temp = SPath.path_to_temp(
                            self._access_point,
                            tenant_id, temp_uuid)
        
        # $BINARY/
        path_to_bin = SPath.path_to_binary_folder(self._access_point)
        
        # /tmp/...
        #path_to_commit_helper = self._gen_commit_bash_helper(
        #                path_to_temp, path_to_bin, temp_uuid)
        # $SYSTEM/$T_ID/%TMP/$UUID
        path_to_temp_metadata = os.path.join(path_to_temp, temp_uuid)
        metadata = {}
        
        # Get temp metadata
        try:
            with open(unicode(path_to_temp_metadata), 'r') as fd:
                temp_meta = utils.read_metadata(fd)
        except Exception as e:
            self._logger.debug(_('Unable to read metadata ${0}'.format( 
                        path_to_temp_metadata)))
            raise StorageError(e)

        # Create metadata
        metadata = utils.create_file_metadata(
            save_path, temp_meta, temp_uuid, file_size, store_size, mtime,
            compress, encrypt)
        # Check Version
        path_to_version = TPath.\
                        path_to_version_folder(self._access_point,
                            tenant_id, save_path)
        path_to_home = TPath.\
                        path_to_home_folder(self._access_point,
                            tenant_id)
        if not self._path_exists(path_to_home):
            # The First Upload
            # create home folder for this tenant
            self._create_folder(path_to_home)

        if not self._path_exists(path_to_version):
            # The First version
            # create version folder for this file
            self._create_folder(path_to_version)
            # write metadata to save path
            # cp current version metadata to versioning folder
            # and append version to file name
        # if path contains subfolder which is not created, 
        # For now, we will create it.
        if not self._path_exists(os.path.join(
                path_to_home,os.path.dirname(save_path))):
            self._create_folder(os.path.join(
                            path_to_home,os.path.dirname(save_path)))
        try:
            with open(unicode(os.path.join(path_to_home,save_path)),'w') as fd:
                utils.write_metadata(metadata,fd)
            #self._copy(os.path.join(path_to_home,save_path),
            #            os.path.join(path_to_version, metadata['rev']))
            with open(unicode(os.path.join(path_to_version, 
                                metadata['rev'])),'w') as fd:
                utils.write_metadata(metadata,fd)
        except Exception as e:
            self._logger.debug(_('Unable to write metadata: ${0}'.format( 
                        os.path.join(path_to_home,save_path))))
            raise StorageError(e)
        
        # Delete temp metadata before running the helper
        #self._delete(path_to_temp_metadata)
        # run commit bash helper
        self._commit_helper(unicode(os.path.join(
                                path_to_home,save_path,metadata['rev'])), 
                            path_to_temp, temp_uuid)
        #self._gen_commit_bash_helper(
        #          path_to_temp, path_to_bin, temp_uuid)

        #self._execute(self._logger, path_to_commit_helper)
        # Check number of version
#        versions = self._get_list_sorted_by_mtime(path_to_version)
#        while versions.__len__() > self._max_number_of_version :
#            version = versions.pop()
#            # Get manifest
#            meta = self._get_file_metadata(
#                os.path.join(path_to_version, version))
#            for chunk in meta['manifest']:
#                self._decrease_binary_usage(chunk)
#                if int(self._get_binary_usage(chunk)) == 0:
#                    # chunk is not refered by any chunk
#                    # we can delete it.
#                    path_to_chunk = self._get_path_to_chunk(chunk)
#                    #path_to_chunk = os.path.join(
#                    #    path_to_bin, chunk)
#                    self._delete(path_to_chunk)
#                    self._delete('{0}.{1}'.format(path_to_chunk,'count'))
#            # Delete Version
#            self._delete(os.path.join(path_to_version, version))
#        # Delete tmp
#        self._delete(path_to_temp)
        # Remove commit bash helper file
        #self._delete(path_to_commit_helper)
        # Return Metadata
        return self._assign_path_metadata(
                metadata, os.path.join(path_to_home,save_path), 
                is_version=False) 

    def move(self, src_path, dest_path, src_tenant_id, 
                is_copy=False, dest_tenant_id=None):
        '''
        Move/Rename a folder/file
        Return metadata
        :param src_path : System relative Path to source file/folder.
        :param dest_path : System relative Path to dest file/folder.
        :param src_tenant_id : Tenant ID for src file/folder.
        :param dest_tenant_id : Tenant ID for dest file/folder.
        :param is_copy : TRUE if it is a copy operation.
        '''
        # *) mv src_path dest_path
        # *) mv $VERSIONING/src_path $VERSIONING/dest_path
        #self._logger.debug('Enter base.move')
        if not src_path or not dest_path or not src_tenant_id:
            raise InvalidParameter('MOVE')
        src_path = unicode(src_path)
        dest_path = unicode(dest_path)
        src_tenant_id = unicode(src_tenant_id)
        # If folder/file exist in DEST
        # will raise Forbidden error.
        src_path = self._get_normalize_path(src_path)
        dest_path = self._get_normalize_path(dest_path)
        path_to_src_home = TPath.path_to_home_folder(
                            self._access_point,src_tenant_id)
        # Version
        path_to_src_version = TPath.path_to_version_folder(
                                self._access_point,
                                src_tenant_id, src_path)
        if dest_tenant_id is not None:
            path_to_dest_home = TPath.path_to_home_folder(
                                self._access_point,
                                dest_tenant_id)
            path_to_dest_version = TPath.path_to_version_folder(
                                    self._access_point,
                                    dest_tenant_id, dest_path)
        else:
            dest_tenant_id = src_tenant_id
            path_to_dest_home = path_to_src_home
            path_to_dest_version = TPath.path_to_version_folder(
                                    self._access_point,
                                    src_tenant_id, dest_path)
        if not is_copy:
            self._move(src=os.path.join(path_to_src_home, src_path),
                       dest=os.path.join(path_to_dest_home, dest_path))
            self._move(src=path_to_src_version,
                       dest=path_to_dest_version)
        else :
            self._copy(src=os.path.join(path_to_src_home, src_path),
                       dest=os.path.join(path_to_dest_home, dest_path))
            self._copy(src=path_to_src_version,
                       dest=path_to_dest_version)
        # TODO : Check # of version
        return self.get_metadata(dest_tenant_id, dest_path)

    def delete(self, tenant_id, path):
        ''' 
        Remove a file/folder
        Return metadata
        :param tenant_id : Tenant ID.
        :param path : System relative path to file/folder
        '''
        #remove all releated data
        #    a) metadata
        #    b) binary if not used by others
        if not tenant_id or not path:
            raise InvalidParameter('DELETE')
        tenant_id = unicode(tenant_id)
        path = unicode(path)
        path = self._get_normalize_path(path)
        path_to_home = TPath.path_to_home_folder(
                        self._access_point, tenant_id)
        path_to_version = TPath.path_to_version_folder(
                        self._access_point, tenant_id, path)
        access_path = os.path.join(path_to_home, path)
        self._check_path_exists(path_to_home, path_to_version, access_path)
        if os.path.isfile(access_path):
            meta = self._get_file_metadata(access_path)
        else :
            meta = self._get_folder_metadata(access_path,is_list=True)
        # Delete file/folder 
        self._delete(access_path)
        self._delete_versions(path_to_version)
        return meta

    def get_version_metadata(self, tenant_id, path):
        '''
        GET metadata of the file
        Return metadata
        :param tenant_id : Tenant ID.
        :param path : System relative path to file
        '''
        #self._logger.debug("Enter base.get_version_metadata")
        if not tenant_id or not path: 
            raise InvalidParameter('GET VERSION METADATA')
        tenant_id = unicode(tenant_id)
        path = unicode(path)
        path = self._get_normalize_path(path)
        path_to_version = TPath.path_to_version_folder(
                            self._access_point,
                            tenant_id, path)
        self._check_path_exists(path_to_version)
        contents = []
        for c in self._get_list_sorted_by_mtime(path_to_version) \
                        [:self._max_number_of_version]:
            p = os.path.join(path_to_version,c)
            contents.append(self._get_file_metadata(p))
        return contents

    def search(self, tenant_id, search_path, keyword):
        '''
        Search file by name.
        Return match files' metadata
        :param tenant_id : Tenant ID.
        :param search_path : System relative path
        :param keyword : File name
        '''
        #self._logger.debug("Enter base.search")
        if not tenant_id or not search_path or not keyword:
            raise InvalidParameter('SEARCH')
        tenant_id = unicode(tenant_id)
        search_path = unicode(self._get_normalize_path(search_path))
        keyword = unicode(keyword)
        path = os.path.join(
            TPath.path_to_home_folder(self._access_point, tenant_id), 
            search_path)
        self._check_path_exists(path)
        results = self._search_by_name(path, keyword)
        ret = []
        for res in results:
            res = res.decode('utf-8')
            if os.path.isfile(res):
                ret.append(self._get_file_metadata(res))
            else:
                ret.append(self._get_folder_metadata(res))
        return ret

    def create_folder(self, tenant_id, folder_path):
        '''
        Create a folder
        Return metadata
        :param tenant_id : Tenant ID.
        :param folder_path : System relative path
        '''
        if not tenant_id or not folder_path:
            raise InvalidParameter('CREATE FOLDER')
        tenant_id = unicode(tenant_id)
        folder_path = unicode(self._get_normalize_path(folder_path)) or u'/'
        path_to_folder = os.path.join(
                TPath.path_to_home_folder(self._access_point, tenant_id)
                , folder_path)

        path_to_version = TPath.path_to_version_folder(
                self._access_point, tenant_id, folder_path)

        if self._path_exists(path_to_folder):
            self._logger.debug(_('Try to create an exist folder at {0}'.\
                            format(path_to_folder)))
            raise FileExists()
        self._create_folder(path_to_folder)
        self._create_folder(path_to_version)
        return self._get_folder_metadata(path_to_folder)
    
    def trash(self, tenant_id, path):
        '''
        Move file and its version to trash can.
        Return metadata
        :param tenant_id : Tenant ID
        :param path : path to file
        '''
        if not tenant_id or not path:
            raise InvalidParameter('TRASH')
        tenant_id = unicode(tenant_id)
        path = unicode(self._get_normalize_path(path))
        src = os.path.join(
                TPath.path_to_home_folder(
                        self._access_point, tenant_id)
                , path)
        self._check_path_exists(src)
        meta = self.get_metadata(tenant_id, path)
        # save meta data to /path/to/trash/$REV
        path_to_trash = TPath.path_to_trash_folder(
                    self._access_point, tenant_id)
        if not self._path_exists(path_to_trash):
            self._create_folder(path_to_trash)
        path_to_trash_meta = os.path.join(path_to_trash, meta['rev'])
        if self._path_exists(path_to_trash_meta):
            self._logger.debug(
                _('REV conflict. There are two file with same rev, md5(ctime)')
                )
            raise FileExists(
                _('REV conflict. There are two file with same rev'))
        try:
            with open(unicode(path_to_trash_meta), 'w') as fd:
                utils.write_metadata(meta,fd)
        except Exception as e:
            self._logger.debug(_('Unable to write metadata'))
            self._logger.debug(e)
            raise StorageError(e)
        # move version to /path/to/trash/version/$REV/
        path_to_version = TPath.path_to_version_folder(
                self._access_point, tenant_id, path)
        path_to_trash_version = TPath.path_to_trash_version_folder(
                self._access_point, tenant_id, meta['rev'])
        self._move(path_to_version, path_to_trash_version)
        # delete version
        self._delete(path_to_version)
        # delete file
        self._delete(src)
        # return metadata
        return meta

    def trash_list(self, tenant_id):pass
    def trash_restore(self, tenant_id, path):pass

    def download(self, tenant_id, chunk_id):
        '''
        Download a chunk
        Return Chunk
        :param tenant_id : Tenant ID
        :param chunk_id : Chunk ID
        '''
        if not tenant_id or not chunk_id:
            raise InvalidParameter('DOWNLOAD')
        #self._logger.debug("Enter base.ownload")
        chunk_id = unicode(chunk_id)
        access_path = unicode(self._get_path_to_chunk(chunk_id))
        self._check_path_exists(access_path)
        return self._get_chunk(access_path)

    def restore(self, tenant_id, path, rev):
        '''
        Restore to previsous version
        Return metadata
        :param tenant_id : Tenant ID.
        :param path : Path to file
        :param rev : The revision of the file to restore
        '''
        if not tenant_id or not path or not rev:
            raise InvalidParameter('CREATE FOLDER')
        path = self._get_normalize_path(path)
        path_to_version = os.path.join(TPath.path_to_version_folder(
                            self._access_point, tenant_id, path), rev)
        path_to_home = TPath.path_to_home_folder(
                            self._access_point, tenant_id)
        path_to_file = os.path.join(path_to_home,path)
        self._check_path_exists(path_to_version, path_to_file)
        # Copy rev to path
        self._copy(path_to_version, path_to_file, overwrite=True)
        # Touch $VERSION/rev
        self._touch_file(path_to_version)
        # Return metadata
        return self._get_file_metadata(path_to_file)

    def delete_tenant(self, tenant_id):
        '''
        Delete Tenant Home and Version folder
        Return True if successed
        :param tenant_id : Tenant ID
        '''
        if not tenant_id :
            raise InvalidParameter('DELETE TENANT')
        path = SPath.path_to_tenant(
                            self._access_point, tenant_id)
       
        self._check_path_exists(path)
        self._delete(path)
        return True

    def _init_system_folder(self):
        '''
        Creating system folders
        '''
        #self._logger.debug("Enter base._init_system_folder")
        if not self._path_exists(self._access_folder):
            self._create_folder(self._access_folder)
            #self._execute(self._logger, 'mkdir', '-p', access_folder)
        # Create a softlink from access_point to access_folder
        #if self._path_exists(self._access_point):
        #    self._execute(self._logger, 'rm', self._access_point)
        #else:
        if not self._path_exists(os.path.dirname(self._access_point)):
            self._create_folder(os.path.dirname(self._access_point))
            #self._execute(self._logger,'mkdir', '-p',
            #            os.path.dirname(self._access_point))
        #self._delete(self._access_point)
        if not self._path_exists(self._access_point):
            os.symlink(self._access_folder, self._access_point)
            #self._execute(self._logger, 'ln', '-s', access_folder, 
            #                self._access_point)
        # Create commit bash helper folder
        #if not self._path_exists(
        #            SPath.get_system_commit_helper_folder()):
        #    self._create_folder(
        #            SPath.get_system_commit_helper_folder())
        # Create System Binary Folder
        if not self._path_exists(
                SPath.path_to_binary_folder(self._access_point)):
            self._create_folder(
                SPath.path_to_binary_folder(self._access_point))

    def _check_path_exists(self, *args):
        '''
        Check path exist in system
        If not, raise FileNotFound error.
        :param *args : Path need to be checked.
        '''
        for path in args:
            if not self._path_exists(path):
                self._logger.debug(_(
                    '{0} try to access non-exist file at {1}'.format(
                    inspect.stack()[1][3], path)))
                raise FileNotFound()

    def _path_exists(self, path):
        '''
        Check for existence of given path.
        os.path.exists(path) may return False 
        if permission is not granted to execute 
        os.stat() on the requested file
        Return TRUE if exists, else FALSE
        '''
        return os.path.exists(path)	
        #self._logger.debug("Enter base._path_exists")
        #try:
        #    self._execute(self._logger, 'stat', unicode(path))
        #    return True
        #except ProcessExecutionError as exc:
        #    if 'No such file or directory' in exc.stderr \
        #        or '沒有此一檔案或目錄' in exc.stderr:
        #        return False
        #    else:
        #        raise StorageError(exc.stderr)

    def _delete_versions(self, path_to_version):
        for f in os.walk(path_to_version):
            # (dirpath, dirname, filename)
            for fn in f[2]:
                # filename is []
                # will not go into here
                path = os.path.join(f[0], fn)
                try:
                    with open(unicode(path), 'r') as fd:
                        meta = utils.read_metadata(fd)
                        self._delete_file_chunk(meta)
                except Exception as e:
                    self._logger.debug(_(e))
                    raise StorageEroor(e)
        # Delete versions folder
        self._delete(path_to_version)

    def _delete_file_chunk(self, meta):
        for chunk in meta['manifest']:
            #TODO : what if chunk not found
            self._decrease_binary_usage(chunk)
            if int(self._get_binary_usage(chunk)) == 0:
                # chunk is not refered by any chunk
                # we can delete it.
                path_to_chunk = self._get_path_to_chunk(chunk)
                #path_to_chunk = os.path.join(
                #    path_to_bin, chunk)
                self._delete(path_to_chunk)

    def _get_path_to_chunk(self, chunk_id):
        '''
        Get path to chunk file
        Return /PATH/TO/CHUNK
        '''
        #self._logger.debug("Enter base._get_path_to_chunk")
        return SPath.path_to_chunk(self._access_point, chunk_id)

    def _get_path_to_chunk_count(self, chunk_id):
        '''
        Get path to chunk file
        Return /PATH/TO/CHUNK.count
        '''
        #self._logger.debug("Enter base._get_path_to_chunk_count")
        return '{0}.{1}'.format(
            self._get_path_to_chunk(chunk_id),'count')

    def _get_normalize_path(self,path):
        '''
        Remove the first slash
        Otherwise os.path.join cannot point to right position
        '''
        #self._logger.debug('Enter base._get_normalize_path')
        if os.path.isabs(path) :
            return path[1:]
        return path
   
    def _get_list_sorted_by_mtime(self, path):
        '''
        List a folder and sorted by modified time
        [NEW -> OLD]
        Return a list
        '''
        #self._logger.debug('Enter base._get_list_sorted_by_mtime')
        #print path
        try:
            mtime = lambda f: os.stat(os.path.join(path, f)).st_mtime
            return list(sorted(os.listdir(path), key=mtime, reverse=True))
            #return self._execute(self._logger, 
            #        'ls','-tr', path,)[0].split('\n')[:-1] 
        except Exception as e:
            self._logger.debug(_('Unable to list : ${0}'.format(path)))
            self._logger.debug(_('Exception : ${0}'.format(e)))
            raise StorageError(e)

    def _create_folder_contents(self,access_path):
        '''
        Create the folder content metadata while listing a folder
        Return a list
        :param access_path : Path to folder
        '''
        contents = []
        for c in sorted(os.listdir(access_path)):
            p = os.path.join(access_path,c)
            if os.path.isdir(p):
                contents.append(utils.create_folder_metadata(
                    p, SPath.get_system_relative_path(
                            self._access_point,p
                            )
                        )
                    )
            elif os.path.isfile(p):
                contents.append(self._get_file_metadata(p))
        return contents

    def _search_by_name(self, path, name):
        '''
        Search a file by name
        Return a LIST
        :param path : Search Path
        :param name : file name
        '''
        try:
            #result = []
            #for root, dirs, files in os.walk(path):
            #    for fn in files:
            #        if fnmatch.fnmatch(name, '*{0}*'.format(name)):
            #            result.append(os.path.join(root, fn))
            #return result
            return self._execute(self._logger,
                        'find', path, '-iname', 
                        u'*{0}*'.format(name))[0].split()
        except Exception as e:
            self._logger.debug(_('Unable to search the path %s'), path)
            raise StorageError(e)

    def _get_file_metadata(self, path, is_version=False):
        '''
        Get file metadata
        Return metadata
        :param path : Path to file
        :param is_version : TRUE if is versioned file
        '''
        try: 
            with open(unicode(path),'r') as fd :
                meta = utils.read_metadata(fd)
                return self._assign_path_metadata(meta, path, is_version)
        except Exception as e:
            self._logger.debug(_('Unable to read metadata ${0}'.format(path)))
            raise StorageError(e)

    def _assign_path_metadata(self, meta, path, is_version=False):
        '''
        Dynamic assign path valuse, otherwise
        we need to modify this valuse for each version
        upon each copy/rename/move operation
        Return Metadata
        :param meta : metadata w/o path
        :param path : ABS path to the file
        :param is_version : TRUE if its versioned file
        '''
        if not is_version:
            meta['path'] = SPath.get_system_relative_path(
                        self._access_point, path)
        else:
            meta['path'] = os.path.dirname(
                            SPath.get_system_relative_path(
                                    self._access_point, path)
                            )
        return meta
        
    def _get_folder_metadata(self, access_path, 
                    is_list=False,version=None):
        '''
        Get folder metadata
        Return metadata
        :param access_path : Path to folder
        :param is_list : TRUE if it listing operation
        :param version : Folder version, not used for now.
        '''
        folder_meta = utils.create_folder_metadata(
                access_path,
                SPath.get_system_relative_path(
                                self._access_point, access_path))
        if is_list :
            folder_meta['contents'] = self._create_folder_contents(
                    access_path)
        return folder_meta

    def _commit_helper(self, save_path, path_to_temp, temp_uuid):
        for f in os.listdir(path_to_temp):
            # Bypass temp metadata
            if f == temp_uuid: 
                continue
            path_to_chunk = self._get_path_to_chunk(f)
            if not self._path_exists(path_to_chunk):
                shutil.move(os.path.join(path_to_temp, f),path_to_chunk)
            try:
                fn = self._get_path_to_chunk_count(f)
                with open(fn, 'a') as fd:
                    utils.write_data(u'\n', fd)
                    #fd.write(unicode(save_path))
                    #fd.write(u' \n')
            except Exception as e:
                raise StorageError(e)
        # Remove Path to temp
        try:
            shutil.rmtree(path_to_temp)
        except Exception as e:
            raise StorageError(e)

    def _gen_commit_bash_helper(self, path_to_temp, path_to_bin, temp_uuid):
        '''
        Generate Bash Helper for commit operation
        Return Path to helper
        :param path_to_temp : Path to temp folder
        :param paht_to_bin : Path to binary folder
        :param temp_uuid : Temp folder for chunks.
        '''
        ##!/usr/bin/env bash
        #for file in {1}$MOUNT_POINT/$TENANT_ID/$TMP/$TEMP_UUID/*
        #do
	    #filename = $(basename ${file})
        #    mv ${file} $MOUNT_POINT/$BINARY/${filename}
        #    echo " " >> $MOUNT_POINT/$BINARY/${filename}.count
        #done
        path_to_helper = os.path.join(
            SPath.get_system_commit_helper_folder(),temp_uuid)
        try:
            with open(unicode(path_to_helper),'w') as fd:
                fd.write('#!/usr/bin/env bash\n') 
                fd.write('for file in {0}/* \n'.format(path_to_temp)) 
                fd.write('do \n') 
                fd.write('filename={0} \n'.format('$(basename ${file})')) 
                fd.write('mv {0} {1}/{2} \n'.format('${file}',path_to_bin,'${filename}')) 
                fd.write('echo " " >> {0}/{1}.count \n'.format(path_to_bin,'${filename}')) 
                fd.write('done \n')
            self._execute(self._logger, 'chmod','+x',path_to_helper)
            return path_to_helper
        except Exception as e:
            raise StorageError(e)

    def _get_chunk(self, access_path):
        """
        Download a chunk
        return $BINARY/$CHUNK_ID
        :param chunk_id : Chunk ID
        """
        try:
            with open(unicode(access_path), 'rb') as fd:
                chunk = fd.read(os.path.getsize(access_path))
        except Exception as e:
            raise StorageErrore(e)
        return chunk
    
    def _move(self, src, dest, overwrite=False):
        '''
        Move a file/folder
        :param src : Path to src file/folder.
        :param dest : Path to dest file/folder.
        '''
        if not self._path_exists(src):
            raise FileNotFound()
        
        if self._path_exists(dest) and not overwrite :
            raise FileExists() 
        
        if not self._path_exists(os.path.dirname(dest)):
            self._create_folder(os.path.dirname(dest))
        #if not self._path_exists(dest):
        #    self._create_folder(os.path.dirname(dest))
        #elif not overwrite:
        #    raise FileExists()
        #try:
        #    shutil.move(src, dest)
        
        try: 
            self._execute(self._logger, 'mv', src, dest)
        except ProcessExecutionError as exc:
            raise StorageError(exc.stderr)
        except Exception as e:
            raise StorageError(e)

    def _copy(self, src, dest, overwrite=False):
        '''
        Copy a file/folder
        :param src : Path to src file/folder.
        :param dest : Path to dest file/folder.
        '''
        
        if not self._path_exists(src):
            raise FileNotFound()
       	
        if self._path_exists(dest) and not overwrite :
            raise FileExists() 
        
        if not self._path_exists(os.path.dirname(dest)):
            self._create_folder(os.path.dirname(dest))
        #elif not overwrite:
        #    raise FileExists()

        try:
            #shutil.copy(src,dest)
            self._execute(self._logger, 'cp', '-rf', src, dest )
        except ProcessExecutionError as exc:
            raise StorageError(exc.stderr)
        except Exception as e:
            raise StorageError(e)

    def _delete(self, file_path):
        '''
        Delete a file/folder
        :param file_path : Path to file/folder.
        '''
        #file_path = file_path.replace(self._access_point, self._access_folder)
        try:
            #if os.path.isfile(file_path):
            #    os.remove(file_path)
            #else:
            #    shutil.rmtree(file_path)
            self._execute(self._logger, 'rm', '-rf', file_path)
        except ProcessExecutionError as exc:
            raise StorageError(exc.stderr)
        except Exception as e:
            print e
            raise StorageError(e)

    def _create_folder (self, path_to_folder):
        '''
        Create a folder
        :param path_to_folder : Path to folder.
        '''
        try:
            return os.makedirs(path_to_folder)
            #if not self._path_exists(path_to_folder):
            #self._execute(self._logger, 
            #        'mkdir', '-p', path_to_folder)
            #return True
        except OSError as exc:
            #if 'File exists' in exc.stderr:
            #    self._logger.debug("File exists")
            #    return FileExists(path_to_folder)
            #else:
            raise StorageError(exc)

        #try:
            #if not self._path_exists(path_to_folder):
        #    self._execute(self._logger, 
        #            'mkdir', '-p', path_to_folder)
        #    return True
        #except ProcessExecutionError as exc:
            #if 'File exists' in exc.stderr:
            #    self._logger.debug("File exists")
            #    return FileExists(path_to_folder)
            #else:
        #    raise StorageError(exc.stderr)

    def _touch_file (self, path):
        '''
        Create a folder
        :param path_to_folder : Path to folder.
        '''
        try:
            #if not self._path_exists(path_to_folder):
            self._execute(self._logger, 
                    'touch', path)
            return True
        except ProcessExecutionError as exc:
            #if 'File exists' in exc.stderr:
            #    self._logger.debug("File exists")
            #    return FileExists(path_to_folder)
            #else:
            raise StorageError(exc.stderr)
    
    def _get_binary_usage(self, chunk_id):
        '''
        Get Binary usage
        Return usage as an INT
        :param chunk_id : Chunk ID
        '''
        #driver._execute('wc','-l',
        #    '/opt/monga/binary/221387a915a2b606e54907ed8ecec348.count')
        #('15 /opt/monga/binary/221387a915a2b606e54907ed8ecec348.count\n', '')
        #driver._execute('wc','-l',
        #    '/opt/monga/binary/221387a915a2b606e54907ed8ecec348.count')[0].split()[0]
        #Out[72]: '15'
        #with open(self._get_path_to_chunk_count(chunk_id), 'r') as fd :
        #    return fd.readlines().__len__()
        try:
            return self._execute(self._logger, 'wc','-l',
                        self._get_path_to_chunk_count(chunk_id)
                    )[0].split()[0]
        except ProcessExecutionError as exc:
            raise StorageError(exc.stderr)
        except Exception as e:
            raise StorageError(e)

    def _decrease_binary_usage(self, chunk_id, delete_path=None):
        path_to_count = self._get_path_to_chunk_count(chunk_id)
        #with open(path_to_count, 'r') as fd :
        #    lines = fd.readlines()
        #with open(path_to_count, 'w') as fd :
        #    fd.writelines(lines[1:])
            #for line in lines:
            #    if line == delete_path: continue
            #    fd.write(line)
            #    fd.write('\n')
        try:
            self._execute(self._logger, 'sed', '-i', '$d', path_to_count)
        except ProcessExecutionError as exc:
            raise StorageError(exc.stderr)
        except Exception as e:
            raise StorageError(e)

