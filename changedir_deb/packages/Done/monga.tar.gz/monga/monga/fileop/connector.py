import commands

class Connector:
    def __init__(self):
        self.location = 'this is connector'
        #commands.getoutput('rm -rf /tmp/aaa')

    def printData(self):
        print 'haha %s'%self.location
    def upload(self, uid, fname, data, checksum):
    #def upload(self, tenant_id, temp_uuid, data, data_md5)

    #def upload(self, t_id, uid, data, checksum):
        #fname = t_id+'/'+uid+
        fname = '/tmp/'+fname
        path = fname.rsplit('/',1)[0]
        commands.getoutput('mkdir %s'%path)
        manifestfile = fname
        commands.getoutput('touch %s'%(manifestfile))
        chunkfilename = path+'/'+checksum
        commands.getoutput('echo %s >> %s'%(chunkfilename, manifestfile))
        path='%s/%s'%(path, checksum)
        f = open(path, "w")
        f.write(data)
        f.close()
        return 'ok'
    def readMeta(self, uid):
        manifestfile = '/tmp/'+uid
        ret = commands.getoutput('cat %s'%(manifestfile)).split('\n')
        print ret
        return ret
    def commit(self):
        print 'file commit'
        return 'ok'
    def create_folder(self, t_id, filepath):
        ret = commands.getoutput('mkdir /tmp/%s/%s'%(t_id, filepath))
        return filepath
        

