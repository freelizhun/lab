import httplib
import sys
import mimetypes
import os
import json
import urllib
CHUNKSIZE = 4096
url="http://127.0.0.1:7000/"
conn = httplib.HTTPConnection("127.0.0.1", 7000)
body = json.dumps({'root':'tenant_id','path':'/hahalala'})
conn.request('POST', '/v1/fileops/create_folder?path=hahaha') 
response = conn.getresponse()
#response = getresponse()
print '------status--------'
print response.status
print '------resaon--------'
print response.reason
print '----- read -------'
ret= response.read()
print ret
retd= json.loads(ret)
print retd
#print response.headers


