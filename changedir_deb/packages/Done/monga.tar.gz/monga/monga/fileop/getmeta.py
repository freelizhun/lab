import httplib, urllib
import json
#url = 'http://localhost:8090/search?q=haha&aq=f'
conn = httplib.HTTPConnection("localhost:7000")
conn.putrequest("GET", "/v1/metadata")
conn.putheader("X-AUTH-Token","dab9a1c0bf364d299a756a26a913fd3a")
conn.endheaders()
response = conn.getresponse()
print response.status, response.reason

print '------status--------'
print response.status
print '------resaon--------'
print response.reason
#print '----- read -------'
#print response.getheader('x-dropbox-metadata')
ret= response.read()
#print ret
retd= json.loads(ret)
print retd

