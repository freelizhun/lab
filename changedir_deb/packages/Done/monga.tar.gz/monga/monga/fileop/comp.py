import lz4
a = '1234567891'*102400
print len(a)
aa = lz4.compress(a)
print len(aa)
bb = lz4.uncompress(aa)
print len(bb)


