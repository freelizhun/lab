

import httplib
import sys
import mimetypes
import os
import json
import urllib
import commands

def getTokenTid(user, password):
    s ="""curl -X POST -v -H 'Content-Type: application/json' 10.90.0.52:35357/v3/auth/tokens -d '{"auth":{"identity":{"methods":["password"],"password":
        {"user":{"domain":{"name":"cs.promise.com.tw"},"name":"%s","password":"%s"}}},"scope":{"project":{"domain":{"name":"cs.promise.com.tw"},"name":"%s"}}}}'"""%(user,password,user)
    #print s
    strr = commands.getoutput(s)
    print strr
    ss= strr.split('left intact')
#print ss.get('project')
#print '---------------'
#print ss[0]
    #print '------------------------------------'
    token =  ss[0].split('X-Subject-Token:')[1].split()[0]
    print 'show token ---------------',token
    t_idtmp= ss[1].split('*')[0].strip()
    t_id =  json.loads(t_idtmp)['token']['project']['id']
    return token,t_id

token,t_id = getTokenTid('Carol.Wilson','Password1')
print token,t_id
#ss = commands.getstatus('python testing_loop.py  %s'%(token))
#print ss


"""
print '---------------'
print ss[1]
sss = ss[1].strip()
print sss

ssss= dict(sss)
"""




