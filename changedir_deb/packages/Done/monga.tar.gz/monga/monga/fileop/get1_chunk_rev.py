import httplib, urllib
import json
params = urllib.urlencode({'spam': 1, 'eggs': 2, 'bacon': 0})
headers = {"Content-type": "application/x-www-form-urlencoded",
        "Accept": "text/plain"}
#url = 'http://localhost:8090/search?q=haha&aq=f'

conn = httplib.HTTPConnection("localhost:7000")
conn.request("GET", "/v1/files/vsize.txt?rev=6b4cb9e08a9b0fcc6e9a6383ea166da8", params, headers)
response = conn.getresponse()
print response.status, response.reason


#print data
#conn.close()
f = open('/tmp/size_rev.txt',"wb")
chunksize = 4096
#data = response.read(chunksize)
data = response.read(chunksize)
while data:
    f.write(data)
    data = response.read(chunksize)
f.close()
conn.close()

print '------status--------'
print response.status
print '------resaon--------'
print response.reason
print '----- read -------'
print response.getheader('x-dropbox-metadata')
#et= response.read()
#print ret
#retd= json.loads(ret)
#print retd

