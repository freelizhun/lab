import httplib
import sys
import mimetypes
import os
import json
import urllib
url="http://127.0.0.1:7000/"
conn = httplib.HTTPConnection("127.0.0.1", 7000)
conn.putrequest('POST', '/v1/fileops/copy?root=0132ca642aee4550940ccba6a5d96b48&from_path=size1.txt&to_path=sizecopy6.txt') 
conn.putheader("X-AUTH-Token","f7cc98793c6a49a7b75d7c2fced71039")
conn.endheaders()

response = conn.getresponse()
print '------status--------'
print response.status
print '------resaon--------'
print response.reason
print '----- read -------'
ret= response.read()
print ret
retd= json.loads(ret)
print retd
#print response.headers


