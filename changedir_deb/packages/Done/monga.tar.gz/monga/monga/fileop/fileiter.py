from monga.fileop.Error import MyError
#from monga.connector import connector as conn
from monga.connector import get_connector
import lz4
from monga.fileop.encutils import encData

class FileIterable(object):
    def __init__(self, listfile, t_id, log, conf, comFlag, encFlag, count=0, size=4096):
       self.count = count
       #self.chunk_size = 1024000
       self.chunk_size = int(conf.get('storage_chunk_size',1024000))
       self.listfile = listfile
       self.t_id = t_id
       self.log = log
       self.comFlag = comFlag
       self.encFlag = encFlag
       self.conf = conf

    def __iter__(self):
       return FileIterator(self.t_id, self.listfile, self.count, self.chunk_size, self.log, self.conf, self.comFlag, self.encFlag)
class FileIterator(object):
    #chunk_size = 4096
    def __init__(self, t_id, listfile, count, chunk_size, log, conf, comFlag, encFlag):
        self.count = count
        self.chunk_size = chunk_size
        self.listfile = listfile
        #self.fileobj = open(self.listfile[self.count], 'rb')
        self.conn = get_connector(log, conf)
        self.t_id = t_id
        self.comFlag = comFlag
        self.encFlag = encFlag
        self.enc = encData()
    def __iter__(self):
        return self
    def next(self):
        if self.count >= len(self.listfile):
           raise StopIteration
        chunk = self.conn.download(self.t_id, self.listfile[self.count])

        if self.encFlag:
            decryptkey=self.listfile[self.count].rsplit('-',1)[1]
            enc_data = self.enc.decrypt(chunk, decryptkey)
            chunk = enc_data

        if self.comFlag:
            tmpchunk = lz4.uncompress(chunk)
            chunk = tmpchunk


        self.count = self.count + 1

        return chunk
#def make_response(count):
#    res = Response(content_type=get_mimetype(count))
#    res.app_iter = FileIterable(count)
#    res.content_length = os.path.getsize(count)
#    return res


