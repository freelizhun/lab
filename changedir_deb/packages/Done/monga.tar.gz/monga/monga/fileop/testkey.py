

import httplib
import sys
import mimetypes
import os
import json
import urllib
url="http://127.0.0.1:7000/"

headerss = {"Content-type": "application/json"}
msgbody = {"auth":{"identity":{"methods":["password"],"password":{"user":{"domain":{"name":"cs.promise.com.tw"},"name":"Carol.Wilson","password":"Password1"}}},
        "scope":{"project":{"domain":{"name":"cs.promise.com.tw"},"name":"Carol.Wilson"}}}}

conn = httplib.HTTPConnection("10.90.0.52", 35357)
conn.request('POST', '/v3/auth/tokens',  body=json.dumps(msgbody), headers = headerss)

response = conn.getresponse()
print '------status--------'
print response.status
print '------resaon--------'
print response.reason
print '----- read -------'
ret= response.read()
print ret
retd= json.loads(ret)
print retd
print retd['token']['project']['id']
"""
 curl -v -H 'Content-Type: application/json'
 10.90.0.58:35357/v3/auth/tokens 
msgbody = {"auth":{"identity":{"methods":["password"],"password":{"user":{"domain":{"name":"cs.promise.com.tw"},
"name":"joe","password":"joe"}}},"scope":{"project":{"domain":{"name":"cs.promise.com.tw"},"name":"joe"}}}}
"""
"""
 curl -v -H 'Content-Type: application/json'
 10.90.0.58:35357/v3/auth/tokens 
-d '{"auth":{"identity":{"methods":["password"],"password":{"user":{"domain":{"name":"cs.promise.com.tw"},
"name":"joe","password":"joe"}}},"scope":{"project":{"domain":{"name":"cs.promise.com.tw"},"name":"joe"}}}}'
"""

