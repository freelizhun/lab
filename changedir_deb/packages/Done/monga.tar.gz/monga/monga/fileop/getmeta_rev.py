import httplib, urllib
import json
params = urllib.urlencode({'spam': 1, 'eggs': 2, 'bacon': 0})
headers = {"Content-type": "application/x-www-form-urlencoded",
        "Accept": "text/plain"}
#url = 'http://localhost:8090/search?q=haha&aq=f'

conn = httplib.HTTPConnection("localhost:7000")
conn.putrequest("GET", "/v1/revisions/sizemm.txt")
conn.putheader("X-AUTH-Token","bfe8e086728a47ef812266a941f614d1")
conn.endheaders()

response = conn.getresponse()
print response.status, response.reason

print '------status--------'
print response.status
print '------resaon--------'
print response.reason
#print '----- read -------'
#print response.getheader('x-dropbox-metadata')
ret= response.read()
#print ret
retd= json.loads(ret)
print retd

