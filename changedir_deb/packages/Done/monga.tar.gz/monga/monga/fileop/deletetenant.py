import httplib
import sys
import mimetypes
import os
import json
import urllib
url="http://127.0.0.1:7000/"
conn = httplib.HTTPConnection("127.0.0.1", 7000)
conn.putrequest('DELETE', '/v1/delete/98ed9d6ac11646b9ba73b5591be443dd') 
conn.putheader("X-AUTH-Token","ADMIN")
conn.endheaders()


response = conn.getresponse()
print '------status--------'
print response.status
print '------resaon--------'
print response.reason
print '----- read -------'


