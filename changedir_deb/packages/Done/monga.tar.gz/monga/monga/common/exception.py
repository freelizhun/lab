#import logging
from decorator import decorator
from monga.common import response as RESP
import sys

class BadRequestError(Exception):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)
        
class NotFoundError(Exception):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)
        
class ExceedQuotaError(Exception):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)
        
class FileNotFoundError(NotFoundError):
    def __init__(self, path=None):
        self.value = 'File Not Found At : {0}'.format(path)

class ForbiddenError(Exception):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)

class FileExistError(ForbiddenError):
    def __init__(self, path=None):
        self.value = 'File Exist At : {0}'.format(path)

class InternalServerError(Exception):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)

class InvalidParameter(InternalServerError):
    def __init__(self, fn):
        self.value = 'Invalid Input for {0}'.format(fn)

class StorageError(Exception):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)

class UploadTimeOut(Exception):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)

class FileBusyError(Exception):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)
    #pass

class NotImplementError(Exception):
    pass

class UnauthorizedError(Exception):
    pass

class ManifestUploadError(Exception):
    pass
    
class LengthRequiredError(Exception):
    pass

def handle_exceptions():
    def wrapper(func, *args, **kwargs):
        try:
            return func(*args, **kwargs)
        except (BadRequestError, ValueError) as e:
            return RESP.bad_request(e)
        except (NotFoundError, FileNotFoundError, NotImplementError) as e:
            return RESP.not_found(e)
        except (ForbiddenError, ExceedQuotaError, FileExistError) as e:
            return RESP.forbidden(e)
        except InternalServerError as e:
            return RESP.internal_error(e)
        except UnauthorizedError as e:
            return RESP.unauthorized('Unauthorized')
        except LengthRequiredError:
            return RESP.lengtherror()
        except StorageError as e:
            return RESP.storageerror(e)
        except UploadTimeOut as e:
            return RESP.uploadtimeout(e)
        except FileBusyError as e:
            return RESP.filebusyerror('File is busy %s'%e)
        #except Exception as e:
        #    return RESP.internal_error(e)
    return decorator(wrapper)
