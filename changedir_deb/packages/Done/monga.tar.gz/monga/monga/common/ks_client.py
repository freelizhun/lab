import httplib2
import json
import urlparse
import logging
log = logging.getLogger(__name__)

class KeystoneClient():

    def __init__(self, path, token):
        self.path = path
        self.headers = {'X-Auth-Token' : token}
            
    def get_tenant(self, user_id):
        _url = self.path + 'projects/' + user_id
        return self._do_request(_url, headers = self.headers)['project']
        
    def get_user(self, user_name):
        _url = self.path + 'users?name=' + user_name
        return self._do_request(_url, headers = self.headers)
        
    def get_user_tenant(self, user_name):
        _url = self.path + 'projects?name=' + user_name
        return self._do_request(_url, headers = self.headers)

    @staticmethod
    def _do_request(url, method = 'GET', headers = None, body = None):
        headers = headers or {}
        conn = httplib2.Http()
        conn.force_exception_to_status_code = True
        headers['User-Agent'] = 'monga-client'
        resp, resp_body = conn.request(url, method, headers = headers, 
                                       body = body)
        if resp.status == 200:
            return json.loads(resp_body)
        else:
            raise Exception('Unexpected response: %s'% resp.status)

