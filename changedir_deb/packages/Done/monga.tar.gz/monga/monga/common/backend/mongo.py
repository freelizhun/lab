import pymongo
from pymongo import Connection
from bson.code import Code
from pymongo.errors import *
import time
import hashlib
import re
from bson.objectid import ObjectId
from monga.common import exception as exception
from monga.common.backend.base import BaseMongoDriver
from monga.common.utils import current_timestamp

class MongoDBConnector (BaseMongoDriver):
    
    def __init__(self, path='localhost', port=27017, db_conn = None,
                 tz_aware=True):
        self.mongo_path = path
        self.mongo_port = port
        self.time_zone = tz_aware
        BaseMongoDriver.__init__(self, path, port, conn = db_conn)

    def update_quota(self, user_info, used = 0):
        self.update('quota', {'tenant_id' : user_info['tenant_id']}, 
                        {"$inc" : {'used' : used}}, True)

    def find_quota(self, user_info, multi = False):
        if multi :
            return self.base_find('quota', {})
        else :
            res = self.base_findone('quota', 
                                    {'tenant_id' : user_info['tenant_id']})
            if not res:
                return {'used' : 0, 'tenant_id' : user_info['tenant_id']}
            else :
                del res['_id']
            return res
    
    def insert_lock(self, user_info, file_path):
        data = {
            'user_id'      : user_info.get('user_id', None),
            'user_name'    : user_info.get('user_name', None),
            'tenant_id'    : user_info.get('tenant_id', None),
            'tenant_name'  : user_info.get('tenant_name', None),
            'domain_id'    : user_info.get('domain_id', None),
            'domain_name'  : user_info.get('domain_name', None),
            'file_path'    : file_path,
            'updated_time' : current_timestamp(),
            'expired_time' : current_timestamp() + 86400
        }
        return self.base_insert('lock', data)

    def find_lock(self, tenant_id, domain_id, path):
        result = self.base_find('lock',
                       {'tenant_id' : tenant_id,
                        'file_path' : path,
                        'domain_id' : domain_id}, 
                       count = True)
        if result == 0:
            return True
        else:
            return False
            
    def find_expired_lock(self, query):
        return self.base_find('lock', query)
        
    def delete_expired_lock(self, _id):
        return self.direct_delete('lock', _id)
            
    def find_user_lock(self, user_info, path):
        result = self.base_findone('lock', {
                    'user_id'      : user_info.get('user_id', None),
                    'user_name'    : user_info.get('user_name', None),
                    'tenant_id'    : user_info.get('tenant_id', None),
                    'tenant_name'  : user_info.get('tenant_name', None),
                    'domain_id'    : user_info.get('domain_id', None),
                    'domain_name'  : user_info.get('domain_name', None),
                    'file_path'    : path})
        if result:
            return True
        else:
            return False

    def delete_lock(self, user_info, path):
        return self.base_delete('lock',
                                {'tenant_id' : user_info['tenant_id'],
                                 'user_id'   : user_info['user_id'],
                                 'file_path' : path,
                                 'domain_id' : user_info['domain_id']})

    def insert_shared(self, from_user, to_user, link_user, permission, 
                      file_path, shared_path, is_dir = False, confirm = False):
        data = {
            #from
            'from_user_id'     : from_user['user_id'],
            'from_user_name'   : from_user['user_name'],
            'from_tenant_id'   : from_user['tenant_id'],
            'from_tenant_name' : from_user['tenant_name'],
            'from_domain_id'   : from_user['domain_id'],
            'from_domain_name' : from_user['domain_name'],
            #to
            'to_user_id'       : to_user['user_id'],
            'to_user_name'     : to_user['user_name'],
            'to_tenant_id'     : to_user['tenant_id'],
            'to_tenant_name'   : to_user['tenant_name'],
            'to_domain_id'     : to_user['domain_id'],
            'to_domain_name'   : to_user['domain_name'],
            #link
            'link_user_id'     : link_user['link_user_id'],
            'link_user_name'   : link_user['link_user_name'],
            'link_tenant_id'   : link_user['link_tenant_id'],
            'link_tenant_name' : link_user['link_tenant_name'],
            'link_domain_id'   : link_user['link_domain_id'],
            'link_domain_name' : link_user['link_domain_name'],
            'link_path'        : link_user['link_path'],
            #attrs
            'permission'       : {'write' : permission['write']},
            'is_dir'           : is_dir,
            'file_path'        : file_path,
            'shared_path'      : shared_path,
            'updated_time'     : current_timestamp(),
            'confirm'          : confirm
        }
        return self.base_insert('shared', data)

    def find_shared(self, body, action = 'to', path = None, shared_path = None,
                    once = False, match = False, count = False, confirm = True):
        data = {
            action + '_user_id'     : body['user_id'],
            action + '_user_name'   : body['user_name'],
            action + '_tenant_id'   : body['tenant_id'],
            action + '_tenant_name' : body['tenant_name'],
            action + '_domain_id'   : body['domain_id'],
            action + '_domain_name' : body['domain_name'],
        }
        if path :
            data['file_path'] = path
        if shared_path :
            data['shared_path'] = shared_path
        if count :
            return self.base_find('shared', data), \
                self.base_find('shared', data, count = count)
        elif once and not match:
            return self.base_findone('shared', data)
        elif once and match:
            return self.match_find('shared', data, once = True)
        elif not once and match :
            return self.match_find('shared', data)
        else :
            return self.base_find('shared', data)
            
    def find_link_shared(self, data):
        data = {
            'link_user_id'     : data['link_user_id'],
            'link_user_name'   : data['link_user_name'],
            'link_tenant_id'   : data['link_tenant_id'],
            'link_tenant_name' : data['link_tenant_name'],
            'link_domain_id'   : data['link_domain_id'],
            'link_domain_name' : data['link_domain_name'],
            'link_path'        : data['link_path']
        }
        return self.base_find('shared', data)
        
    def check_shared_path(self, user_info, path, confirm = True):
        data = {
            'to_user_id'       : user_info.get('user_id', None),
            'to_user_name'     : user_info.get('user_name', None),
            'to_tenant_id'     : user_info.get('tenant_id', None),
            'to_tenant_name'   : user_info.get('tenant_name', None),
            'to_domain_id'     : user_info.get('domain_id', None),
            'to_domain_name'   : user_info.get('domain_name', None),
            'is_dir'           : user_info.get('is_dir', False),
            'shared_path'      : path,
        }
        return self.base_findone('shared', data)
        
    def find_mathched_shared_path(self, user_info, path, confirm = True):
        data = {
                   'to_user_id'     : user_info.get('user_id', None),
                   'to_user_name'   : user_info.get('user_name', None),
                   'to_tenant_id'   : user_info.get('tenant_id', None),
                   'to_tenant_name' : user_info.get('tenant_name', None),
                   'to_domain_id'   : user_info.get('domain_id', None),
                   'to_domain_name' : user_info.get('domain_name', None),
                   'shared_path'    : path,
        }
        return self.base_findone('shared', data)

    def delete_shared(self, _id):
        return self.direct_delete('shared', _id)

    def insert_dlink(self, user_info, file_path, public_url, 
                     match_url, pwd = None, expired_time = None,
                     expired_tag = None):
        if not expired_time:
            expired_time = int(round(time.time())) + 7*86400
        data = {
            'user_id'      : user_info.get('user_id', None),
            'user_name'    : user_info.get('user_name', None),
            'tenant_id'    : user_info.get('tenant_id', None),
            'tenant_name'  : user_info.get('tenant_name', None),
            'domain_id'    : user_info.get('domain_id', None),
            'domain_name'  : user_info.get('domain_name', None),
            'file_path'    : file_path,
            'public_url'   : public_url,
            'match_url'    : match_url,
            'pwd'          : pwd,
            'expired_time' : expired_time,
            'updated_time' : current_timestamp(),
            'expired_tag'  : expired_tag
        }
        return self.base_insert('dlink', data)

    def find_dlink(self, data, _id = None, multi = False):
        if _id :
            return self.base_findone('dlink', {'_id' : ObjectId(_id)})
        elif multi :
            return self.base_find('dlink', data)
        else :
            return self.base_findone('dlink', data)
        
    def update_dlink(self, _id, data):
        return self.update('dlink', {'_id' : ObjectId(_id)}, {"$set" : data})
        
    def delete_dlink(self, _id):
        return self.direct_delete('dlink', _id)
        
    def insert_log(self, user_info, action, method = 'GET', from_path = None, 
                   to_path = None, size = 0, is_chunk = False, is_dir = False,
                   chunk_id = None, is_share = False, result = True,
                   delta = None, notifier = False):
        data = {
            'user_id'      : user_info.get('user_id', None),
            'user_name'    : user_info.get('user_name', None),
            'tenant_id'    : user_info.get('tenant_id', None),
            'tenant_name'  : user_info.get('tenant_name', None),
            'domain_id'    : user_info.get('domain_id', None),
            'domain_name'  : user_info.get('domain_name', None),
            'action'       : action,
            'method'       : method,
            'from_path'    : from_path,
            'to_path'      : to_path,
            'file_size'    : size,
            'is_chunk'     : is_chunk,
            'is_dir'       : is_dir,
            'chunk_id'     : chunk_id,
            'client_ip'    : user_info.get('client_ip', None), 
            'result'       : result,
            'is_share'     : is_share,
            'device_name'  : user_info.get('device_name', 'MongaUser'),
            'delta'        : delta,
            'updated_time' : current_timestamp(),
            'notifier'     : notifier
        }
        return self.base_insert('log', data)

    def find_log(self, data, limit = 100, sort = False, skip = 0):
        if not sort :
            sort = [("updated_time", 1)]
        else :
            sort = [("updated_time", -1)]
        return self.base_find('log', 
                              data, 
                              limit = limit, 
                              sort  = sort,
                              skip  = skip)
                              
    def find_log_count(self, data):
        return self.base_find('log', 
                              data,
                              count = True)
        
    def update_log(self, _id, used = 0):
        self.update('log', {'_id' : _id}, 
                        {"$set" :{"notifier" : True}})

    def delete_log(self, data):
        return self.base_delete('log', data)
        
    def clean_records(self, tenant_id):
        #clean lists
        _list = {
            'log'    : ['tenant_id'],
            'quota'  : ['tenant_id'],
            'dlink'  : ['tenant_id'],
            'lock'   : ['tenant_id'],
            'shared' : ['from_tenant_id', 'to_tenant_id', 'link_tenant_id'],
        }
        for k, v in _list.iteritems() :
            for _v in v:
                self.base_multi_delete(k, { _v : tenant_id })
        return 
