from monga.controller.base import Controller
from monga.common import response as RESP
from swift.common.utils import public
from monga.common import exception as exception
from monga.common.exception import *

class TrashController(Controller):
    server_type = _('Trash')

    def __init__(self, app, **kwargs):
        Controller.__init__(self, app)
        self.action = 'Trash'

    @public
    @exception.handle_exceptions()
    def GET(self, user_info, req):
        #check user role
        if not self.check_role(user_info['user_roles'], 'r'):
            raise ForbiddenError('Access denied')
        #TODO Get response from connector
        from webob import Response
        resp = Response(status = '200 OK')
        #Record Activty
        self.db.insert_log(user_info, 
                           self.action,
                           to_path = path,
                           result = self.get_result(resp.status))
        return RESP.ok()
        
    @public
    @exception.handle_exceptions()
    def DELETE(self, user_info, req, path = None):
        #check user role
        if not self.check_role(user_info['user_roles'], 'r'):
            raise ForbiddenError('Access denied')
        #TODO Get response from connector
        from webob import Response
        resp = Response(status = '200 OK')
        #Record Activty
        self.db.insert_log(user_info, 
                           self.action,
                           to_path = path,
                           result = self.get_result(resp.status))
        return RESP.ok()

    @public
    @exception.handle_exceptions()
    def POST(self, user_info, req, path):
        #check user role
        if not self.check_role(user_info['user_roles'], 'r'):
            raise ForbiddenError('Access denied')
        #TODO Get response from connector
        from webob import Response
        resp = Response(status = '200 OK')
        #Record Activty
        self.db.insert_log(user_info,
                           self.action,
                           to_path = path,
                           result = self.get_result(resp.status))
        return RESP.ok()

