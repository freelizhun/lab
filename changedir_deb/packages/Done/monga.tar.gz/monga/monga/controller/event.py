from monga.controller.base import Controller
from monga.common import response as RESP
from swift.common.utils import public
from monga.common import exception as exception
from monga.common.exception import *
from monga.common.utils import json_dump
import time, json

class EventController(Controller):
    server_type = _('Event')

    def __init__(self, app, **kwargs):
        Controller.__init__(self, app)
        self.action = 'Event'
        self.handle_actions = ['CommitChunkUpload', 'FileCopy', 'FileMove',
                               'CreateFolder', 'FileDelete', 'UploadFile',
                               'Restore', 'ShareFile', 'PublicLink', 'Lock',
                               'JoinShareFolder']
                               
    def _normal_action(self, data, copy = False, link = False):
        res = {
           'update_time' : data['updated_time'],           
           'action'      : data['action']
        } 
        if copy :
            res['from_path'] = self.check_path(data['from_path'])
            res['to_path']   = self.check_path(data['to_path'])
        elif link :
            res['path'] = self.check_path(data['from_path'])
        else :
            res['path'] = self.check_path(data['to_path'])
        return res
                               
    def CommitChunkUpload(self, data):
        pass
        
    def FileCopy(self, data):
        return self._normal_action(data, copy = True)
        
    def FileMove(self, data):
        return self._normal_action(data, copy = True)
        
    def CreateFolder(self, data):
        return self._normal_action(data)
        
    def FileDelete(self, data):
        return self._normal_action(data)
    
    def UploadFile(self, data):
        return self._normal_action(data)
        
    def Restore(self, data):
        return self._normal_action(data)
        
    def ShareFile(self, data):
        return self._normal_action(data)
    
    def PublicLink(self, data):
        if data['method'] == 'POST' :
            return self._normal_action(data, link = True)
        return None
    
    def Lock(self, data):
        return self._normal_action(data)
    
    def JoinShareFolder(self, data):
        return self._normal_action(data)
        
    @public
    @exception.handle_exceptions()
    def GET(self, user_info, req):
        #check user role
        if not self.check_role(user_info['user_roles'], 'r'):
            raise ForbiddenError('Access denied')
        try:
            cursor = req.GET['cursor']
        except Exception:
            cursor = None
        #Set query conditiosn
        query_data = {
            'user_id'   : user_info['user_id'],
            'tenant_id' : user_info['tenant_id'],
            'domain_id' : user_info['domain_id'],
            'result'    : True}
        if cursor :
            query_data['updated_time'] = {'$gt' : int(cursor)}
        #Get log data from db
        data = self.db.find_log(query_data, limit = 0)
        entries = []
        count = 0
        #Fit entry data
        for _d in data:
            if _d['action'] in self.handle_actions :
                handler = getattr(self, _d['action'])
                _res = handler(_d)
                if _res :
                    entries.append(_res)
                    count += 1
                    cursor = _d['updated_time']
            if count == 100:
                break
        #Has more delta or not
        if count == 100:
            has_more = True
        else: has_more = False
        #Generate resp body
        resp_body = {
            'entries'  : entries,
            'cursor'   : cursor,
            'has_more' : has_more
        }
        return RESP.ok(content = json_dump(resp_body))
