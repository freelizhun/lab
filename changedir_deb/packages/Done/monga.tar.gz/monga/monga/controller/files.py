from monga.controller.base import Controller
from monga.common import response as RESP
from swift.common.utils import public
from monga.common import exception as exception
from monga.common.exception import *

class FileController(Controller):
    server_type = _('File')

    def __init__(self, app, **kwargs):
        Controller.__init__(self, app)

    @public
    @exception.handle_exceptions()
    def GET(self, user_info, req, path):
        #check user role
        if not self.check_role(user_info['user_roles'], 'r'):
            raise ForbiddenError('Access denied')
        #Decode path
        path = self.decode_url(path)
        #Check shared folder
        _user, _path, is_share = \
            self.check_shared(user_info, path)
        #Get response from connector
        resp = self.fileop.downloadData(_user, _path, req)
        #Log Activity
        self.db.insert_log(user_info, 
                           'DownloadFile',
                           to_path  = self.check_path(path),
                           size     = resp.headers.get('Content-Length', 0),
                           result   = self.get_result(resp.status),
                           is_share = is_share)
        return resp
        
    @public
    @exception.handle_exceptions()
    def PUT(self, user_info, req, path):
        return self.POST(user_info, req, path)

    @public
    @exception.handle_exceptions()
    def POST(self, user_info, req, path):
        #check user role
        if not self.check_role(user_info['user_roles'], 'w'):
            raise ForbiddenError('Access denied')
        #Decode path
        path = self.decode_url(path)
        #Check shared folder
        _user, _path, is_share = \
            self.check_shared(user_info, path, 'write', True)
        #Check quota
        _quota = int(req.headers.get('X-Tenant-Quota', 5368709120))
        _used = self.db.find_quota(_user).get('used', 0)
        size = req.headers.get('Content-Length', None)
        if not size :
            raise LengthRequiredError()
        else : size = int(size)
        if (_used + size) > _quota:
            raise ExceedQuotaError('Exceed Quota Limit')
        #Get Response from webob
        resp = self.fileop.uploadData(_user, _path, req)
        if is_share :
            resp.body = self.modfied_shared_contents(resp.body, user_info, path)
        #Record Used
        self.db.update_quota(_user, size)
        #Record Activty
        self.db.insert_log(user_info, 
                           'UploadFile',
                           method   = 'POST',
                           delta    = 'Create',
                           to_path  = self.check_path(path),
                           size     = size,
                           result   = self.get_result(resp.status),
                           is_share = is_share)
        return resp
