from monga.common.backend.mongo import MongoDBConnector
from monga.fileop.FileOp import FileOp
from monga.common.exception import *
from monga.common.ks_client import KeystoneClient
from monga.common.utils import json_dump, split_path
import base64
import urllib
import uuid
import json

class Controller(object):
    """Base WSGI controller class for the proxy"""
    server_type = _('Base')

    def __init__(self, app, **local_variables):
        self.app    = app
        self.logger = app.logger
        self.db     = MongoDBConnector(app.mongo_path, app.mongo_port)
        self.fileop = FileOp(self.logger, app.conf)
        self.ks     = KeystoneClient(app.auth_url, app.admin_token)
        
    def encode_url(self, path):
        return urllib.quote(path)
        
    def decode_url(self, path):
        return urllib.unquote(path)    
        
    def check_role(self, roles, action = 'r'):
        '''
        action = 'w' ==> write (at least member)
               = 's' ==> share (at least admin)
               = 'r' ==> share (at least guest)
        '''
        try:
            roles.index('admin')
            return True
        except ValueError:
            if action == 's':
                return False
        try:
            roles.index('member')
            return True
        except ValueError:
            if action == 'w':
                return False
        try:
            roles.index('guest')
            return True
        except ValueError:
            return False
        return False
        
    def check_shared(self, user_info, path, permission = None, lock = False):
        is_share = self.is_shared(path)
        #Find match path then check permission
        if is_share : 
            _map_path, _new_path = self.get_share_path(path)
            #Check path correct or not
            if not _map_path:
                raise BadRequestError('Can\'t operate this path')
            _shared = self.db.find_mathched_shared_path(user_info, _map_path)
            #Check this path exist or not
            if not _shared :
                raise BadRequestError('Can\'t find this shared path')
            #Check Permssion
            if permission:
                if not _shared['permission'][permission] :
                    raise BadRequestError('''Can\'t operate object to this '''
                                          '''shared path''')
            #Combine new path
            if _new_path :
                _path = _shared['link_path'] + _new_path
            else:
                _path = _shared['link_path']
            #Combine real user info
            _user = self.get_real_user(_shared)
        else :
            _user = user_info
            _path = path
        if lock:
            #Check file lock
            if not self.db.find_lock(_user['tenant_id'],
                                     _user['domain_id'], _path) :
                raise BadRequestError('File was locked')
        return _user, _path, is_share

    def get_real_user(self, _shared):
        return {
            'user_id'     : _shared['link_user_id'],
            'user_name'   : _shared['link_user_name'],
            'tenant_id'   : _shared['link_tenant_id'],
            'tenant_name' : _shared['link_tenant_name'],
            'domain_id'   : _shared['link_domain_id'],
            'domain_name' : _shared['link_domain_name']
        }
        
    def is_shared(self, path):
        _path = split_path(path)
        _path = _path[0]
        if _path.lower() == 'shared':
            return True
        else :
            return False
            
    def check_path(self, path):
        if path.startswith('/') :
            return path
        else:
            return '/' + path
            
    def get_share_path(self, path):
        _path = split_path(path)
        if len(_path) == 2:
            if path.startswith('/'):
                return path, None
            else:        
                return '/' + path, None
        elif len(_path) > 2:
            map_path = '/' + _path[0] + '/' +_path[1]
            del _path[0:2]
            new_path = '/' + '/'.join(_path)
            return map_path, new_path
        else :
            return None, None
            
    def get_shared_path(self, path):
        _path = split_path(path)
        return '/' + '/'.join(_path[0:2])
            
    def modfied_shared_contents(self, body, user_info, path):
        _body = json.loads(body)
        data = self.db.find_shared(user_info, 
                                   action = 'to', 
                                   shared_path = self.get_shared_path(path), 
                                   once = True, 
                                   match = True)
        if data :
            _body['path'] = _body['path'].replace(data['link_path'], 
                                                  data['shared_path'], 1)
            if _body.get('contents', None):
                for _content in _body['contents']:
                    _content['path'] = \
                        _content['path'].replace(data['link_path'], 
                                                 data['shared_path'], 1)
        return json_dump(_body)

    def get_result(self, status):
        def _get_status_int(status):
            return int(status.split(' ', 1)[0])
        if _get_status_int(status) < 300 and \
            _get_status_int(status) >= 200 :
            return True
        else:
            return False

    @staticmethod
    def get_uuid():
        return str(uuid.uuid4())
