from monga.controller.base import Controller
from monga.common import response as RESP
from swift.common.utils import public
from monga.common import exception as exception
from swift.common.swob import Request, Response
from monga.common.exception import *
from monga.common.utils import json_dump
from monga.common.utils import split_path
import json

class ShareFileController(Controller):
    server_type = _('ShareFile')

    def __init__(self, app, **kwargs):
        Controller.__init__(self, app)
        self.action = 'ShareFile'
        
    def check_shared_path(self, user_info, body):
        path = self.decode_url(body.get('file_path', None))
        _path = split_path(path)
        _tmp = '/'
        for _p in _path:
            if _tmp == '/' :
                _tmp = _tmp + _p
            else :
                _tmp = _tmp + '/' + _p
            if _tmp == '/shared' :
                continue
            #Find subfolder was shared or not
            _share = self.db.find_shared(user_info, 'to', shared_path = _tmp, 
                                         once = True)
            if _share:
                if _share['shared_path'] != path :
                    self.logger.info('Cant share A')
                    return True, 'CaseA'
            else :
                _share = None
            #Find subfolder was shared or not
            _share = self.db.find_shared(user_info, 'from', path = _tmp, 
                                         once = True)
            if _share :
                if _share['file_path'] != path :
                    self.logger.info('Cant share B')
                    return True, 'CaseB'
            else :
                _share = None
            #Check share from other people
            _share = self.db.find_shared(user_info, 'to', shared_path = _tmp, 
                                         once = True)
            if _share and path != _tmp :
                self.logger.info('Cant share C')
                return True, 'CaseC'
            elif _share and path == _tmp:
                return False, _share
            else :
                _share = None
            #Check share to other people
            _share, _count = self.db.find_shared(user_info, 'from', 
                                                 path = _tmp, count = True)
            if _count and path != _tmp :
                self.logger.info('Cant share D')
                return True, 'CaseD'
            elif _share and path == _tmp :
                _s_tmp = None
                for _s in _share :
                    #Check body user
                    if self.compare_source(user_info, body, _s) :
                        self.logger.info('Cant share E')
                        return True, 'CaseE'
                    _s_tmp = _s
                return False, _s_tmp
            else :
                _share = None
        return False, None
        
    def compare_source(self, _from, _to, _record):
        if _from['user_id']   == _record['from_user_id']   and \
           _from['tenant_id'] == _record['from_tenant_id'] and \
           _from['domain_id'] == _record['from_domain_id'] and \
           _to['user_id']     == _record['to_user_id']     and \
           _to['tenant_id']   == _record['to_tenant_id']   and \
           _to['domain_id']   == _record['to_domain_id'] :
            return True
        else:
            return False
        
    def recombine_link_body(self, user_info, path):
        return {
            'link_user_id'     : user_info['user_id'],
            'link_user_name'   : user_info['user_name'],
            'link_tenant_id'   : user_info['tenant_id'],
            'link_tenant_name' : user_info['tenant_name'],
            'link_domain_id'   : user_info['domain_id'],
            'link_domain_name' : user_info['domain_name'],
            'link_path'        : path,
        }
    
    @public
    @exception.handle_exceptions()
    def GET(self, user_info, req):
        #check user role
        if not self.check_role(user_info['user_roles'], 's'):
            raise ForbiddenError('Access denied')
        #Get shared list
        data = self.db.find_shared(user_info, action = 'from')
        resp_body = []
        for _d in data:
            _new = {}
            for k, v in _d.iteritems():
                if not (k.startswith('from') or k.startswith('to') \
                        or k.startswith('link')):
                    if k == '_id' :
                        _new['id'] = str(v)
                    else:
                        _new[k] = v
            _new['from'] = _d['from_user_name'] + '@' + _d['from_domain_name']
            _new['to']   = _d['to_user_name'] + '@' + _d['to_domain_name']
            resp_body.append(_new)
        #Record Activty
        self.db.insert_log(user_info, self.action,
                           result   = True,
                           is_share = True)
        return RESP.ok(content = json_dump(resp_body))
        
    @public
    @exception.handle_exceptions()
    def DELETE(self, user_info, req, _id):
        #check user role
        if not self.check_role(user_info['user_roles'], 's'):
            raise ForbiddenError('Access denied')
        #Delete record
        self.db.delete_shared( _id )
        #Record Activty
        self.db.insert_log(user_info, self.action,
                           method   = 'DELETE',
                           result   = 1,
                           is_share = True)
        return RESP.no_content()

    @public
    @exception.handle_exceptions()
    def POST(self, user_info, req):
        '''
        {
            'email' : <target_email>
            'permission' : {
                'write' : True or False
            },
            'file_path'    : file_path,
        }
        '''
        #check user role
        if not self.check_role(user_info['user_roles'], 's'):
            raise ForbiddenError('Access denied')
        #Read body
        body = json.loads(req.body)
        #Check path
        path = body.get('file_path', None)
        if not path:
            raise BadRequestError('Lack file_path')
        else:
            path = self.decode_url(self.check_path(path))
        #Check path is dir or not
        if path.startswith('/shared/'):
            _map_path, _new_path = self.get_share_path(path)
            if not _map_path:
                raise BadRequestError('Can\'t operate this path')
            _body = self.db.find_mathched_shared_path(user_info, _map_path)
        else:
            _resp = self.fileop.get_meta(user_info, path, req)
            if not self.get_result(_resp.status):
                return _resp
            else:
                _body = json.loads(_resp.body)
        body['is_dir'] = _body.get('is_dir', False)
        #Get target info from keystone
        email = body.get('email', None)
        if not email :
            raise BadRequestError('Lack email')
        _email = email.split('@')
        _users = self.ks.get_user(_email[0])['users']
        _user = None
        for _u in _users :
            if _u['email'] == email:
                _user = _u
                break
        if not _user :
            raise BadRequestError('Invaild email')
        else:
            body['domain_name'] = _email[1]
            body['domain_id']   = _user['domain_id']
            body['tenant_name'] = _email[0]
            body['tenant_id']   = _user['tenantId']
            body['user_name']   = _email[0]
            body['user_id']     = _user['id']
        #Check file_path 
        # if this path already is a shared path
        # then subfolder can't sharen to another one
        _res, _link = self.check_shared_path(user_info, body)
        if _res:
            raise BadRequestError('Can\'t share this path : ' + _link)
        if not _link :
            _link = self.recombine_link_body(user_info, body['file_path'])
        #check file_name
        _path = split_path(path)
        _file_name = _path[-1]
        _shared_path = '/shared/' + _file_name
        count = 1
        #Combine query data
        while self.db.check_shared_path(body, _shared_path):
            if body['is_dir']:
                _name = _file_name + ' (' + str(count) + ')'
            else:
                _name = _file_name.split('.', 1)
                if len(_name) > 1 :
                    _name = _name[0] + ' (' + str(count) + ').' + _name[1]
                else :
                    _name = _name[0] + ' (' + str(count) + ')'
            _shared_path = '/shared/' + _name
            count += 1
        #insert shared data
        #TODO comfirm temp is TRUE
        self.db.insert_shared(from_user   = user_info, 
                              to_user     = body,
                              link_user   = _link,
                              permission  = body.get('permission',
                                                     {'write':True}), 
                              file_path   = self.check_path(path),
                              shared_path = _shared_path, 
                              is_dir      = body.get('is_dir', False),
                              confirm     = True)#will be False later
        #Record Activty
        self.db.insert_log(user_info, 
                           self.action,
                           method   = 'POST',
                           to_path  = self.check_path(path),
                           result   = True,
                           is_share = True,
                           notifier = True)
        #Record target activity
        self.db.insert_log(body, 
                           'JoinShareFolder',
                           method    = 'POST',
                           from_path = self.check_path(path),
                           to_path   = _shared_path,
                           result    = True,
                           is_share  = True,
                           notifier  = True)
        return RESP.created()

