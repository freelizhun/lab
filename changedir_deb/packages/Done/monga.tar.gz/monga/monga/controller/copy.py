from monga.controller.base import Controller
from monga.common import response as RESP
from swift.common.utils import public
from monga.common import exception as exception
from monga.common.exception import *
import json

class FileCopyController(Controller):
    server_type = _('FileCopy')

    def __init__(self, app, **kwargs):
        Controller.__init__(self, app)
        self.action = 'FileCopy'

    @public
    @exception.handle_exceptions()
    def POST(self, user_info, req):
        #check user role
        if not self.check_role(user_info['user_roles'], 'w'):
            raise ForbiddenError('Access denied')
        #Get from_path and to_path
        try:
            from_path = self.decode_url(req.GET['from_path'])
            to_path   = self.decode_url(req.GET['to_path'])
        except Exception:
            raise BadRequestError('Lack file path')
        #Check to_path
        to_user, _to_path, is_share = \
            self.check_shared(user_info, to_path, 'write', True)
        #Check from_path
        from_user, _from_path, junk = \
            self.check_shared(user_info, from_path)
        #Pass to_path, from_path, to_user_info, from_user_info
        #Get response from connector
        resp, is_dir, change_size = \
            self.fileop.move(req, _to_path, _from_path, to_user, from_user,
                             is_copy = True)
        if is_share :
            resp.body = self.modfied_shared_contents(resp.body, user_info,
                                                     to_path)
        #Record Used
        if to_user != from_user:
            self.db.update_quota(to_user, change_size)
        #Record Activty
        self.db.insert_log(user_info, self.action, 
                           method    = 'POST',
                           delta     = 'Create',
                           from_path = self.check_path(from_path),
                           to_path   = self.check_path(to_path),
                           is_dir    = is_dir,
                           size      = change_size,
                           result    = self.get_result(resp.status))
        return resp

