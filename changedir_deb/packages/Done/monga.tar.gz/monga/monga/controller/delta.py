from monga.controller.base import Controller
from monga.common import response as RESP
from swift.common.utils import public
from monga.common import exception as exception
from monga.common.exception import *
from monga.common.utils import json_dump
import time, json

class DeltaController(Controller):
    server_type = _('Delta')

    def __init__(self, app, **kwargs):
        Controller.__init__(self, app)
        self.action = 'Delta'

    @public
    @exception.handle_exceptions()
    def POST(self, user_info, req):
        #check user role
        if not self.check_role(user_info['user_roles'], 'r'):
            raise ForbiddenError('Access denied')
        try:
            cursor = req.GET['cursor']
        except Exception:
            cursor = None
        #Set query conditiosn
        query_data = {
            'tenant_id' : user_info['tenant_id'],
            'delta'     : { "$in" : ['Create', 'DELETE']},
            'result'    : True}
        if cursor :
            query_data['updated_time'] = {'$gt' : int(cursor)}
        #Get log data from db
        data = self.db.find_log(query_data)
        entries = []
        count = 0
        #Fit entry data
        for _d in data:
            _e = {
                'size'   : _d['file_size'],
                'action' : _d['action'],
                'delta'  : _d['delta'],
                'is_dir' : _d['is_dir'],
                'update_time' : _d['updated_time'],
            }
            if _d['action'] == 'FileCopy' or _d['action'] == 'FileMove' :
                _e['from_path'] = self.check_path(_d['from_path'])
                _e['to_path']   = self.check_path(_d['to_path'])
            else:
                _e['path'] = self.check_path(_d['to_path'])
            entries.append(_e)
            count += 1
            cursor = _d['updated_time']
            if count == 100 :
                break
        #Has more delta or not
        if count == 100:
            has_more = True
        else: has_more = False
        #Generate resp body
        resp_body = {
            'entries'  : entries,
            'cursor'   : cursor,
            'has_more' : has_more
        }
        #Record Activty
        self.db.insert_log(user_info, self.action,
                           method   = 'POST',
                           result   = True)
        return RESP.ok(content = json_dump(resp_body))
