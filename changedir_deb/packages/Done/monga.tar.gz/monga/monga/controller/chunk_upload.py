from monga.controller.base import Controller
from monga.common import response as RESP
from swift.common.utils import public
from monga.common import exception as exception
from monga.common.exception import *

class ChunkUploadController(Controller):
    server_type = _('ChunkUpload')

    def __init__(self, app, **kwargs):
        Controller.__init__(self, app)
        self.action = 'ChunkUpload'

    @public
    @exception.handle_exceptions()
    def POST(self, user_info, req):
        #check user role
        if not self.check_role(user_info['user_roles'], 'w'):
            raise ForbiddenError('Access denied')
        #define path from
        path = req.headers.get('X-File-Path', None)
        if not path:
            raise BadRequestError('Can\'t find file path')
        else :
            path = self.decode_url(path)
        #Check shared folder
        _user, _path, is_share = \
            self.check_shared(user_info, path, 'write')
        #Check quota
        _quota = int(req.headers.get('X-Tenant-Quota', 5368709120))
        _used = self.db.find_quota(_user).get('used', 0)
        size = req.headers.get('Content-Length', None)
        if not size :
            raise LengthRequiredError()
        else : size = int(size)
        if (_used + size) > _quota:
            raise ExceedQuotaError('Exceed Quota Limit')
        resp, chunk_id = self.fileop.chunk_upload(_user, _path, req)
        #Record Used
        self.db.update_quota(_user, size)
        #Record Activty
        self.db.insert_log(user_info, self.action,
                           method   = 'POST',
                           to_path  = path,
                           size     = size,
                           result   = self.get_result(resp.status),
                           is_share = is_share,
                           is_chunk = True, 
                           chunk_id = chunk_id)
        return resp

