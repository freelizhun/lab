from monga.controller.base import Controller
from monga.common import response as RESP
from swift.common.utils import public
from monga.common import exception as exception
from monga.common.exception import *

class RestoreController(Controller):
    server_type = _('Restore')

    def __init__(self, app, **kwargs):
        Controller.__init__(self, app)
        self.action = 'Restore'

    @public
    @exception.handle_exceptions()
    def POST(self, user_info, req, path):
        #check user role
        if not self.check_role(user_info['user_roles'], 'w'):
            raise ForbiddenError('Access denied')
        #Decode path
        path = self.decode_url(path)
        #Check shared folder
        _user, _path, is_share = \
            self.check_shared(user_info, path, 'write', True)
        #Get response from connector
        resp = self.fileop.restore(_user, _path, req)
        if is_share :
            resp.body = self.modfied_shared_contents(resp.body, user_info, path)
        #Record Activty
        self.db.insert_log(user_info, self.action, 
                           method   = 'POST',
                           delta    = 'Create',
                           to_path  = self.check_path(path),
                           result   = self.get_result(resp.status),
                           is_share = is_share)
        return resp

