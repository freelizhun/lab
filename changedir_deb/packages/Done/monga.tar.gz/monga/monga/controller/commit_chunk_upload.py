from monga.controller.base import Controller
from monga.common import response as RESP
from swift.common.utils import public
from monga.common import exception as exception
from monga.common.exception import *

class CommitChunkUploadController(Controller):
    server_type = _('CommitChunkUpload')

    def __init__(self, app, **kwargs):
        Controller.__init__(self, app)
        self.action = 'CommitChunkUpload'
    @public
    @exception.handle_exceptions()
    def POST(self, user_info, req, path):
        #check user role
        if not self.check_role(user_info['user_roles'], 'w'):
            raise ForbiddenError('Access denied')
        #Check shared folder
        _user, _path, is_share = \
            self.check_shared(user_info, path, 'write')
        resp, chunk_id = self.fileop.commit_chunk_upload(_user, _path, req)
        if is_share :
            resp.body = self.modfied_shared_contents(resp.body, user_info, path)
        #Record Activty
        self.db.insert_log(user_info, self.action,
                           delta    = 'Create',
                           method   = 'POST',
                           to_path  = path,
                           result   = self.get_result(resp.status),
                           is_share = is_share,
                           is_chunk = True, 
                           chunk_id = chunk_id)
        return resp

