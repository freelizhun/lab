from monga.controller.base import Controller
from monga.common import response as RESP
from swift.common.utils import public
from monga.common import exception as exception
from monga.common.exception import *

class FileCreateFolderController(Controller):
    server_type = _('FileCreateFolder')

    def __init__(self, app, **kwargs):
        Controller.__init__(self, app)
        self.action = 'CreateFolder'

    @public
    @exception.handle_exceptions()
    def POST(self, user_info, req):
        #check user role
        if not self.check_role(user_info['user_roles'], 'w'):
            raise ForbiddenError('Access denied')
        #Get from_path and to_path
        try:
            path = self.decode_url((req.GET['path']))
        except Exception:
            raise BadRequestError('Lack file path')
        #Check shared folder
        _user, _path, is_share = \
            self.check_shared(user_info, path, 'write')
        resp = self.fileop.create_folder(_user, _path, req)
        if is_share :
            resp.body = self.modfied_shared_contents(resp.body, user_info, path)
        #Record Activty
        self.db.insert_log(user_info, self.action,
                           method   = 'POST',
                           delta    = 'Create',
                           to_path  = self.check_path(path),
                           is_dir   = True,
                           result   = self.get_result(resp.status),
                           is_share = is_share)
        return resp

