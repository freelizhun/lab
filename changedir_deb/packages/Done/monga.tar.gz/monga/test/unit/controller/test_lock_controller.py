from monga.controller.lock import LockController
from monga.common.utils import json_dump
from monga.common.exception import *
import unittest
from utils import *
import json

class TestLockController(unittest.TestCase):

    def setUp(self):
        _c = LockController
        _c.__init__ = fake_init
        self._c = _c()
        self._user = {
            'user_id'     : 'a',
            'user_name'   : 'b',
            'tenant_id'   : 'c',
            'tenant_name' : 'd',
            'domain_id'   : 'e',
            'domain_name' : 'f',
        }
        
    def test_POST(self):
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, object, '/a')
        self.assertEquals(201 , _resp.status_int)
        
    def test_POST_role_fail_case(self):
        _user = self._user
        _user['user_roles'] = ['guest']
        _resp = self._c.POST(_user, object, '/a')
        self.assertEquals(403 , _resp.status_int)
        
    def test_DELETE(self):
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.DELETE(_user, object, '/true')
        self.assertEquals(204 , _resp.status_int)
        
    def test_DELETE_role_fail_case(self):
        _user = self._user
        _user['user_roles'] = ['guest']
        _resp = self._c.DELETE(_user, object, '/true')
        self.assertEquals(403 , _resp.status_int)
        
    def test_DELETE_fail(self):
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.DELETE(_user, object, '/false')
        self.assertEquals(400 , _resp.status_int)

if __name__ == '__main__':
    unittest.main()
