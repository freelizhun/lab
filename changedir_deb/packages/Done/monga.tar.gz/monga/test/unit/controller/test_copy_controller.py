from monga.controller.copy import FileCopyController
from monga.common.utils import json_dump
from monga.common.exception import *
import unittest
from utils import *
import json

class TestFileCopyController(unittest.TestCase):

    def setUp(self):
        _c = FileCopyController
        _c.__init__ = fake_init
        self._c = _c()
        self._user = {
            'user_id'     : 'a',
            'user_name'   : 'b',
            'tenant_id'   : 'c',
            'tenant_name' : 'd',
            'domain_id'   : 'e',
            'domain_name' : 'f',
        }
        
    def test_POST(self):
        _object = FakeRequest(GET = {'from_path': '/a',
                                     'to_path' : '/b'})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object)
        self.assertEquals(201 , _resp.status_int)
        
    def test_POST_with_guest_role(self):
        _object = FakeRequest(GET = {'from_path': '/a',
                                     'to_path' : '/b'})
        _user = self._user
        _user['user_roles'] = ['guest']
        _resp = self._c.POST(_user, _object)
        self.assertEquals(403 , _resp.status_int)
        
    def test_POST_without_path(self):
        _object = FakeRequest(GET = {'from_path': '/a'})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object)
        self.assertEquals(400 , _resp.status_int)
        
    def test_POST_with_shared_from_path(self):
        _object = FakeRequest(GET = {'from_path': '/shared/a',
                                     'to_path' : '/a'})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object)
        self.assertEquals(201 , _resp.status_int)
    
    def test_POST_with_shared_to_path(self):
        _object = FakeRequest(GET = {'from_path': '/a',
                                     'to_path' : '/shared/a'})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object)
        self.assertEquals(201 , _resp.status_int)
        
    def test_POST_with_shared_paths(self):
        _object = FakeRequest(GET = {'from_path': '/shared/a',
                                     'to_path' : '/shared/a'})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object)
        self.assertEquals(201 , _resp.status_int)
if __name__ == '__main__':
    unittest.main()
