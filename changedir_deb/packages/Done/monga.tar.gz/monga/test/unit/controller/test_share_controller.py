from monga.controller.share import ShareController
from monga.common.utils import json_dump
from monga.common.exception import *
import unittest
from utils import *
import json

class TestShareController(unittest.TestCase):

    def setUp(self):
        _c = ShareController
        _c.__init__ = fake_init
        self._c = _c()
        self._user = {
            'user_id'     : 'a',
            'user_name'   : 'b',
            'tenant_id'   : 'c',
            'tenant_name' : 'd',
            'domain_id'   : 'e',
            'domain_name' : 'f',
        }
        
    def test_GET(self):
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.GET(_user, object)
        self.assertEquals(200 , _resp.status_int)
        
    def test_GET_with_wrong_role(self):
        _user = self._user
        _user['user_roles'] = ['guest']
        _resp = self._c.GET(_user, object)
        self.assertEquals(403 , _resp.status_int)
        
    def test_DELETE(self):
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.DELETE(_user, object, 'a')
        self.assertEquals(204 , _resp.status_int)
        
    def test_DELETE_with_wrong_role(self):
        _user = self._user
        _user['user_roles'] = ['guest']
        _resp = self._c.DELETE(_user, object, 'a')
        self.assertEquals(403 , _resp.status_int)
        
    def test_PUT(self):
        _object = FakeRequest(body = json.dumps({'expired_time' : '2011.1.1',
                                                 'password' : 'password'}))
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.PUT(_user, _object, True)
        self.assertEquals(201 , _resp.status_int)
        
    def test_PUT_with_wrong_role(self):
        _user = self._user
        _user['user_roles'] = ['guest']
        _resp = self._c.PUT(_user, object, True)
        self.assertEquals(403 , _resp.status_int)
        
    def test_PUT_without_pwd(self):
        _object = FakeRequest(body = json.dumps({'expired_time' : '2011.1.1'}))
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.PUT(_user, _object, True)
        self.assertEquals(201 , _resp.status_int)
        
    def test_PUT_without_expired(self):
        _object = FakeRequest(body = json.dumps({'password' : 'password'}))
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.PUT(_user, _object, True)
        self.assertEquals(201 , _resp.status_int)
        
    def test_PUT_record_not_exist(self):
        _object = FakeRequest(body = json.dumps({'password' : 'password'}))
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.PUT(_user, _object, 'NotExist')
        self.assertEquals(404 , _resp.status_int)
        
    def test_PUT_mongo_error(self):
        _object = FakeRequest(body = json.dumps({'password' : 'password'}))
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.PUT(_user, _object, 2)
        self.assertEquals(500 , _resp.status_int)
        
    def test_POST(self):
        _object = FakeRequest(headers = {'X-Public-Password' : 'password',
                                         'X-Expired-Time' : '2011.1.1'})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object, '/a')
        self.assertEquals(201 , _resp.status_int)
        
    def test_POST_with_wrong_role(self):
        _user = self._user
        _user['user_roles'] = ['guest']
        _resp = self._c.POST(_user, object, '/a')
        self.assertEquals(403 , _resp.status_int)
        
    def test_POST_with_wrong_path(self):
        _object = FakeRequest(headers = {'X-Public-Password' : 'password',
                                         'X-Expired-Time' : '2011.1.1'})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object, '/not_exist')
        self.assertEquals(404 , _resp.status_int)
        
    def test_POST_without_pwd(self):
        _object = FakeRequest(headers = {'X-Expired-Time' : '2011.1.1'})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object, '/a')
        self.assertEquals(201 , _resp.status_int)
        
    def test_POST_without_expired_time(self):
        _object = FakeRequest(headers = {'X-Public-Password' : 'password'})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object, '/a')
        self.assertEquals(201 , _resp.status_int)
        
    def test_POST_without_extra_attrs(self):
        _object = FakeRequest(headers = {})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object, '/a')
        self.assertEquals(201 , _resp.status_int)
        
if __name__ == '__main__':
    unittest.main()
