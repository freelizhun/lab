from monga.controller.search import SearchController
from monga.common.utils import json_dump
from monga.common.exception import *
import unittest
from utils import *
import json

class TestSearchController(unittest.TestCase):

    def setUp(self):
        _c = SearchController
        _c.__init__ = fake_init
        self._c = _c()
        self._user = {
            'user_id'     : 'a',
            'user_name'   : 'b',
            'tenant_id'   : 'c',
            'tenant_name' : 'd',
            'domain_id'   : 'e',
            'domain_name' : 'f',
        }
        
    def test_GET(self):
        _object = FakeRequest(GET = {'query' : 'aa'})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.GET(_user, _object)
        self.assertEquals(200 , _resp.status_int)
        
    def test_POST(self):
        _object = FakeRequest(GET = {'query' : 'aa'})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object)
        self.assertEquals(200 , _resp.status_int)
        
    def test_GET_with_wrong_role(self):
        _object = FakeRequest(GET = {'query' : 'aa'})
        _user = self._user
        _user['user_roles'] = ['guestt']
        _resp = self._c.GET(_user, _object)
        self.assertEquals(403 , _resp.status_int)
        
    def test_GET_without_query(self):
        _object = FakeRequest()
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.GET(_user, object)
        self.assertEquals(400 , _resp.status_int)
        
    def test_GET_with_path(self):
        _object = FakeRequest(GET = {'query' : 'aa'})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.GET(_user, _object, '/a')
        self.assertEquals(200 , _resp.status_int)
    
if __name__ == '__main__':
    unittest.main()
