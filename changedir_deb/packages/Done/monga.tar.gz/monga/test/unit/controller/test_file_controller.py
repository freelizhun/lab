from monga.controller.files import FileController
from monga.common.utils import json_dump
from monga.common.exception import *
import unittest
from utils import *
import json

class TestFileController(unittest.TestCase):

    def setUp(self):
        _c = FileController
        _c.__init__ = fake_init
        self._c = _c()
        self._user = {
            'user_id'     : 'a',
            'user_name'   : 'b',
            'tenant_id'   : 'c',
            'tenant_name' : 'd',
            'domain_id'   : 'e',
            'domain_name' : 'f',
        }

    def test_GET(self):
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.GET(_user, object, '/a')
        self.assertEquals(200 , _resp.status_int)

    def test_GET_with_shared_folder(self):
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.GET(_user, object, '/shared/a')
        self.assertEquals(200 , _resp.status_int)
        
    def test_GET_with_not_exist_role(self):
        _user = self._user
        _user['user_roles'] = ['role']
        _resp = self._c.GET(_user, object, '/a')
        self.assertEquals(403 , _resp.status_int)
        
    def test_PUT(self):
        _object = FakeRequest(headers = {'X-Tenant-Quota':100000,
                                         'Content-Length' : 100})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.PUT(_user, _object, '/a')
        self.assertEquals(201 , _resp.status_int)
        
    def test_POST(self):
        _object = FakeRequest(headers = {'X-Tenant-Quota':100000,
                                         'Content-Length' : 100})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object, '/a')
        self.assertEquals(201 , _resp.status_int)
        
    def test_POST_with_shared_folder(self):
        _object = FakeRequest(headers = {'X-Tenant-Quota':100000,
                                         'Content-Length' : 100})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object, '/shared/a')
        self.assertEquals(201 , _resp.status_int)
        
    def test_POST_with_guest_role(self):
        _object = FakeRequest(headers = {'X-Tenant-Quota':100000,
                                         'Content-Length' : 100})
        _user = self._user
        _user['user_roles'] = ['guest']
        _resp = self._c.POST(_user, _object, '/a')
        self.assertEquals(403 , _resp.status_int)
        
    def test_POST_without_len(self):
        _object = FakeRequest(headers = {'X-Tenant-Quota':100000})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object, '/a')
        self.assertEquals(411 , _resp.status_int)
        
    def test_POST_exceed_quota(self):
        _object = FakeRequest(headers = {'X-Tenant-Quota':10,
                                         'Content-Length' : 100})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object, '/a')
        self.assertEquals(403 , _resp.status_int)
        
if __name__ == '__main__':
    unittest.main()
