from monga.controller.base import Controller
from monga.common.utils import json_dump
from monga.common.exception import *
import unittest
from utils import *
import json

class TestBaseController(unittest.TestCase):

    def setUp(self):
        _c = Controller
        _c.__init__ = fake_init
        self._c = _c()

    def test_encode_url(self):
        self.assertEquals('%20', self._c.encode_url(' '))
        
    def test_decode_url(self):
        self.assertEquals(' ', self._c.decode_url('%20'))
        
    def test_check_role_admin(self):
        _roles = ['admin']
        self.assertEquals(True, self._c.check_role(_roles, 'w'))
        self.assertEquals(True, self._c.check_role(_roles, 's'))
        self.assertEquals(True, self._c.check_role(_roles, 'r'))
        
    def test_check_role_member(self):
        _roles = ['member']
        self.assertEquals(True, self._c.check_role(_roles, 'w'))
        self.assertEquals(False, self._c.check_role(_roles, 's'))
        self.assertEquals(True, self._c.check_role(_roles, 'r'))
        
    def test_check_role_guest(self):
        _roles = ['guest']
        self.assertEquals(False, self._c.check_role(_roles, 'w'))
        self.assertEquals(False, self._c.check_role(_roles, 's'))
        self.assertEquals(True, self._c.check_role(_roles, 'r'))
        
    def test_check_role_none(self):
        _roles = ['guestt']
        self.assertEquals(False, self._c.check_role(_roles, 'w'))
        self.assertEquals(False, self._c.check_role(_roles, 's'))
        self.assertEquals(False, self._c.check_role(_roles, 'r'))
        
    def test_get_result(self):
        self.assertEquals(True, self._c.get_result('200 OK'))
        self.assertEquals(False, self._c.get_result('400 BadRequest'))
        self.assertEquals(False, self._c.get_result('500 InternalServerError'))
        
    def test_get_shared_path(self):
        self.assertEquals('/shared/a', self._c.get_shared_path('/shared/a/b'))
        self.assertEquals('/shared/a', self._c.get_shared_path('/shared/a/b/c'))
        
    def test_get_share_path(self):
        _path, _extra = self._c.get_share_path('/shared/a')
        self.assertEquals('/shared/a', _path)
        self.assertEquals(None, _extra)
        _path, _extra = self._c.get_share_path('shared/a')
        self.assertEquals('/shared/a', _path)
        self.assertEquals(None, _extra)
        _path, _extra = self._c.get_share_path('shared/a/b')
        self.assertEquals('/shared/a', _path)
        self.assertEquals('/b', _extra)
        _path, _extra = self._c.get_share_path('shared/a/b/c/d')
        self.assertEquals('/shared/a', _path)
        self.assertEquals('/b/c/d', _extra)
        
    def test_check_path(self):
        self.assertEquals('/shared/a', self._c.check_path('/shared/a'))
        self.assertEquals('/shared/a', self._c.check_path('shared/a'))
        
    def test_is_shared(self):
        self.assertEquals(True , self._c.is_shared('/shared/a'))
        self.assertEquals(False , self._c.is_shared('/aa/a'))
        
    def test_get_real_user(self):
        _data = {
            'link_user_id'     : 'a',
            'link_user_name'   : 'b',
            'link_tenant_id'   : 'c',
            'link_tenant_name' : 'd',
            'link_domain_id'   : 'e',
            'link_domain_name' : 'f',
        }
        _data2 = {
            'user_id'     : 'a',
            'user_name'   : 'b',
            'tenant_id'   : 'c',
            'tenant_name' : 'd',
            'domain_id'   : 'e',
            'domain_name' : 'f',
        }
        self.assertEquals(_data2 , self._c.get_real_user(_data))
        
    def test_check_shared(self):
        _user = {
            'user_id'     : 'a',
            'user_name'   : 'b',
            'tenant_id'   : 'c',
            'tenant_name' : 'd',
            'domain_id'   : 'e',
            'domain_name' : 'f',
        }
        real_user = {
            'user_id'     : 'm',
            'user_name'   : 'n',
            'tenant_id'   : 'o',
            'tenant_name' : 'p',
            'domain_id'   : 'q',
            'domain_name' : 'r',
        }
        #Path not shared
        res_user, res_path, res_share = self._c.check_shared(_user, '/a')
        self.assertEquals(_user , res_user)
        self.assertEquals('/a' , res_path)
        self.assertEquals(False , res_share)
        #Path is shared
        res_user, res_path, res_share = self._c.check_shared(_user, '/shared/a')
        self.assertEquals(real_user , res_user)
        self.assertEquals('/s' , res_path)
        self.assertEquals(True , res_share)
        #Path is shared
        res_user, res_path, res_share = self._c.check_shared(_user, 
                                                             '/shared/a/d')
        self.assertEquals(real_user , res_user)
        self.assertEquals('/s/d' , res_path)
        self.assertEquals(True , res_share)
        #Path is locked
        res_user, res_path, res_share = self._c.check_shared(_user, 
                                                             '/shared/a/d',
                                                             lock = True)
        self.assertEquals(real_user , res_user)
        self.assertEquals('/s/d' , res_path)
        self.assertEquals(True , res_share)
        #permission
        res_user, res_path, res_share = self._c.check_shared(_user, 
                                                             '/shared/a/d',
                                                             'write')
        self.assertEquals(real_user , res_user)
        self.assertEquals('/s/d' , res_path)
        self.assertEquals(True , res_share)
        try: 
            self._c.check_shared(_user, '/shared')
        except BadRequestError:
            pass
            
    def test_modfied_shared_contents(self):
        ref = {
            'path' : '/s',
            'contents' : [{'path':'/s/obj'},{'path':'/s/dir'}]
        }
        res = {
            'path' : '/shared/a',
            'contents' : [{'path':'/shared/a/obj'},{'path':'/shared/a/dir'}]
        }
        _res = self._c.modfied_shared_contents(json.dumps(ref), None, 
                                               '/shared/a')
        self.assertEquals(json.loads(_res) , res)
        
if __name__ == '__main__':
    unittest.main()
