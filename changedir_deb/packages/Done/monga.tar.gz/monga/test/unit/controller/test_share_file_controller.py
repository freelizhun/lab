from monga.controller.share_file import ShareFileController
from monga.common.utils import json_dump
from monga.common.exception import *
import unittest
from utils import *
import json

class TestShareFileController(unittest.TestCase):

    def setUp(self):
        _c = ShareFileController
        _c.__init__ = fake_init
        self._c = _c()
        self._user = {
            'user_id'     : 'a',
            'user_name'   : 'b',
            'tenant_id'   : 'c',
            'tenant_name' : 'd',
            'domain_id'   : 'e',
            'domain_name' : 'f',
        }
        self.body = {
            'email' : 'test@test',
            'permission' : {
                'write' : True
            },
            'file_path'    : '/pass',
        }
        
    def test_GET(self):
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.GET(_user, object)
        self.assertEquals(200 , _resp.status_int)
        
    def test_GET_with_wrong_role(self):
        _user = self._user
        _user['user_roles'] = ['guest']
        _resp = self._c.POST(_user, object)
        self.assertEquals(403 , _resp.status_int)
        
    def test_DELETE(self):
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.DELETE(_user, object, 'a')
        self.assertEquals(204 , _resp.status_int)
        
    def test_DELETE_with_wrong_role(self):
        _user = self._user
        _user['user_roles'] = ['guest']
        _resp = self._c.DELETE(_user, object, 'a')
        self.assertEquals(403 , _resp.status_int)
        
    def test_POST(self):
        _object = FakeRequest(body = json.dumps(self.body))
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object)
        self.assertEquals(201 , _resp.status_int)
        
    def test_POST_with_wrong_role(self):
        _object = FakeRequest(body = json.dumps(self.body))
        _user = self._user
        _user['user_roles'] = ['guest']
        _resp = self._c.POST(_user, _object)
        self.assertEquals(403 , _resp.status_int)
        
    def test_POST_without_path(self):
        _body = self.body.copy()
        _body['file_path'] = None
        _object = FakeRequest(body = json.dumps(_body))
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object)
        self.assertEquals(400 , _resp.status_int)
        
    def test_POST_with_wrong_shared_path(self):
        _body = self.body.copy()
        _body['file_path'] = '/shared/'
        _object = FakeRequest(body = json.dumps(_body))
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object)
        self.assertEquals(400 , _resp.status_int)
        
    def test_POST_with_correct_shared_path(self):
        _body = self.body.copy()
        _body['file_path'] = '/shared/pass'
        _object = FakeRequest(body = json.dumps(_body))
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object)
        self.assertEquals(201 , _resp.status_int)
        
    def test_POST_without_mail(self):
        _body = self.body.copy()
        _body['email'] = None
        _object = FakeRequest(body = json.dumps(_body))
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object)
        self.assertEquals(400 , _resp.status_int)
        
    def test_POST_with_wrong_mail(self):
        _body = self.body.copy()
        _body['email'] = 'fail@test'
        _object = FakeRequest(body = json.dumps(_body))
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object)
        self.assertEquals(400 , _resp.status_int)
        
    def test_POST_with_check_shared_path_case_A(self):
        _body = self.body.copy()
        _body['file_path'] = '/caseA'
        _object = FakeRequest(body = json.dumps(_body))
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object)
        self.assertEquals(400 , _resp.status_int)
        
    def test_POST_with_check_shared_path_case_B(self):
        _body = self.body.copy()
        _body['file_path'] = '/caseB'
        _object = FakeRequest(body = json.dumps(_body))
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object)
        self.assertEquals(400 , _resp.status_int)
        
    def test_POST_with_check_shared_path_case_C(self):
        _body = self.body.copy()
        _body['file_path'] = '/caseC/D/E/F'
        _object = FakeRequest(body = json.dumps(_body))
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object)
        self.assertEquals(400 , _resp.status_int)
        
    def test_POST_with_check_shared_path_case_D(self):
        _body = self.body.copy()
        _body['file_path'] = '/caseD/D/E/F'
        _object = FakeRequest(body = json.dumps(_body))
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object)
        self.assertEquals(400 , _resp.status_int)
        
    def test_POST_with_check_shared_path_case_E(self):
        _body = self.body.copy()
        _body['file_path'] = '/caseD'
        _object = FakeRequest(body = json.dumps(_body))
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object)
        self.assertEquals(400 , _resp.status_int)
        
if __name__ == '__main__':
    unittest.main()
