#!/usr/bin/env python
from monga.connector.exception import InvalidParameter
from monga.connector.path import MongaSystemPath as spath
from monga.connector.path import MongaTenantPath as tpath
import unittest


class TestMongaSystemPath(unittest.TestCase):

    def test_bad_input(self):
        self._bad_input_path_to_binary_folder()
        self._bad_input_path_to_chunk()
        self._bad_input_get_system_relative_path()

    def _bad_input_path_to_binary_folder(self):
        #path_to_binary_folder(cls, access_point)
        f = spath.path_to_binary_folder
        self.assertRaises(InvalidParameter, f, None)

    def _bad_input_path_to_chunk(self):
        #def path_to_chunk(cls, access_point, chunk_id)
        f = spath.path_to_chunk
        self.assertRaises(InvalidParameter, f, None, None)
        self.assertRaises(InvalidParameter, f, '/Fake', None)
        self.assertRaises(InvalidParameter, f, None, 'Fake')

    def _bad_input_get_system_relative_path(self):
        #def get_system_relative_path(cls, access_point, access_path)
        f = spath.get_system_relative_path
        self.assertRaises(InvalidParameter, f, None, None)
        self.assertRaises(InvalidParameter, f, '/Fake', None)
        self.assertRaises(InvalidParameter, f, None, 'Fake')


class TestMongaTenantPath(unittest.TestCase):

    def test_bad_input(self):
        self._bad_input_path_to_version_folder()
        self._bad_input_path_to_home_folder()
        self._bad_input_path_to_trash_folder()

    def _bad_input_path_to_version_folder(self):
        #def path_to_version_folder(cls, access_point, tenant_id, file_path)
        f = tpath.path_to_version_folder
        self.assertRaises(InvalidParameter, f, None, None)
        self.assertRaises(InvalidParameter, f, '/Fake', None)
        self.assertRaises(InvalidParameter, f, None, 'Fake')
#        self.assertRaises(InvalidParameter, f, None, None, None)
#        self.assertRaises(InvalidParameter, f, 'fake', None, None)
#        self.assertRaises(InvalidParameter, f, None, 'fake', None)
#        self.assertRaises(InvalidParameter, f, None, None, 'fake')
#        self.assertRaises(InvalidParameter, f, None, 'fake', 'fake')
#        self.assertRaises(InvalidParameter, f, 'fake', None, 'fake')
#        self.assertRaises(InvalidParameter, f, 'fake', 'fake', None)

    def _bad_input_path_to_home_folder(self):
        #def path_to_home_folder(cls, access_point, tenant_id)
        f = tpath.path_to_home_folder
        self.assertRaises(InvalidParameter, f, None, None)
        self.assertRaises(InvalidParameter, f, '/Fake', None)
        self.assertRaises(InvalidParameter, f, None, 'Fake')

    def _bad_input_path_to_trash_folder(self):
        #def path_to_trash_folder(cls, access_point, tenant_id):
        f = tpath.path_to_trash_folder
        self.assertRaises(InvalidParameter, f, None, None)
        self.assertRaises(InvalidParameter, f, '/Fake', None)
        self.assertRaises(InvalidParameter, f, None, 'Fake')
