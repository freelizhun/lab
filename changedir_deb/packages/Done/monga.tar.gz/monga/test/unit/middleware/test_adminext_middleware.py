import unittest
from time import time
from swift.common.swob import Request, Response
from monga.middleware.admin_extension import AdminExtMiddleware
from utils import *

_object = AdminExtMiddleware
_object.__init__ = fake_init

def filter_factory(global_conf, **local_conf):
    conf = global_conf.copy()
    conf.update(local_conf)
    def exten_filter(app):
        return _object(app, conf)
    return exten_filter

class TestAdminExtMiddleware(unittest.TestCase):

    def setUp(self):
        self.conf = dict(test='test')
        self.admin = filter_factory(self.conf)(FakeApp())

    def _make_request(self, path, cache = True, **kwargs):
        req = Request.blank(path, **kwargs)
        if cache :
            req.environ['swift.cache'] = FakeMemcache()
        return req
    
    def test_get_used_with_wrong_token(self):
        req = self._make_request('/v1/used/tenant',
                environ={'REQUEST_METHOD': 'GET'},
                headers={'X-Auth-Token': 'ADMINN'})
        resp = req.get_response(self.admin)
        self.assertEquals(resp.status_int, 401)
        
    def test_get_used_without_token(self):
        req = self._make_request('/v1/used/tenant',
                environ={'REQUEST_METHOD': 'GET'})
        resp = req.get_response(self.admin)
        self.assertEquals(resp.status_int, 401)
        
    def test_get_used_all(self):
        req = self._make_request('/v1/used',
                environ={'REQUEST_METHOD': 'GET'},
                headers={'X-Auth-Token': 'ADMIN'})
        resp = req.get_response(self.admin)
        self.assertEquals(resp.status_int, 200)
        
    def test_get_used_with_specified_tenant(self):
        req = self._make_request('/v1/used/tenant',
                environ={'REQUEST_METHOD': 'GET'},
                headers={'X-Auth-Token': 'ADMIN'})
        resp = req.get_response(self.admin)
        self.assertEquals(resp.status_int, 200)

    def test_get_used_with_wrong_url(self):
        req = self._make_request('/v1/used/tenant/a/a/a/a',
                environ={'REQUEST_METHOD': 'GET'},
                headers={'X-Auth-Token': 'ADMIN'})
        resp = req.get_response(self.admin)
        self.assertEquals(resp.status_int, 404)
        
    def test_delete_tenant(self):
        req = self._make_request('/v1/delete/tenant',
                environ={'REQUEST_METHOD': 'DELETE'},
                headers={'X-Auth-Token': 'ADMIN'})
        resp = req.get_response(self.admin)
        self.assertEquals(resp.status_int, 204)
        
    def test_delete_tenant_with_wrong_path(self):
        req = self._make_request('/v1/delete/tenant/a/a/',
                environ={'REQUEST_METHOD': 'DELETE'},
                headers={'X-Auth-Token': 'ADMIN'})
        resp = req.get_response(self.admin)
        self.assertEquals(resp.status_int, 404)
        
    def test_delete_tenant_with_wrong_token(self):
        req = self._make_request('/v1/delete/tenant',
                environ={'REQUEST_METHOD': 'DELETE'},
                headers={'X-Auth-Token': 'ADMINN'})
        resp = req.get_response(self.admin)
        self.assertEquals(resp.status_int, 401)

    def test_delete_tenant_without_token(self):
        req = self._make_request('/v1/delete/tenant',
                environ={'REQUEST_METHOD': 'DELETE'})
        resp = req.get_response(self.admin)
        self.assertEquals(resp.status_int, 401)
        
    def test_pass_case(self):
        req = self._make_request('/v1/files/tenant',
                environ={'REQUEST_METHOD': 'DELETE'},
                headers={'X-Auth-Token': 'ADMINN'})
        resp = req.get_response(self.admin)
        self.assertEquals(resp.status_int, 404)
        
if __name__ == '__main__':
    unittest.main()
