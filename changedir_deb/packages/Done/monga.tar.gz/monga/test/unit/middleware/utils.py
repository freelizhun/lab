from contextlib import contextmanager
from swift.common.swob import Request, Response
from monga.common import response as RESP
import json

class FakeKS():
    def __init__(self, url = None, token = None):
        pass
        
    def get_tenant(self, junk):
        return {'quota' : 100}
        
class FakeLogger():
    def info(self, junk): pass
    
    def increment(self, junk) : pass
    
class FakeMongo():
    def insert_log(self, user_info, action, method = 'GET', from_path = None, 
                   to_path = None, size = 0, is_chunk = False, is_dir = False,
                   chunk_id = None, is_share = False, result = True,
                   delta = None, notifier = False):
        return 
        
    def find_dlink(self, junk):
        if junk['match_url'] == '/v1/links/path_not_exist' :
            return None
        else :
            return {
                '_id' : 'id',
                'public_url' : 'url',
                'expired_tag' : 'expires',
                'file_path' : 'path',
                'pwd' : 'pwd',
            }
         
    def find_quotas(self):
        return [{'_id':'id'},{'_id':'id'},{'_id':'id'}]
        
    def find_quota(self, junk):
        return {'_id' : 'id'}
        
class FakeFileOP():
    def __init__(self, logger, conf):
        self.meta_body = {
            "bytes": 0, 
            "contents": [
                {
                    "bytes": 879394, 
                    "compress": False, 
                    "encrypt": False, 
                    "icon": "page_white_acrobat", 
                    "is_dir": False, 
                    "modified": "Fri, 10 May 2013 02:03:48 +0000", 
                    "mtime": "Wed, 08 May 2013 08:26:08 +0000", 
                    "path": "/TN/Chrysanthemum.jpg", 
                    "rev": "d9d10a58ff63c243fc0e527feccc58d0", 
                    "root": "File Cruiser", 
                    "shared_flag": False, 
                    "size": "858.0 KB", 
                    "store_bytes": 879394, 
                    "store_size": "858.0 KB", 
                    "thumb_exists": False
                }, 
                {
                    "bytes": 0, 
                    "hash": "5ceb6fed399a1d989cc7decbc628d895", 
                    "icon": "folder_public", 
                    "is_dir": True, 
                    "modified": "Tue, 14 May 2013 14:52:27 +0000", 
                    "path": "/TN/YES", 
                    "rev": "5ceb6fed399a1d989cc7decbc628d895", 
                    "root": "File Cruiser", 
                    "shared_flag": False, 
                    "size": "0 Bytes", 
                    "thumb_exists": False
                }
            ], 
            "hash": "6e3f35d21c954c4f3d3b29a4d6a8cdcd", 
            "icon": "folder_public", 
            "is_dir": True, 
            "modified": "Tue, 14 May 2013 17:09:59 +0000", 
            "path": "/TN", 
            "rev": "6e3f35d21c954c4f3d3b29a4d6a8cdcd", 
            "root": "File Cruiser", 
            "shared_flag": True, 
            "size": "0 Bytes", 
            "thumb_exists": False
        }
        self.meta_body2 = {
                    "bytes": 879394, 
                    "compress": False, 
                    "encrypt": False, 
                    "icon": "page_white_acrobat", 
                    "is_dir": False, 
                    "modified": "Fri, 10 May 2013 02:03:48 +0000", 
                    "mtime": "Wed, 08 May 2013 08:26:08 +0000", 
                    "path": "/TN/Chrysanthemum.jpg", 
                    "rev": "d9d10a58ff63c243fc0e527feccc58d0", 
                    "root": "File Cruiser", 
                    "shared_flag": False, 
                    "size": "858.0 KB", 
                    "store_bytes": 879394, 
                    "store_size": "858.0 KB", 
                    "thumb_exists": False
                }
        
    def get_meta(self, junk, junk2, junk3):
        if junk3.path == '/v1/links/file_not_exist' :
            return RESP.not_found('not found')
        elif junk3.path == '/v1/links/list_subfolder_case':
            return RESP.ok(content = json.dumps(self.meta_body))
        else :
            return RESP.ok(content = json.dumps(self.meta_body2))
        
    def downloadData(self, junk, junk2, junk3):
        return RESP.ok()
        
    def deletetenant(self, junk, junk2):
        return 
        
class FakeMemcache(object):

    def __init__(self):
        self.store = {}

    def get(self, key):
        return self.store.get(key)

    def set(self, key, value, timeout=0):
        self.store[key] = value
        return True

    def incr(self, key, timeout=0):
        self.store[key] = self.store.setdefault(key, 0) + 1
        return self.store[key]

    @contextmanager
    def soft_lock(self, key, timeout=0, retries=5):
        yield True

    def delete(self, key):
        try:
            del self.store[key]
        except Exception:
            pass
        return True

class FakeApp(object):

    def __init__(self, status_headers_body_iter=None):
        self.calls = 0
        self.status_headers_body_iter = status_headers_body_iter
        if not self.status_headers_body_iter:
            self.status_headers_body_iter = iter([('404 NotFound', {}, '')])
        

    def __call__(self, env, start_response):
        env['wsgi.input'] = ['a']
        self.request = Request.blank('', environ=env)
        if 'swift.authorize' in env:
            resp = env['swift.authorize'](self.request)
            if resp:
                return resp(env, start_response)
        status, headers, body = self.status_headers_body_iter.next()
        return Response(status=status, headers=headers,
                        body=body)(env, start_response)
                        
def fake_init(self, app, conf):
    self.app = app
    self.auth_url = ''
    self.auth_token = 'ADMIN'
    self.default_quota = 5368709120
    self.cache_timeout = 3600
    self.ks = FakeKS()
    self.logger = FakeLogger()
    self.mongo_path = 'localhost'
    self.mongo_port = 27017
    self.db  = FakeMongo()
    self.fileop = FakeFileOP
    self.conf = conf
