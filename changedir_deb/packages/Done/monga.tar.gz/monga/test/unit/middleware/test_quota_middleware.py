import unittest
from time import time
from swift.common.swob import Request, Response
from monga.middleware.quota import Quota
from utils import *

_object = Quota
_object.__init__ = fake_init

def filter_factory(global_conf, **local_conf):
    conf = global_conf.copy()
    conf.update(local_conf)
    def exten_filter(app):
        return _object(app, conf)
    return exten_filter

class TestQuotaMiddleware(unittest.TestCase):

    def setUp(self):
        self.conf = dict(test='test')
        app = FakeApp(iter([('200 OK', {}, '')]))
        self.quota = filter_factory(self.conf)(app)

    def _make_request(self, path, cache = True):
        req = Request.blank(path)
        if cache :
            req.environ['swift.cache'] = FakeMemcache()
        req.environ['HTTP_X_PROJECT_ID'] = 'tenant_id'
        return req
        
    def test_quota(self):
        req = self._make_request('/v1/test')
        resp = req.get_response(self.quota)
        self.assertEquals(resp.status_int, 200)
        
    def test_quota_without_cache(self):
        req = self._make_request('/v1/test', False)
        resp = req.get_response(self.quota)
        self.assertEquals(resp.status_int, 200)

if __name__ == '__main__':
    unittest.main()
