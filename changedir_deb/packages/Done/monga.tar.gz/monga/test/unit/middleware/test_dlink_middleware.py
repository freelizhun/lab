import unittest
from time import time
from swift.common.swob import Request, Response
from monga.middleware.direct_link import DirectLinkMiddleware
from utils import *

_object = DirectLinkMiddleware
_object.__init__ = fake_init

def filter_factory(global_conf, **local_conf):
    conf = global_conf.copy()
    conf.update(local_conf)
    def exten_filter(app):
        return _object(app, conf)
    return exten_filter

class TestDirectLinkMiddleware(unittest.TestCase):

    def setUp(self):
        self.conf = dict(test='test')
        self.dlink = filter_factory(self.conf)(FakeApp())

    def _make_request(self, path, cache = True, password = None):
        req = Request.blank(path)
        if cache :
            req.environ['swift.cache'] = FakeMemcache()
        if password :
            req.environ['HTTP_X_PUBLIC_PASSWORD'] = password
        return req
        
    def test_dlink_with_wrong_utf8(self):
        req = self._make_request('/v1/links/a%80')
        resp = req.get_response(self.dlink)
        self.assertEquals(resp.status_int, 412)
        
    def test_dlink_with_wrong_path(self):
        app = FakeApp(iter([('404 NotFound', {}, '')]))
        _dlink = filter_factory(self.conf)(app)
        req = self._make_request('/v1/links/path_not_exist')
        resp = req.get_response(_dlink)
        self.assertEquals(resp.status_int, 404)
        
    def test_dlink_with_file_not_exist(self):
        app = FakeApp(iter([('404 NotFound', {}, '')]))
        _dlink = filter_factory(self.conf)(app)
        req = self._make_request('/v1/links/file_not_exist')
        resp = req.get_response(_dlink)
        self.assertEquals(resp.status_int, 404)
        
    def test_dlink_with_list_subfolder_case(self):
        req = self._make_request('/v1/links/list_subfolder_case')
        resp = req.get_response(self.dlink)
        self.assertEquals(resp.status_int, 200)
        
    def test_dlink_with_get_subfolder_file(self):
        req = self._make_request('/v1/links/subfolder/file')
        resp = req.get_response(self.dlink)
        self.assertEquals(resp.status_int, 200)
        
    def test_dlink_with_download_subfolder_file(self):
        req = self._make_request('/v1/links/file')
        resp = req.get_response(self.dlink)
        self.assertEquals(resp.status_int, 200)
        
    def test_pass_dlink(self):
        req = self._make_request('/v1/file')
        resp = req.get_response(self.dlink)
        self.assertEquals(resp.status_int, 404)

if __name__ == '__main__':
    unittest.main()
