#Init Keystone
export OS_SERVICE_TOKEN=652aa098c9e542c19a95fa1050cd2c6e
export OS_SERVICE_ENDPOINT=http://localhost:35357/v2.0
# Create keystone service
ADMIN_PORTAL_SID=`keystone service-create --name admin_portal --type admin_portal | grep id | cut -d'|' -f3 | cut -d' ' -f2`
USER_PORTAL_SID=`keystone service-create --name user_portal --type user_portal| grep id | cut -d'|' -f3 | cut -d' ' -f2`
FILEOP_SID=`keystone service-create --name fileop --type fileop| grep id | cut -d'|' -f3 | cut -d' ' -f2`
NOTIFY_SID=`keystone service-create --name notify_server --type notify_server| grep id | cut -d'|' -f3 | cut -d' ' -f2`
# Create keystone service endpoint
ADMIN_EP_ID=`keystone endpoint-create --region RegionOne --service-id=$ADMIN_PORTAL_SID --publicurl http://$MY_IP:8000/`
FILEOP_EP_ID=`keystone endpoint-create --region RegionOne --service-id=$FILEOP_SID --publicurl http://$MY_IP:7000/v1/`
NOTIFY_EP_ID=`keystone endpoint-create --region RegionOne --service-id=$NOTIFY_SID --publicurl ws://$MY_IP:12345/`
USER_EP_ID=`keystone endpoint-create --region RegionOne --service-id=$USER_PORTAL_SID --publicurl http://$MY_IP:8080/`

