from keystone.common import logging
from keystone import auth
from keystone import exception
from keystone import identity
from keystone.auth.plugins.password import UserAuthInfo
from keystone.identity.backends.sql import Identity
from keystone.common import utils
from latte.driver.auth_driver import AuthDriver
from keystone.common import sql

METHOD_NAME = 'password'
LOG = logging.getLogger(__name__)

class Password(auth.AuthMethodHandler):

    def latte_check_password(self, password, user_ref):
        try :
            _extra = user_ref['extra']
        except Exception:
            _extra = user_ref
        _type = _extra.get('auth_type', None)
        if _type:
            user   = user_ref['name']
            domain = self.identity_api.get_domain(user_ref['domain_id'])['name']
            _auth = AuthDriver(_extra)
            return _auth.auth(user, password, domain)
        else :
            return utils.check_password(password, user_ref.get('password'))

    def authenticate(self, context, auth_payload, user_context):
        user_info = UserAuthInfo(context, auth_payload)
        Identity._check_password = self.latte_check_password
        self.identity_api = Identity()
        try:
            #latest keystone
            user_auth_data = self.identity_api.authenticate_user(
                user_id=user_info.user_id,
                password=user_info.password)
        except Exception as err:
            print err
            #old keystone
            user_auth_data = self.identity_api.authenticate(
                user_id=user_info.user_id,
                password=user_info.password)
            
            
        if 'user_id' not in user_context:
            user_context['user_id'] = user_info.user_id
