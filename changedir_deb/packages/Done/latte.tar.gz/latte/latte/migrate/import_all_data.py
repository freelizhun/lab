from latte.migrate.migrate_data import MigrateData

_type = 'ldap'

db_addr = 'mysql://root:joe@127.0.0.1/keystone'
total_quota = None
user_quota = 5368709120

if _type == 'ad':
    addr = 'ldap://10.90.0.51'
    domain = 'cs.promise.com.tw'
    user = 'joe@cs.promise.com.tw'
    pwd = 'P@ssword'
    cn = 'cn'
else :
    addr = 'ldap://10.90.0.145'
    domain = 'example.com'
    user = 'cn=admin, dc=example, dc=com'
    pwd = 'secret'
    cn = 'uid'

_m = MigrateData(ad_addr     = addr, 
                 domain      = domain, 
                 db_path     = db_addr, 
                 user        = user, 
                 pwd         = pwd, 
                 backend     = _type, 
                 cn          = cn, 
                 total_quota = total_quota, 
                 user_quota  = user_quota)
_m.loop_insert(_m.dn)
