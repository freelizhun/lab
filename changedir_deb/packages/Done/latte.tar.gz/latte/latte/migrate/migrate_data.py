import ldap, sys
from ldap.dn import str2dn
import uuid
from latte.migrate.migrate_db import KeystoneDBDriver as KsDB
import datetime
from urllib import unquote

class MigrateData(object):
    
    def __init__(self, ad_addr, domain, db_path, user = None, pwd = None, 
                 backend = 'ad', cn = 'cn', total_quota = None, 
                 user_quota = 5368709120):
        self.user = user
        self.pwd  = pwd
        self.addr = ad_addr
        self.dn   = self.split_dn(domain)
        self.backend = backend
        self.db_path = db_path
        self.db   = KsDB(self.db_path, self.backend, self.addr)
        self.conn = ldap.initialize(self.addr)
        self.conn.set_option(ldap.OPT_REFERRALS, 0)
        self.total_quota = total_quota
        self.allocated_quota = 0
        self.user_quota = user_quota
        self.cn = cn
        if backend == 'ad' :
            print self.user, self.pwd
            self.conn.bind_s(self.user, self.pwd)
        else:
            self.conn.simple_bind_s(self.user, self.pwd)
        
    def split_dn(self, dn):
        return ','.join(["dc=%s" % (k) for k in dn.split('.')])
        
    def get_domain_entity(self):
        try:
            attrs = ['businessCategory', 'userPassword', 'enabled', 
                     'email', 'sn']
            res = self.conn.search_s(self.dn, 0, '(objectClass=*)', attrs)
            return str2dn(res[0][0])
        except ldap.LDAPError as e:
            raise Exception(e)
    
    def get_detail_infos(self, _data):
        cn = []
        ou = []
        dc = []
        #gen user_login string
        user_string = []
        for _d in _data:
            if _d[0][0].lower() == self.cn :
                cn.append(_d[0][1])
                user_string.append(self.cn + '='+_d[0][1])
            elif _d[0][0].lower() == 'ou' :
                ou.append(_d[0][1])
                user_string.append('ou='+_d[0][1])
            elif _d[0][0].lower() == 'dc' :
                dc.append(_d[0][1])
                user_string.append('dc='+_d[0][1])
        return {'cn' : unquote('.'.join(cn)),
                'ou' : unquote('.'.join(ou)),
                'dc' : unquote('.'.join(dc))},\
                unquote(','.join(user_string))
               
    def get_child_entities(self, data):
    
        if self.backend == 'ad':
            _rule = '(|(objectClass=organizationalUnit)(objectClass=User))'
        else:
            _rule = '(|(objectClass=organizationalUnit)'+\
                '(objectClass=inetOrgPerson))'
    
        try:
            attrs = ['sAMAccountName']
            res= self.conn.search_s( data, 1, _rule, attrs)
            return res
        except ldap.LDAPError as e:
            raise Exception(e)
            
    def find_ad_group(self, _groups): 
        for _g in _groups :
            if _g.get('type'):
                if _g['type'] == 'AD':
                    return _g
        return None
            
    def insert_to_db(self, data, full_name = ''):
        if data['cn'] == '' :
            self.db.create_ou(data['ou'], data['dc'])
        elif data['cn'] != '' :
            ref_project, _new = self.db.create_project(data['cn'], data['dc'])
            ref_user = self.db.create_user(data['cn'], data['dc'], 
                                           ref_project['id'], full_name)
            if _new :
                #Add admin role to user's own project
                self.db.create_grant(role = 'admin', 
                                     domain = data['dc'], 
                                     user_id = ref_user['id'], 
                                     tenant_id = ref_project['id'])
                #Add member role into domain
                self.db.create_grant(role = 'member', 
                                     domain = data['dc'], 
                                     user_id = ref_user['id'])
                #Add user into OU
                self.db.add_user_to_group(user_id = ref_user['id'], 
                                          ou = data['ou'])
                #Grant role of user into OU
                self.db.create_grant(role = 'member', 
                                     domain = data['dc'], 
                                     user_id = ref_user['id'], 
                                     ou = data['ou'],
                                     under_ou=True)
                #Record allocated quota
                self.allocated_quota += self.user_quota
            else :
                
                #TODO find user's previous OU
                _groups = self.db.list_groups_for_user(ref_user['id'])
                _group = self.find_ad_group(_groups)
                if _group :
                    if _group['name'] != data['ou'] :
                        #print _group['name'] ,data['ou']
                        old_ou_ref = self.db.find_ou(_group['name'])
                        self.db.remove_user_from_group(ref_user['id'],
                                                       old_ou_ref['id'])
                    else :
                        pass
                #Add user into OU
                self.db.add_user_to_group(user_id = ref_user['id'], 
                                          ou = data['ou'])
                #Grant role of user into OU
                self.db.create_grant(role = 'member', 
                                     domain = data['dc'], 
                                     user_id = ref_user['id'], 
                                     ou = data['ou'],
                                     under_ou=True)
            
    def loop_insert(self, data):
        _domain = self.get_domain_entity()
        _dict, junk = self.get_detail_infos(_domain)
        ref = self.db.create_domain(_dict['dc'])
        self.db.get_roles()
        self._loop_insert(self.dn)
        self.db.update_domain(ref, self.total_quota, self.allocated_quota)
             
    def _loop_insert(self, data):
        res = self.get_child_entities(data)
        for _data, _attr in res:
            if _data == None:
                continue
            else :
                _data_parts = str2dn(_data)
                _info, full_name = self.get_detail_infos(_data_parts)
                if _attr.has_key('sAMAccountName'):
                    _info['cn'] = _attr['sAMAccountName'][0]
                self.insert_to_db(_info, full_name)
                self._loop_insert(_data)
