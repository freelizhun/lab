from latte.migrate.migrate_db import KeystoneDBDriver as KsDB

#To create admin account into database
db_addr = 'mysql://root:joe@127.0.0.1/keystone'
backend = 'ldap'
ad_addr = 'ldap://10.90.0.51'
new_user = 'admin'
password = 'admin'
db = KsDB(db_addr, backend, ad_addr)

ref_project, junk = \
    db.create_project(new_user, 'Default')
ref_user = db.create_user(new_user, 'Default', ref_project['id'], '', 1,
                               True, password)
db.create_grant(role = 'admin', 
                domain = 'Default', 
                user_id = ref_user['id'], 
                tenant_id = ref_project['id'])
