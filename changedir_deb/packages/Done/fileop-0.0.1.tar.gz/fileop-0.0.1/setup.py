#!/usr/bin/python
from setuptools import setup, find_packages
#from swift import __canonical_version__ as version

name = 'monga'

setup(
    name=name,
    version='0.0.1',
    description='Monga',
    license='Apache License (2.0)',
    author='Promise, LLC.',
    author_email='joeyang@tw.promise.com',
    url='https://www.promise.com.tw/',
    packages=find_packages(exclude=['test', 'bin']),
    test_suite='nose.collector',
    classifiers=[
        'Development Status :: 4 - Beta',
        'License :: OSI Approved :: Apache Software License',
        'Operating System :: POSIX :: Linux',
        'Programming Language :: Python :: 2.6',
        'Environment :: No Input/Output (Daemon)',
        ],
    install_requires=[],  # removed for better compat
    scripts=[
        'bin/monga-proxy-server',
        'bin/monga-log-notifier',
        'bin/monga-expired-cleaner',
        'bin/monga-chunk-cleaner',
        'bin/monga-version-cleaner'
    ],
    entry_points={
        'paste.app_factory': [
            'proxy = monga.proxy.server:app_factory',
            ],
        'paste.filter_factory': [
            'collector = monga.middleware.collector:filter_factory',
            'fake_user = monga.middleware.fake_user:filter_factory',
            'direct_link = monga.middleware.direct_link:filter_factory',
            'admin_ext =  monga.middleware.admin_extension:filter_factory',
            'formpost = monga.middleware.formpost:filter_factory',
            ],
        },
    )
