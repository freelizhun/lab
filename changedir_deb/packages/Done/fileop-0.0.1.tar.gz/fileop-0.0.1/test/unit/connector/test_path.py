#!/usr/bin/env python
from monga.connector.exception import InvalidParameter
from monga.connector.path import MongaSystemPath as spath
from monga.connector.path import MongaTenantPath as tpath
from monga.connector.path import MONGA_SYSTEM_LIBS as slib
from monga.connector.path import MONGA_TENANT_LIBS as tlib
import unittest
import os


class TestMongaSystemPath(unittest.TestCase):

    def test_bad_input(self):
        self._bad_input_path_to_binary_folder()
        self._bad_input_path_to_chunk()
        self._bad_input_get_system_relative_path()

    def _bad_input_path_to_binary_folder(self):
        #path_to_binary_folder(cls, access_point)
        f = spath.path_to_binary_folder
        self.assertRaises(InvalidParameter, f, None)

    def _bad_input_path_to_chunk(self):
        #def path_to_chunk(cls, access_point, chunk_id)
        f = spath.path_to_chunk
        self.assertRaises(InvalidParameter, f, None, None)
        self.assertRaises(InvalidParameter, f, '/Fake', None)
        self.assertRaises(InvalidParameter, f, None, 'Fake')

    def _bad_input_get_system_relative_path(self):
        #def get_system_relative_path(cls, access_point, access_path)
        f = spath.get_system_relative_path
        self.assertRaises(InvalidParameter, f, None, None)
        self.assertRaises(InvalidParameter, f, '/Fake', None)
        self.assertRaises(InvalidParameter, f, None, 'Fake')
        
    def test_path_to_temp(self):
        _ACCESS_POINT = '/Test/Access/Point'
        _TENANT_ID = 'PertTest'
        _TEMP_UUID = 'A_UUID'
        EXPECT_RESULT = os.path.join(
            _ACCESS_POINT, 
            slib['folder'],
            _TENANT_ID, 
            slib['tmp'],
            _TEMP_UUID)
        result = spath.path_to_temp(
            _ACCESS_POINT, _TENANT_ID, _TEMP_UUID)
        self.assertEquals(EXPECT_RESULT, result)
    
    def test_path_to_temp_with_none(self):
        _ACCESS_POINT = '/Test/Point'
        _TENANT_ID = 'Fortest'
        _TEMP_UUID = None
        EXPECT_RESULT = os.path.join(
            _ACCESS_POINT, 
            slib['folder'],
            _TENANT_ID, 
            slib['tmp']       
            )
        result = spath.path_to_temp(
            _ACCESS_POINT, _TENANT_ID, _TEMP_UUID)
        self.assertEquals(EXPECT_RESULT, result)
     
    def test_path_to_binary_folder(self):
        _ACCESS_POINT= '/Test/Point'
        Expect_result= os.path.join(
            _ACCESS_POINT,
            slib['binary'] 
            )
        Result= spath.path_to_binary_folder(
            _ACCESS_POINT
            )
        f = spath.path_to_binary_folder
        self.assertRaises(InvalidParameter,f, None)
        self.assertEquals(Expect_result, Result)
               
    def test_path_to_chunk(self):
        _ACCESS_POINT= '/Test/Point'
        _CHUNK_ID='Fortest_chunkid'
        Expect_result= os.path.join(
            _ACCESS_POINT,
            slib['binary'],
            _CHUNK_ID
            )
        Result= spath.path_to_chunk(
            _ACCESS_POINT,
            _CHUNK_ID
            )
        self.assertEquals(Expect_result,Result)
      
    def test_get_system_relative_path(self):
        _ACCESS_POINT= '/Test/Point'
        _ACCESS_PATH= '/Test/Path'
        Expect_result= u'/{0}'.format(unicode('/'.join(
            os.path.relpath(_ACCESS_PATH,_ACCESS_POINT).split('/')[2:])))
        Result= spath.get_system_relative_path(
            _ACCESS_PATH,
            _ACCESS_POINT
            )
        self.assertEquals(Expect_result,Result)
        
    
      
    def test_path_to_tenant(self):
        _ACCESS_POINT='/Test/Point'
        _TENANT_ID= 'Fortest_tenantid'
        Expect_result= os.path.join(
            _ACCESS_POINT,
            _TENANT_ID
            )
        Result= spath.path_to_tenant(
            _ACCESS_POINT,
            _TENANT_ID
            )
        self.assertEquals(Expect_result,Result)
        
    def test_path_to_ts(self):
        _ACCESS_POINT='/Test/Point'
        Expect_result= os.path.join(
            _ACCESS_POINT,
            slib['ts']
            )
        Result= spath.path_to_ts(
            _ACCESS_POINT,
            )          
        self.assertEquals(Expect_result, Result)
        
              

class TestMongaTenantPath(unittest.TestCase):

    def test_bad_input(self):
        self._bad_input_path_to_version_folder()
        self._bad_input_path_to_home_folder()
        self._bad_input_path_to_trash_folder()

    def test_path_to_version_folder(self):
        _access_point='/Test/Point'
        _tenant_id='fortest_tenantid'
        _file_path= 'fortest_filepath'
        expect_result= os.path.join(
            _access_point,
            _tenant_id,
            tlib['version'],
            _file_path
            )
        result= tpath.path_to_version_folder(
            _access_point,
            _tenant_id,           
            _file_path
            )
        self.assertEquals(expect_result, result)
  
    def test_path_to_version_folder_filepath_none(self):
        _access_point='/Test/Point'
        _tenant_id='fortest_tenantid'
        _file_path= None
        expect_result= os.path.join(
            _access_point,
            _tenant_id,
            tlib['version']
            )
        result= tpath.path_to_version_folder(
            _access_point,
            _tenant_id,
            )
        self.assertEquals(expect_result, result)
      
      
    def test_path_to_home_folder(self):
        _access_point='/Test/Point'
        _tenant_id='fortest_tenantid'
        expect_result=os.path.join(
            _access_point,
            _tenant_id,
            tlib['home']
            )
        result=tpath.path_to_home_folder(
            _access_point,
            _tenant_id          
            )
        self.assertEquals(expect_result, result)
        
    def test_path_to_trash_folder(self):
        _access_point='/Test/Point'
        _tenant_id='fortest_tenantid'
        expect_result=os.path.join(
            _access_point,
            _tenant_id,
            tlib['trash']
            )
        result=tpath.path_to_trash_folder(
            _access_point,
            _tenant_id,
            
            )
        self.assertEquals(expect_result, result)  
        
    def test_path_to_trash_version_folder(self):
        _access_point='/Test/Point'
        _tenant_id='fortest_tenantid'
        _trash_id='fortest_trashid'
        expect_result=os.path.join(
            _access_point,
            _tenant_id,
            tlib['trash'],
            tlib['trash_version'],
            _trash_id
            )
        result=tpath.path_to_trash_version_folder(
            _access_point,
            _tenant_id,            
            _trash_id
            )
        self.assertEquals(expect_result,result)
    
  
  
  
  
  
    
    
    def _bad_input_path_to_version_folder(self):
        #def path_to_version_folder(cls, access_point, tenant_id, file_path)
        f = tpath.path_to_version_folder
        self.assertRaises(InvalidParameter, f, None, None)
        self.assertRaises(InvalidParameter, f, '/Fake', None)
        self.assertRaises(InvalidParameter, f, None, 'Fake')
#        self.assertRaises(InvalidParameter, f, None, None, None)
#        self.assertRaises(InvalidParameter, f, 'fake', None, None)
#        self.assertRaises(InvalidParameter, f, None, 'fake', None)
#        self.assertRaises(InvalidParameter, f, None, None, 'fake')
#        self.assertRaises(InvalidParameter, f, None, 'fake', 'fake')
#        self.assertRaises(InvalidParameter, f, 'fake', None, 'fake')
#        self.assertRaises(InvalidParameter, f, 'fake', 'fake', None)

    def _bad_input_path_to_home_folder(self):
        #def path_to_home_folder(cls, access_point, tenant_id)
        f = tpath.path_to_home_folder
        self.assertRaises(InvalidParameter, f, None, None)
        self.assertRaises(InvalidParameter, f, '/Fake', None)
        self.assertRaises(InvalidParameter, f, None, 'Fake')

    def _bad_input_path_to_trash_folder(self):
        #def path_to_trash_folder(cls, access_point, tenant_id):
        f = tpath.path_to_trash_folder
        self.assertRaises(InvalidParameter, f, None, None)
        self.assertRaises(InvalidParameter, f, '/Fake', None)
        self.assertRaises(InvalidParameter, f, None, 'Fake')

if __name__ == '__main__':
    unittest.main()
