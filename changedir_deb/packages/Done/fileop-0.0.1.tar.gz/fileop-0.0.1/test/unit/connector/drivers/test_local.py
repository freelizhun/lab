#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import unittest
from monga.connector import get_connector
import sys
import string
import random
import hashlib
import logging
import uuid
import os
#from monga.connector.exception import InvalidParameter
from monga.common.exception import InvalidParameter
from monga.common.exception import StorageError
from monga.common.exception import NotFoundError as FileNotFound
from monga.common.exception import ForbiddenError as FileExists


logger = logging.getLogger()
ch = logging.StreamHandler()
ch.setLevel(logging.ERROR)
logger.setLevel(logging.ERROR)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(formatter)
logger.addHandler(ch)
logger = logging.getLogger()
ch = logging.StreamHandler()
ch.setLevel(logging.ERROR)
logger.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(formatter)
logger.addHandler(ch)
MOUNT_PATH='/mnt/monga'
ACCESS_POINT='/opt/monga'
chunks = []
chunk_size = 1<<5
test_range = 5
for i in range(0,10) :
    chunks.append(
        ''.join(random.choice(
            string.ascii_uppercase + string.digits)
            for x in range(chunk_size)))
chunks_md5 = []
for c in chunks :
    m = hashlib.md5()
    m.update(c)
    chunks_md5.append(m.hexdigest())
save_path = ['/a.txt','/folder/a.txt','/b.txt',
    '/folder/subfolder/a.txt','/folder/b.txt',
    '/folder/c.txt','/folder/search.txt']
#save_path = ['a.txt','/folder/a.txt']
#users = ['Paul','Joe','Jonah']
users = ['Paul']
'''
a.txt
b.txt
folder
    a.txt
    b.txt
    c.txt
    search.txt
    subfolder
        a.txt
'''
MAX_NUM_VERSION = 5 

class TestLocalDriver(unittest.TestCase):
    
    #def setUp(self):
    #    pass
    def setUp(self):
        self.driver = get_connector(logger, 
		conf={'storage_mount_path':MOUNT_PATH, 
                'storage_access_point':ACCESS_POINT})
        for user in users:
            t_id = user
            for s in save_path:
                try:
                    if os.path.dirname(s) is not '':
                        self.driver.create_folder(t_id,os.path.dirname(s))
                except FileExists:
                    pass
                temp_uuid = uuid.uuid4().__str__()
                for i in range(test_range) :
                    self.driver.upload(tenant_id=t_id,
                            temp_uuid=temp_uuid,
                            data=chunks[i],
                            chunk_name=chunks_md5[i])
                self.driver.commit(
                    tenant_id=t_id,
                    save_path=s,
                    temp_uuid=temp_uuid,
                    mtime='DATATIME',
                    file_size=chunk_size,
                    store_size=chunk_size)

    def _upload(self):
        for i in range(MAX_NUM_VERSION):
            for user in users:
                t_id = user
                for s in save_path:
                    if os.path.dirname(s) is not '':
                        try:
                            self.driver.create_folder(t_id,os.path.dirname(s))
                        except FileExists:
                            pass
                    temp_uuid = uuid.uuid4().__str__()
                    for i in range(test_range) :
                        self.driver.upload(tenant_id=t_id,
                                temp_uuid=temp_uuid,
                                data=chunks[i],
                                chunk_name=chunks_md5[i])
                    self.driver.commit(
                        tenant_id=t_id,
                        save_path=s,
                        temp_uuid=temp_uuid,
                        file_size=chunk_size,
                        store_size=chunk_size,
                        mtime='DATATIME')

    #def test_trash(self):
    #    meta = self.driver.get_metadata(tenant_id='Paul', path=save_path[0])
    #    self.driver.trash(tenant_id='Paul', path=save_path[0])
    
    def test_chinses_filename(self):
        fn = u'/不要.txt'
        for i in range(3) :
            self.driver.upload(tenant_id='Paul',
                    temp_uuid='Test-Chinese',
                    data=chunks[i],
                    chunk_name=chunks_md5[i])
        meta = self.driver.commit(
            tenant_id='Paul',
            save_path=fn,
            temp_uuid='Test-Chinese',
            file_size=chunk_size,
            store_size=chunk_size,
            mtime='DATATIME')

        self.assertEquals(meta['path'], fn)


    def test_delete_uncommited_upload(self):
        for i in range(3) :
            self.driver.upload(tenant_id='Paul',
                    temp_uuid='Test-Check-Upload',
                    data=chunks[i],
                    chunk_name=chunks_md5[i])
        self.driver.delete_uncommited_upload(
                            tenant_id='Paul',
                            temp_uuid='Test-Check-Upload')

    def test_check_upload(self):
        for i in range(3) :
            self.driver.upload(tenant_id='Paul',
                    temp_uuid='Test-Check-Upload',
                    data=chunks[i],
                    chunk_name=chunks_md5[i])
        manifest=self.driver.check_upload(
                            tenant_id='Paul',
                            temp_uuid='Test-Check-Upload')
        for i in range(3):
            self.assertEquals(manifest[i], chunks_md5[i])

    def test_check_upload_temp_exists(self):
        for i in range(3) :
            self.driver.upload(tenant_id='Paul',
                    temp_uuid='AHASH-Test-Check-Upload',
                    data=chunks[i],
                    chunk_name=chunks_md5[i])
        self.assertEquals(
            self.driver.check_upload_temp_exists(
			'Paul','AHASH-Test-Check-Upload'), True)
        self.assertEquals(
            self.driver.check_upload_temp_exists('Paul','BHASH-'), False)

    def test_list_uncommited_upload(self):
        for i in range(3) :
            self.driver.upload(tenant_id='Paul',
                    temp_uuid='AHASH-Test-Check-Upload',
                    data=chunks[i],
                    chunk_name=chunks_md5[i])

        res = self.driver.list_uncommited_upload(tenant_id='Paul',
                            temp_uuid='AHASH-Test-Check-Upload')
        for r in res:
            self.assertEquals(int(r), chunk_size)

    def test_exception_create_folder(self):
        self.driver.create_folder('Exception','foo')
        f = self.driver.create_folder
        self.assertRaises(FileExists, f, 'Exception', 'foo')

    def test_download(self):
        meta = self.driver.get_metadata(tenant_id='Paul', path=save_path[0])
        download_chunks = []
        download_chunks_md5 = []
        for c in meta['manifest'] :
            data = self.driver.download(tenant_id='Paul',chunk_id=c)
            download_chunks.append(data)
            m = hashlib.md5()
            m.update(data)
            download_chunks_md5.append(m.hexdigest())

        for i in range(test_range):
            self.assertEquals(chunks_md5[i],download_chunks_md5[i])
        self._exception_download()

    def _exception_download(self):
        f = self.driver.download
        fake_chunk = 'fakefakefake'
        self.assertRaises(FileNotFound, f, 'Paul', fake_chunk)
    
    def test_undefine_driver(self):
        f = get_connector
        self.assertRaises(StorageError,
                f, logger, conf={'storage_type':'unkown'})
        #try:
        #    d = get_connector(logger, conf={'connector_type':'unkown',
        #                'mount_path':MOUNT_PATH})
        #except Exception as inst:
        #    self.assertEquals(type(inst),StorageError)
            

    def test_list_metadata(self):
        self._list_home_metadata()
        self._list_folder_metadata()
        #self._list_folder_metadata()
        #self._list_file_metadata()

    def _list_home_metadata(self):
        meta = self.driver.get_metadata(
            tenant_id='Paul', path='.', is_list=True)
        self.assertEquals(meta['path'],'/')
        self.assertEquals(meta['is_dir'],True)
        #self.assertEquals(meta['contents'].__len__(),3)
        for c in meta['contents']:
            if c['path'] in ['/a.txt','/b.txt']:
                self.assertEquals(c['bytes'], chunk_size)
                self.assertEquals(c['is_dir'], False)
            elif c['path'] in ['/folder']:
                self.assertEquals(c['bytes'], 0)
                self.assertEquals(c['is_dir'], True)
            else:
                print c['path']

    def _list_folder_metadata(self):
        meta = self.driver.get_metadata(
            tenant_id='Paul', path='/folder', is_list=True)
        self.assertEquals(meta['path'],'/folder')
        self.assertEquals(meta['is_dir'],True)
        #self.assertEquals(meta['contents'].__len__(),4)
        for c in meta['contents']:
            if c['path'] in ['/folder/a.txt','/folder/b.txt','/folder/c.txt']:
                self.assertEquals(c['bytes'], chunk_size)
                self.assertEquals(c['is_dir'], False)
            elif c['path'] in ['/folder/subfolder']:
                self.assertEquals(c['bytes'], 0)
                self.assertEquals(c['is_dir'], True)
            else:
                print c['path']
    
    def test_get_folder_metadata(self):
        meta = self.driver.get_metadata(
            tenant_id='Paul', path='/folder')
        self.assertEquals(meta.get('contents',None), None)
        self.assertEquals(meta['bytes'], 0)
        self.assertEquals(meta['is_dir'], True)
    
    def test_get_file_metadata(self):
        meta = self.driver.get_metadata(
            tenant_id='Paul', path='/a.txt')
        self.assertEquals('contents' in meta, False)
        self.assertEquals(meta['bytes'], chunk_size)
        self.assertEquals(meta['is_dir'], False)
    
    def test_list_version_metadata(self):
        self._upload()
        versions = self.driver.get_version_metadata(
            tenant_id='Paul', path=save_path[0])
        self.assertEquals(versions.__len__(),5)
        #for v in versions:
        #        logger.debug(v)
        #logger.debug(versions.__len__())

    #def test_move(self):
    #    self._move_same_tenant()
    #    self._exception_move()
        #self._move_diff_tenant()
    
    def _exception_move(self):
        f = self.driver.move
        self.assertRaise(FileExists, f, \
                src_tenant_id='Paul', \
                src_path = save_path[0],\
                dest_path = save_path[1]
                )

        self.assertRaise(FileNotFound, f, \
                src_tenant_id='Joe', \
                src_path = save_path[0], \
                dest_path = '/noexist/folder'
                )

    def _move_same_tenant(self):
        meta = self.driver.move(src_tenant_id='Paul', 
                src_path=save_path[1],
                dest_path='/move123')
        self.assertEquals(meta['path'],'/move123')

    def _move_diff_tenant(self):
        meta = self.driver.move(src_tenant_id='Paul',
                dest_tenant_id='Joe',
                src_path=save_path[2],
                dest_path=save_path[3])
        meta = self.driver.get_metadata('Joe', save_path[3])
        self.assertEquals(meta['path'], save_path[3])
    
    def test_rename(self):
        meta = self.driver.move(src_tenant_id='Paul', 
                src_path=save_path[2],
                dest_path='/rename')
        self.assertEquals(meta['path'],'/rename')

    def test_copy_move(self):
        self._copy_same_tenant()
        self._exception_copy()
        self._move_same_tenant()
        #self._exception_move()
    
    def _exception_copy(self):
        f = self.driver.move
        self.assertRaises(FileExists, f, 
                    src_tenant_id='Paul', 
                    src_path = save_path[0], 
                    dest_path = save_path[1], 
                    is_copy=True
                )
        self.assertRaises(FileNotFound, f, 
                    src_tenant_id='Joe', 
                    src_path = save_path[0],
                    dest_path = '/noexist/folder', 
                    is_copy=True
                )

    def _copy_same_tenant(self):
        meta = self.driver.move(src_tenant_id='Paul', 
            src_path=save_path[3],
            dest_path='/copy', 
            is_copy=True)
        self.assertEquals(meta['path'],
		'/copy'.format(save_path[3]))

    def _copy_diff_tenant(self):
        meta = self.driver.move(src_tenant_id='Paul',
            dest_tenant_id='Jonah',
            src_path=save_path[1],
            dest_path=save_path[2], 
            is_copy=True)
        meta = self.driver.get_metadata(tenant_id='Jonah', path=save_path[2])
        self.assertEquals(meta['path'], save_path[2])
    
    def _exception_move(self):
        f = self.driver.move
        self.assertRaises(FileExists, f, 
                    src_tenant_id='Paul', 
                    src_path = save_path[0], 
                    dest_path = save_path[1], 
                    is_copy=False
                )
        self.assertRaises(FileNotFound, f, 
                    src_tenant_id='Joe', 
                    src_path = save_path[0],
                    dest_path = '/noexist/folder', 
                    is_copy=False
                )

    def test_delete(self):
        meta = self.driver.delete(tenant_id='Paul', path=save_path[3])
        self.assertEquals(meta['path'],save_path[3])

    def test_delete_empty_folder(self):
        empty_folder = '/empty_folder'
        self.driver.create_folder('Paul', empty_folder)
        meta = self.driver.delete('Paul', empty_folder)
        self.assertEquals(meta['path'],empty_folder)

    def test_search(self):
        self.driver.create_folder('Paul','/MySearch')
        results = self.driver.search(tenant_id='Paul', search_path='/', 
                    keyword='search')
        for res in results:
            print res
            if res['is_dir']:
                self.assertEquals(res['path'],'/MySearch')
            else:
                self.assertEquals(res['path'],'/folder/search.txt')

    def test_bad_input(self):
        self._bad_input_get_metadata()
        #self._bad_upload_input()
        #self._bad_input_commit()
        self._bad_input_move()
        self._bad_input_delete()
        self._bad_input_get_version_metadata()
        self._bad_input_search()
        self._bad_input_create_folder()
        self._bad_input_download()

    def _bad_input_get_metadata(self):
        #def get_metadata(self, tenant_id, path, 
        #       file_version=None, is_list=False):
        f = self.driver.get_metadata
        self.assertRaises(InvalidParameter, f, None, None)
        self.assertRaises(InvalidParameter, f, 'tid', None)
        self.assertRaises(InvalidParameter, f, None, 'path')
    
    def _bad_upload_input(self):
        #upload(self, tenant_id, temp_uuid, data, chunk_name)
        f = self.driver.upload
        self.assertRaises(InvalidParameter, f, None, None, None, None)
        self.assertRaises(InvalidParameter, f, 'tid', None, None, None)
        self.assertRaises(InvalidParameter, f, 'tid', 'tuuid', None, None)
        self.assertRaises(InvalidParameter, f, 'tid', 'tuuid', 'data', None)

    def _bad_input_commit(self):
        #def commit(self, tenant_id, save_path, temp_uuid,
        #    file_size, store_size, mtime, compress=False, encrypt=False):
        f = self.driver.commit
        self.assertRaises(InvalidParameter, f, None, None, None, None, None, None)
        self.assertRaises(InvalidParameter, f, 'tid', None, None, None, None, None)
        self.assertRaises(InvalidParameter, f, 'tid','path', None, None, None, None)
        self.assertRaises(InvalidParameter, f, 'tid','path','uuid', None, None, None)
        self.assertRaises(InvalidParameter, f, 'tid','path','uuid', 1234, None, None)
        self.assertRaises(InvalidParameter, f, None, None, None, None, 4321, None)

    def _bad_input_move(self):
        #def move(self, src_path, dest_path, src_tenant_id,
        #        is_copy=False, dest_tenant_id=None):
        f = self.driver.move
        self.assertRaises(InvalidParameter, f, None, None, None)
        self.assertRaises(InvalidParameter, f, 'src', None, None)
        self.assertRaises(InvalidParameter, f, 'src', 'dest', None)
        self.assertRaises(InvalidParameter, f, None, None, 'tid')

    def _bad_input_delete(self):
        #def delete(self, tenant_id, path):
        f = self.driver.delete
        self.assertRaises(InvalidParameter, f, None, None)
        self.assertRaises(InvalidParameter, f, 'tid', None)
        self.assertRaises(InvalidParameter, f, None, 'path')
    
    def _bad_input_remove(self):
        #def remove(self, tenant_id, path):
        f = self.driver.remove
        self.assertRaises(InvalidParameter, f, None, None)
        self.assertRaises(InvalidParameter, f, 'tid', None)
        self.assertRaises(InvalidParameter, f, None, 'path')
    
    def _bad_input_get_version_metadata(self):
        #def get_version_metadata(self, tenant_id, path):
        f = self.driver.get_version_metadata
        self.assertRaises(InvalidParameter, f, None, None)
        self.assertRaises(InvalidParameter, f, 'tid', None)
        self.assertRaises(InvalidParameter, f, None, 'path')
    
    def _bad_input_search(self):
        #def search(self, tenant_id, search_path, keyword)
        f = self.driver.search
        self.assertRaises(InvalidParameter, f, None, None, None)
        self.assertRaises(InvalidParameter, f, 'tid', None, None)
        self.assertRaises(InvalidParameter, f, None, 'path', None)
        self.assertRaises(InvalidParameter, f, None, None, 'key')
        self.assertRaises(InvalidParameter, f, 'tid', 'path', None)


    def _bad_input_create_folder(self):
        #def create_folder(self, tenant_id, folder_path):
        f = self.driver.create_folder
        self.assertRaises(InvalidParameter, f, None, None)
        self.assertRaises(InvalidParameter, f, 'tid', None)
        self.assertRaises(InvalidParameter, f, None, 'path')
    
    def _bad_input_download(self):
        #def download(self, tenant_id, chunk_id):
        f = self.driver.download
        self.assertRaises(InvalidParameter, f, None, None)
        self.assertRaises(InvalidParameter, f, 'tid', None)
        self.assertRaises(InvalidParameter, f, None, 'path')

    def test_restore(self):
        self._upload()
        meta = self.driver.get_version_metadata('Paul', save_path[0])
        restore_meta = meta[1]
        restored_meta = self.driver.restore('Paul', save_path[0], 
                    restore_meta['rev'])
        self.assertEquals(restore_meta['rev'],restored_meta['rev'])
        self.assertEquals(restored_meta['path'],save_path[0])

    def tearDown(self):
        self.driver._delete(MOUNT_PATH)
        self.driver._delete(ACCESS_POINT)
