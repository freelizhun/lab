from monga.controller.event import EventController
from monga.common.utils import json_dump
from monga.common.exception import *
import unittest
from utils import *
import json

class TestEventController(unittest.TestCase):

    def setUp(self):
        _c = EventController
        _c.__init__ = fake_init
        self._c = _c()
        self._user = {
            'user_id'     : 'a',
            'user_name'   : 'b',
            'tenant_id'   : 'c',
            'tenant_name' : 'd',
            'domain_id'   : 'e',
            'domain_name' : 'f',
        }
        self._c.handle_actions = ['CommitChunkUpload', 'FileCopy', 'FileMove',
                                  'CreateFolder', 'FileDelete', 'UploadFile',
                                  'Restore', 'ShareFile', 'PublicLink', 'Lock',
                                  'JoinShareFolder']
        
    def test_GET(self):
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.GET(_user, object)
        self.assertEquals(200 , _resp.status_int)
        
    def test_GET_with_cursor(self):
        _object = FakeRequest(GET = {'cursor': 123})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.GET(_user, object)
        self.assertEquals(200 , _resp.status_int)
        
    def test_GET_with_wrong_role(self):
        _object = FakeRequest(GET = {'cursor': 123})
        _user = self._user
        _user['user_roles'] = ['adminn']
        _resp = self._c.GET(_user, object)
        self.assertEquals(403 , _resp.status_int)
        
if __name__ == '__main__':
    unittest.main()
