from monga.common.utils import current_timestamp
from monga.common import response as RESP
from monga.common.exception import *
from contextlib import contextmanager
import json
import random

class FakeMongo():
    def __init__(self, path, port):
        self.caseC_count = 0
        self.caseD_count = 0
        
    #add fake insert_comment by Annis
    def insert_comment(self, _user, user_info, file_path, msg):
        return
        
    def find_shared(self, body, action = 'to', path = None, 
                    shared_path = None, once = False, match = False, 
                    count =False):
        
        if shared_path == '/caseA' :
            return self.find_mathched_shared_path()
        elif path == '/caseB' :
            return self.find_mathched_shared_path()
        elif shared_path == '/caseC' :
            if self.caseC_count == 0 :
                self.caseC_count += 1
                return None
            else :
                return self.find_mathched_shared_path()
        elif shared_path in ['/pass', '/shared/pass'] :
            return None
        elif path in ['/pass', '/shared/pass'] :
            if count :
                return None, False
            else :
                return None
        elif path == '/caseD' :
            if self.caseD_count == 0 :
                self.caseD_count += 1
                return None
            else :
                _entries = []
                for num in range(1,10):
                    _body = self.find_mathched_shared_path()
                    _body['file_path'] = '/caseD/a/b'
                    _entries.append(_body)
                return _entries, True
        else :
            if path :
                if path.startswith('/case') :
                    return None
            if shared_path :
                if shared_path.startswith('/case') :
                    return None
            if once :
                return self.find_mathched_shared_path()
            _entries = []
            for num in range(1,10):
                _entries.append(self.find_mathched_shared_path())
            return _entries
        return None

    # Fixed find_comment for comment.py by Annis
    def find_comment(self, junk1, junk2, junk3 = False):
        if junk3 :
            return 0
        return [{'msg': 'msg', 'updated_time': '15:00', 'comment_user': 'user', 'user_icon': 'icon'}]
        
    def find_mathched_shared_path(self, junk1 = None, junk2 = '/a'):
        return {
            'from_user_id'     : 'a',
            'from_user_name'   : 'b',
            'from_tenant_id'   : 'c',
            'from_tenant_name' : 'd',
            'from_domain_id'   : 'e',
            'from_domain_name' : 'f',
            'to_user_id'       : 'a',
            'to_user_name'     : 'h',
            'to_tenant_id'     : 'c',
            'to_tenant_name'   : 'j',
            'to_domain_id'     : 'e',
            'to_domain_name'   : 'l',
            'link_user_id'     : 'm',
            'link_user_name'   : 'n',
            'link_tenant_id'   : 'o',
            'link_tenant_name' : 'p',
            'link_domain_id'   : 'q',
            'link_domain_name' : 'r',
            'link_path'        : '/s',
            'permission'       : {'write' : True},
            'is_dir'           : True,
            'file_path'        : junk2,
            'shared_path'      : '/shared/a',
            'updated_time'     : current_timestamp(),
            'confirm'          : False
        }
        
    def update_quota(self, junk1, junk2):
        return
        
    def delete_shared(self, junk):
        return
        
    def insert_shared(self, from_user, to_user, link_user,
                      permission, file_path, shared_path, is_dir = False, 
                      confirm = False):
        return
        
    def check_shared_path(self, junk, junk2):
        _chance = random.randint(1,3)
        if _chance == 1 :
            return None
        else :
            return self.find_mathched_shared_path()
        
    def find_quota(self, junk):
        return {'used' : 0}
        
    def find_log(self, junk, limit = 1):
        if limit :
            _entries = []
            for num in range(1,200):
                _action = random.randint(1,10)
                if _action == 5 :
                    _action = 'FileCopy'
                else:
                    _action = 'action'
            
                _entries.append({
                    'file_size' : 0,
                    'action' : _action,
                    'delta' : 'delta',
                    'is_dir' : True,
                    'updated_time' : 232131,
                    'from_path' : '/from',
                    'to_path' : '/to',
                })
            return _entries
        else :
            _handles = ['CommitChunkUpload', 'FileCopy', 'FileMove',
                        'CreateFolder', 'FileDelete', 'UploadFile',
                        'Restore', 'ShareFile', 'PublicLink', 'Lock',
                        'JoinShareFolder']
            _entries = []
            for num in range(1,100):
                _action = _handles[random.randint(0,len(_handles)-1)]
            
                _entries.append({
                    'file_size' : 0,
                    'action' : _action,
                    'delta' : 'delta',
                    'is_dir' : True,
                    'updated_time' : 232131,
                    'from_path' : '/from',
                    'to_path' : '/to',
                    'method' : 'POST'
                })
            return _entries
        
    def update_dlink(self, junk, junk2):
        if junk > 1 :
            return {}
        else :
            return {'ok' : True}
        
        
    def find_dlink(self, data, _id = None, multi = False):
        if _id and _id != 'NotExist':
            return {
                '_id' : 'id',
                'public_url' : 'url',
                'expired_tag' : 'expires',
                'file_path' : 'path',
                'pwd' : 'pwd',
            }
        elif _id == 'NotExist':
            return None
        
        _entries = []
        for num in range(1, random.randint(1,10)):
            _entries.append({
                '_id' : 'id',
                'public_url' : 'url',
                'expired_tag' : 'expires',
                'file_path' : 'path',
                'pwd' : 'pwd',
            })
        return _entries
        
    def delete_dlink(self, junk):
        return
        
    def find_lock(self, junk1, junk2, junk3):
        return True
        
    def find_user_lock(self, junk1, junk2):
        if junk2 == '/true' :
            return True
        else :
            return False
        
    def insert_lock(self, junk1, junk2):
        return
        
    def delete_lock(self, junk1, junk2):
        return 
        
    def insert_dlink(self, user_info, file_path, public_url, 
                     match_url, pwd = None, expired_time = None,
                     expired_tag = None, is_dir = False):
        return
        
    def insert_log(self, user_info, action, method = 'GET', from_path = None, 
                   to_path = None, size = 0, is_chunk = False, is_dir = False,
                   chunk_id = None, is_share = False, result = True,
                   delta = None, notifier = False, is_team = False):
        return 
        
class FakeFileOP():
    def __init__(self, logger, conf):
        self.shared_body = {
            'path' : '/s',
            'contents' : [{'path':'/s/obj'},{'path':'/s/dir'}]
        }
        self.search_body = [{'path' : '/s'},{'path' : '/a'},{'path' : '/b'}]
        self.meta_body = {
            "bytes": 0, 
            "contents": [
                {
                    "bytes": 879394, 
                    "compress": False, 
                    "encrypt": False, 
                    "icon": "page_white_acrobat", 
                    "is_dir": False, 
                    "modified": "Fri, 10 May 2013 02:03:48 +0000", 
                    "mtime": "Wed, 08 May 2013 08:26:08 +0000", 
                    "path": "/TN/Chrysanthemum.jpg", 
                    "rev": "d9d10a58ff63c243fc0e527feccc58d0", 
                    "root": "File Cruiser", 
                    "shared_flag": False, 
                    "size": "858.0 KB", 
                    "store_bytes": 879394, 
                    "store_size": "858.0 KB", 
                    "thumb_exists": False
                }, 
                {
                    "bytes": 0, 
                    "hash": "5ceb6fed399a1d989cc7decbc628d895", 
                    "icon": "folder_public", 
                    "is_dir": True, 
                    "modified": "Tue, 14 May 2013 14:52:27 +0000", 
                    "path": "/TN/YES", 
                    "rev": "5ceb6fed399a1d989cc7decbc628d895", 
                    "root": "File Cruiser", 
                    "shared_flag": False, 
                    "size": "0 Bytes", 
                    "thumb_exists": False
                }
            ], 
            "hash": "6e3f35d21c954c4f3d3b29a4d6a8cdcd", 
            "icon": "folder_public", 
            "is_dir": True, 
            "modified": "Tue, 14 May 2013 17:09:59 +0000", 
            "path": "/TN", 
            "rev": "6e3f35d21c954c4f3d3b29a4d6a8cdcd", 
            "root": "File Cruiser", 
            "shared_flag": True, 
            "size": "0 Bytes", 
            "thumb_exists": False
        }
        
    # Add trash_list for trash.py by Annis
    def trash_list(self, junk, junk2):
        if junk2['tenant_id'] == 'no':
            raise FileNotFoundError('')
        return RESP.ok(content = json.dumps({}))
        
    def trash_remove(self, junk, junk2, junk3 = None):
        return RESP.ok(content = json.dumps({'path':'a'}))
        
    def trash_restore(self, junk, junk2, junk3 = None):
        return RESP.ok(content = json.dumps({'path':'a'}))
        
    def trash(self, junk, junk2, junk3 = None):
        return RESP.ok(content = json.dumps({'path':'a'})), 'i', 'j'
        
    def get_meta(self, junk, junk2, junk3):
        if junk2 == '/not_exist' :
            return RESP.not_found('not found')
        return RESP.ok(content = json.dumps(self.meta_body))
        
    def move(self, junk, junk2, junk3, junk4, junk5, is_copy = None):
        return RESP.created(content = json.dumps(self.shared_body)), True, 100
        
    def delete(self, junk, junk2, junk3):
        return RESP.ok(content = json.dumps(self.shared_body)), True, 100
        
    def restore(self, junk, junk2, junk3):
        return RESP.ok(content = json.dumps(self.shared_body))

    def revisions(self, junk, junk2, junk3):
        return RESP.ok(content = json.dumps(self.shared_body))
        
    def search(self, junk, junk2, junk3, junk4):
        return RESP.ok(content = json.dumps(self.search_body))
        
    def downloadData(self, junk, junk2, junk3):
        return RESP.ok()
        
    def uploadData(self, junk, junk2, junk3):
        return RESP.created(content = json.dumps(self.shared_body))
        
    def chunk_upload(self, junk, junk2, junk3):
        return RESP.created(), 'id'
        
    def commit_chunk_upload(self, junk, junk2, junk3):
        return RESP.created(content = json.dumps(self.shared_body)), 'id'
       
class FakePika():
    def __init__(self, logger, conf):
        pass
        
    def publish_msg(self, junk):
        pass
        
class FakeKS():
    def __init__(self, url, token):
        pass
        
    def get_user(self, junk, junk2):
        return [{
                'domain_id' : 'e',
                'tenantId'  : 'c',
                'email'     : 'test@test',
                'id'        : 'a'
            }]
        
    # Add if-else to let trash.py testing "no content" scenario    
    def get_user_tenants(self, junk, junk2):
        if junk == 'n':
            return [{
            'quota'     : 999,
            'name'      : 'team',
            'id'        : 'no'
        }]
        else:
            return [{
                'quota'     : 999,
                'name'      : 'team',
                'id'        : 'team'
            }]
        
    def get_admin_token(self):
        return ''
        
class FakeApp():
    pass
        
class FakeLogger():
    def info(self, junk): pass
    
class FakeRequest():
    def __init__(self, headers = None, GET = None, body = None):
        self.headers = headers
        self.GET = GET
        self.body = body
        
class FakeMemcache(object):

    def __init__(self):
        self.store = {}

    def get(self, key):
        return self.store.get(key)

    def set(self, key, value, timeout=0):
        self.store[key] = value
        return True

    def incr(self, key, timeout=0):
        self.store[key] = self.store.setdefault(key, 0) + 1
        return self.store[key]

    @contextmanager
    def soft_lock(self, key, timeout=0, retries=5):
        yield True

    def delete(self, key):
        try:
            del self.store[key]
        except Exception:
            pass
        return True
    
def fake_init(self):
    self.server_addr = 'server_address'
    self.action = 'action'
    self.app    = FakeApp()
    self.logger = FakeLogger()
    self.db     = FakeMongo(None, None)
    self.fileop = FakeFileOP(None, None)
    self.pika   = FakePika(None, None)
    self.ks     = FakeKS(None, None)
    self.cache  = FakeMemcache()
    self.deny_path = ['/shared', '/shared/', '/team', '/team/', '/']
