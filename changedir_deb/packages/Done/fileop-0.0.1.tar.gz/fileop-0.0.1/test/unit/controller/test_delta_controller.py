from monga.controller.delta import DeltaController
from monga.common.utils import json_dump
from monga.common.exception import *
import unittest
from utils import *
import json

class TestDeltaController(unittest.TestCase):

    def setUp(self):
        _c = DeltaController
        _c.__init__ = fake_init
        self._c = _c()
        self._user = {
            'user_id'     : 'a',
            'user_name'   : 'b',
            'tenant_id'   : 'c',
            'tenant_name' : 'd',
            'domain_id'   : 'e',
            'domain_name' : 'f',
        }
        
    def test_POST(self):
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, object)
        self.assertEquals(200 , _resp.status_int)
        
    def test_POST_role_fail_case(self):
        _user = self._user
        _user['user_roles'] = ['guestt']
        _resp = self._c.POST(_user, object)
        self.assertEquals(403 , _resp.status_int)
        
    def test_POST_with_cursor(self):
        _object = FakeRequest()
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object)
        self.assertEquals(200 , _resp.status_int)
        
    def test_POST_has_more_number(self):
        _object = FakeRequest(GET = {'cursor' : 123})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object)
        _len = len(json.loads(_resp.body)['entries'])
        self.assertEquals(200 , _resp.status_int)  
        self.assertEquals(100 , _len)
        
if __name__ == '__main__':
    unittest.main()
