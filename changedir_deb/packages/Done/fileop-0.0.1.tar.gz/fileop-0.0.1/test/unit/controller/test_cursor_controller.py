from monga.controller.cursor import CursorController
from monga.common.utils import json_dump
from monga.common.exception import *
import unittest
from utils import *
import json

class TestCursorController(unittest.TestCase):

    def setUp(self):
        _c = CursorController
        _c.__init__ = fake_init
        self._c = _c()
        self._user = {
            'user_id'     : 'a',
            'user_name'   : 'b',
            'tenant_id'   : 'c',
            'tenant_name' : 'd',
            'domain_id'   : 'e',
            'domain_name' : 'f',
        }
        
    def test_GET(self):
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.GET(_user, object)
        self.assertEquals(200 , _resp.status_int)
        
    def test_GET_with_wrong_role(self):
        _user = self._user
        _user['user_roles'] = ['guestt']
        _resp = self._c.GET(_user, object)
        self.assertEquals(403 , _resp.status_int)
        
if __name__ == '__main__':
    unittest.main()
