from monga.controller.trash import TrashController
from monga.common.utils import json_dump
from monga.common.exception import *
import unittest
from utils import *
import json

class TestTrashController(unittest.TestCase):
    
    def setUp(self):
        _c = TrashController
        _c.__init__ = fake_init
        self._c = _c()
        self._user = {
            'user_id'     : 'a',
            'user_name'   : 'b',
            'tenant_id'   : 'c',
            'tenant_name' : 'd',
            'domain_id'   : 'e',
            'domain_name' : 'f',
            'user_token'  : '123',
        }
        self._tenant = [{'name' : 'annis'}]
     
    # Is user storage     
    def test_get_tenant_user(self):
        _tenant = self._tenant
        _resp = self._c.get_tenant(_tenant, 'annis', 'annis')
        self.assertEquals(False, _resp[1])
        
    # Is team storage     
    def test_get_tenant_team(self):
        _tenant = self._tenant
        _resp = self._c.get_tenant(_tenant, 'team', 'annis')
        self.assertEquals(True, _resp[1])
        
    #--------------------------
    # base GET testing
    def test_GET_admin(self):
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.GET(_user, object)
        self.assertEquals(200 , _resp.status_int)
        
    # test no content in trash scenario    
    def test_GET_no_content(self):
        _user = self._user
        _user['user_id'] = 'n' #user n has no content in trash
        _user['user_roles'] = ['admin']
        _resp = self._c.GET(_user, object)
        self.assertEquals(200 , _resp.status_int)
        
    #--------------------------
    # base DELETE testing
    def test_DELETE_admin(self):
        _object = FakeRequest(GET={'team':'team'})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.DELETE(_user, _object, 'a')
        self.assertEquals(200 , _resp.status_int)
        
    # Bad Request: has no team value
    def test_DELETE_noteam_name(self):
        _object = FakeRequest(GET={'team':''})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.DELETE(_user, _object, 'a')
        self.assertEquals(400 , _resp.status_int)
    
    # Change role: member
    def test_DELETE_member(self):
        _object = FakeRequest(GET={'team':'team'})
        _user = self._user
        _user['user_roles'] = ['member']
        _resp = self._c.DELETE(_user, _object, 'a')
        self.assertEquals(200 , _resp.status_int)
    
    # Change role: guest
    def test_DELETE_guest(self):
        _object = FakeRequest(GET={'team':'team'})
        _user = self._user
        _user['user_roles'] = ['guest']
        _resp = self._c.DELETE(_user, _object, 'a')
        self.assertEquals(403 , _resp.status_int)
    
    # Enter BadRequestError('Can not find this space')  
    def test_DELETE_nospace(self):
        _object = FakeRequest(GET={'team':' '})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.DELETE(_user, _object, 'a')
        self.assertEquals(400 , _resp.status_int)
    
    #---------------------------
    # base PUT testing
    def test_PUT_admin(self):
        _object = FakeRequest(GET={'team':'team'})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.PUT(_user, _object, 'a')
        self.assertEquals(200 , _resp.status_int)
        
    # Bad Request: has no team value
    def test_PUT_admin(self):
        _object = FakeRequest(GET={'team':''})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.PUT(_user, _object, 'a')
        self.assertEquals(400 , _resp.status_int)
    
    # Change role: member
    def test_PUT_member(self):
        _object = FakeRequest(GET={'team':'team'})
        _user = self._user
        _user['user_roles'] = ['member']
        _resp = self._c.PUT(_user, _object, 'a')
        self.assertEquals(200 , _resp.status_int)
    
    # Change role: guest
    def test_PUT_guest(self):
        _object = FakeRequest(GET={'team':'team'})
        _user = self._user
        _user['user_roles'] = ['guest']
        _resp = self._c.PUT(_user, _object, 'a')
        self.assertEquals(403 , _resp.status_int)  
    
    # Enter BadRequestError('Can not find this space')      
    def test_PUT_nospace(self):
        _object = FakeRequest(GET={'team':' '})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.PUT(_user, _object, 'a')
        self.assertEquals(400 , _resp.status_int)   

    #--------------------------
    # base POST testing
    def test_POST_admin(self):
        _object = FakeRequest(GET={'team':'team'})
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object, 'a')
        self.assertEquals(200 , _resp.status_int)
        
    # Change role: member
    def test_POST_member(self):
        _object = FakeRequest(GET={'team':'team'})
        _user = self._user
        _user['user_roles'] = ['member']
        _resp = self._c.POST(_user, _object, 'a')
        self.assertEquals(200 , _resp.status_int)
    
    # Change role: guest
    def test_POST_guest(self):
        _object = FakeRequest(GET={'team':'team'})
        _user = self._user
        _user['user_roles'] = ['guest']
        _resp = self._c.POST(_user, _object, 'a')
        self.assertEquals(403 , _resp.status_int)   
        
         
if __name__ == '__main__':
    unittest.main()
