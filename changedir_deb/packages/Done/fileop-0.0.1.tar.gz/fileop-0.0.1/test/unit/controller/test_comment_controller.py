from monga.controller.comment import CommentController
from monga.common.utils import json_dump
from monga.common.exception import *
import unittest
from utils import *
import json

class TestCommentController(unittest.TestCase):
    
    def setUp(self):
        _c = CommentController
        _c.__init__ = fake_init
        self._c = _c()
        self._user = {
            'user_id'     : 'a',
            'user_name'   : 'b',
            'tenant_id'   : 'c',
            'tenant_name' : 'd',
            'domain_id'   : 'e',
            'domain_name' : 'f',
         }
        
    # base POST testing
    def test_POST(self):
        _object = FakeRequest(body=json.dumps({'msg':'This is test comment'}))
        _user = self._user
        _user['user_roles'] = ['admin']
        _path='/a'
        _resp = self._c.POST(_user, _object, _path)
        self.assertEquals(201 , _resp.status_int)
    
    #-------------------------------
    # change msg variable
    def test_POST_no_comment(self):
        _object = FakeRequest(body=json.dumps({'msg':''}))
        _user = self._user
        _user['user_roles'] = ['admin']
        _path='/a'
        _resp = self._c.POST(_user, _object, _path)
        self.assertEquals(400 , _resp.status_int)
    
    # insert space in msg 
    def test_POST_hasspace_comment(self):
        _object = FakeRequest(body=json.dumps({'msg':' s fs '}))
        _user = self._user
        _user['user_roles'] = ['admin']
        _path='/a'
        _resp = self._c.POST(_user, _object, _path)
        self.assertEquals(201 , _resp.status_int)
    
    #msg length over 256
    def test_POST_overlength_comment(self):
        message = '12345678'
        _object = FakeRequest(body=json.dumps({'msg': message*100}))
        _user = self._user
        _user['user_roles'] = ['admin']
        _path='/a'
        _resp = self._c.POST(_user, _object, _path)
        self.assertEquals(400 , _resp.status_int)

    #----------------------------------------    
    # change path variable: /shared/
    def test_POST_denypath_share1(self):
        _object = FakeRequest(body=json.dumps({'msg': 'werwer'}))
        _user = self._user
        _user['user_roles'] = ['admin']
        _path= '/shared/'
        _resp = self._c.POST(_user, _object, _path)
        self.assertEquals(400 , _resp.status_int)

    # change path variable: /shared
    def test_POST_denypath_share2(self):
        _object = FakeRequest(body=json.dumps({'msg': 'werwer'}))
        _user = self._user
        _user['user_roles'] = ['admin']
        _path='/shared'
        _resp = self._c.POST(_user, _object, _path)
        self.assertEquals(400 , _resp.status_int)
        
    # change path variable: /
    def test_POST_denypath_slash1(self):
        _object = FakeRequest(body=json.dumps({'msg': 'werwer'}))
        _user = self._user
        _user['user_roles'] = ['admin']
        _path='/'
        _resp = self._c.POST(_user, _object, _path)
        self.assertEquals(400 , _resp.status_int)
        
    # change path variable: /team
    def test_POST_denypath_team1(self):
        _object = FakeRequest(body=json.dumps({'msg': 'werwer'}))
        _user = self._user
        _user['user_roles'] = ['admin']
        _path='/team'
        _resp = self._c.POST(_user, _object, _path)
        self.assertEquals(400 , _resp.status_int)
        
    # change path variable: /team/
    def test_POST_denypath_team2(self):
        _object = FakeRequest(body=json.dumps({'msg': 'werwer'}))
        _user = self._user
        _user['user_roles'] = ['admin']
        _path='/team/'
        _resp = self._c.POST(_user, _object, _path)
        self.assertEquals(400 , _resp.status_int)
        
    # No path in POST funciton
    def test_POST_no_path(self):
        _object = FakeRequest(body=json.dumps({'msg': 'werwer'}))
        _user = self._user
        _user['user_roles'] = ['admin']
        _resp = self._c.POST(_user, _object)
        self.assertEquals(400 , _resp.status_int)
        
    #-----------------------------
    #change user variable: member
    def test_POST_role_member(self):
        _object = FakeRequest(body=json.dumps({'msg': 'werwer'}))
        _user = self._user
        _user['user_roles'] = ['member']
        _path='/a'
        _resp = self._c.POST(_user, _object, _path)
        self.assertEquals(201 , _resp.status_int)
        
    #change user variable: guest
    def test_POST_role_guest(self):
        _object = FakeRequest(body=json.dumps({'msg': 'werwer'}))
        _user = self._user
        _user['user_roles'] = ['guest']
        _path='/a'
        _resp = self._c.POST(_user, _object, _path)
        self.assertEquals(403 , _resp.status_int)
        
    #---------------------------
    # base GET testing
    def test_GET(self):
        _user = self._user
        _user['user_roles'] = ['admin']
        _path='/a'
        _resp = self._c.GET(_user, object, _path)
        self.assertEquals(200 , _resp.status_int)
        
    # change role: guest
    def test_GET_role_guest(self):
        _user = self._user
        _user['user_roles'] = ['guestt']
        _path='/a'
        _resp = self._c.GET(_user, object, _path)
        self.assertEquals(403 , _resp.status_int)
        
    # change role: member
    def test_GET_role_member(self):
        _user = self._user
        _user['user_roles'] = ['member']
        _path='/a'
        _resp = self._c.GET(_user, object, _path)
        self.assertEquals(200 , _resp.status_int)
        
    #----------------------    
    # change path: /shared
    def test_GET_denypath_share(self):
        _user = self._user
        _user['user_roles'] = ['admin']
        _path='/shared'
        _resp = self._c.GET(_user, object, _path)
        self.assertEquals(400 , _resp.status_int)
        
    # change path: /team
    def test_GET_denypath_team(self):
        _user = self._user
        _user['user_roles'] = ['admin']
        _path='/team'
        _resp = self._c.GET(_user, object, _path)
        self.assertEquals(400 , _resp.status_int)
        
    # change path: /team/ad/
    def test_GET_denypath_team(self):
        _user = self._user
        _user['user_roles'] = ['admin']
        _path='/team/ad/'
        _resp = self._c.GET(_user, object, _path)
        self.assertEquals(200 , _resp.status_int)
        
    # change path: /team/ad
    def test_GET_denypath_team(self):
        _user = self._user
        _user['user_roles'] = ['admin']
        _path='/team/ad'
        _resp = self._c.GET(_user, object, _path)
        self.assertEquals(400 , _resp.status_int)
        
if __name__ == '__main__':
    unittest.main()
