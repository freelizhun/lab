from monga.controller.base import Controller
from monga.common.utils import json_dump
from monga.common.exception import *
from monga.common.exception import BadRequestError as baderror
import unittest
from utils import *
import json

class TestBaseController(unittest.TestCase):

    def setUp(self):
        _c = Controller
        _c.__init__ = fake_init
        self._c = _c()
        
    def test_ks_get_user_tenants(self):
        self.assertEquals([{'id': 'team', 'quota': 999, 'name': 'team'}],
                          self._c._ks_get_user_tenants('',''))

    def test_check_special_path(self):
        self.assertRaises(baderror, self._c.check_special_path, '/')
        self.assertRaises(baderror, self._c.check_special_path, '/team')
        self.assertRaises(baderror, self._c.check_special_path, '/team/')
        self.assertRaises(baderror, self._c.check_special_path, '/shared/')
        self.assertRaises(baderror, self._c.check_special_path, '/shared')
        self.assertRaises(baderror, self._c.check_special_path, '/team/a')

    def test_decode_and_check_path(self):
        self.assertRaises(baderror, self._c.decode_and_check_path, '/')
        self.assertRaises(baderror, self._c.decode_and_check_path, '/team')
        self.assertRaises(baderror, self._c.decode_and_check_path, '/team/')
        self.assertRaises(baderror, self._c.decode_and_check_path, '/shared/')
        self.assertRaises(baderror, self._c.decode_and_check_path, '/shared')
        self.assertRaises(baderror, self._c.decode_and_check_path, '/team/a')
        self.assertEquals(' ', self._c.decode_and_check_path('%20'))

    def test_encode_url(self):
        self.assertEquals('%20', self._c.encode_url(' '))
        
    def test_decode_url(self):
        self.assertEquals(' ', self._c.decode_url('%20'))
        
    def test_check_role_admin(self):
        _roles = ['admin']
        self.assertEquals(True, self._c.check_role(_roles, 'w'))
        self.assertEquals(True, self._c.check_role(_roles, 's'))
        self.assertEquals(True, self._c.check_role(_roles, 'r'))
        
    def test_check_role_member(self):
        _roles = ['member']
        self.assertEquals(True, self._c.check_role(_roles, 'w'))
        self.assertEquals(False, self._c.check_role(_roles, 's'))
        self.assertEquals(True, self._c.check_role(_roles, 'r'))
        
    def test_check_role_guest(self):
        _roles = ['guest']
        self.assertEquals(False, self._c.check_role(_roles, 'w'))
        self.assertEquals(False, self._c.check_role(_roles, 's'))
        self.assertEquals(True, self._c.check_role(_roles, 'r'))
        
    def test_check_role_none(self):
        _roles = ['guestt']
        self.assertEquals(False, self._c.check_role(_roles, 'w'))
        self.assertEquals(False, self._c.check_role(_roles, 's'))
        self.assertEquals(False, self._c.check_role(_roles, 'r'))
        
    def test_get_result(self):
        self.assertEquals(True, self._c.get_result('200 OK'))
        self.assertEquals(False, self._c.get_result('400 BadRequest'))
        self.assertEquals(False, self._c.get_result('500 InternalServerError'))
        
    def test_get_shared_path(self):
        self.assertEquals('/shared/a', self._c.get_shared_path('/shared/a/b'))
        self.assertEquals('/shared/a', self._c.get_shared_path('/shared/a/b/c'))
        
    def test_get_share_path(self):
        _path, _extra = self._c.get_share_path('/shared/a')
        self.assertEquals('/shared/a', _path)
        self.assertEquals(None, _extra)
        _path, _extra = self._c.get_share_path('shared/a')
        self.assertEquals('/shared/a', _path)
        self.assertEquals(None, _extra)
        _path, _extra = self._c.get_share_path('shared/a/b')
        self.assertEquals('/shared/a', _path)
        self.assertEquals('/b', _extra)
        _path, _extra = self._c.get_share_path('shared/a/b/c/d')
        self.assertEquals('/shared/a', _path)
        self.assertEquals('/b/c/d', _extra)
        
    def test_check_path(self):
        self.assertEquals('/shared/a', self._c.check_path('/shared/a'))
        self.assertEquals('/shared/a', self._c.check_path('shared/a'))
        
    def test_judge_special_folder_case(self):
        is_share, is_team = self._c.judge_special_folder_case('/shared/a')
        self.assertEquals(True , is_share)
        self.assertEquals(False , is_team)
        is_share, is_team = self._c.judge_special_folder_case('/team/a/a')
        self.assertEquals(False , is_share)
        self.assertEquals(True , is_team)
        is_share, is_team = self._c.judge_special_folder_case('/a/a')
        self.assertEquals(False , is_share)
        self.assertEquals(False , is_team)
        
    def test_get_real_user(self):
        _data = {
            'link_user_id'     : 'a',
            'link_user_name'   : 'b',
            'link_tenant_id'   : 'c',
            'link_tenant_name' : 'd',
            'link_domain_id'   : 'e',
            'link_domain_name' : 'f',
        }
        _data2 = {
            'user_id'     : 'a',
            'user_name'   : 'b',
            'tenant_id'   : 'c',
            'tenant_name' : 'd',
            'domain_id'   : 'e',
            'domain_name' : 'f',
        }
        self.assertEquals(_data2 , self._c.get_real_user(_data2, _data))
        
    def test_get_team_name(self):
        self.assertEquals('a' , self._c.get_team_name('/team/a/b'))
        self.assertEquals('b' , self._c.get_team_name('/team/b/b/c/c/'))
        self.assertEquals(None , self._c.get_team_name('/team'))
        
    def test_get_team_path(self):
        self.assertEquals(('/team/a','a','/b'), 
            self._c.get_team_path('/team/a/b'))
        self.assertEquals(('/team/a','a','/b/c'), 
            self._c.get_team_path('/team/a/b/c'))   
        self.assertEquals(('/team/a','a', None), 
            self._c.get_team_path('/team/a'))
        self.assertEquals(('/a/a','a', None), 
            self._c.get_team_path('/a/a'))
         
    def test_get_tenant_quota(self):
        _user1 = {'tenant_id' : 'team', 'tenant_name' : 'team', 'user_id':'a'}
        _user2 = {'tenant_id' : 'team2', 'tenant_name' : 'team2', 'user_id':'a'}
        self.assertEquals(999, self._c.get_tenant_quota(_user1))
        self.assertEquals(5368709120, self._c.get_tenant_quota(_user2))
        
    def test_check_shared(self):
        _user = {
            'user_id'     : 'a',
            'user_name'   : 'b',
            'tenant_id'   : 'c',
            'tenant_name' : 'd',
            'domain_id'   : 'e',
            'domain_name' : 'f',
        }
        real_user = {
            'user_id'     : 'm',
            'user_name'   : 'n',
            'tenant_id'   : 'o',
            'tenant_name' : 'p',
            'domain_id'   : 'q',
            'domain_name' : 'r',
        }
        team_user = {
            'user_id'     : 'a',
            'user_name'   : 'b',
            'tenant_id'   : 'team',
            'tenant_name' : 'team',
            'domain_id'   : 'e',
            'domain_name' : 'f',
            'quota'       : 999
        }
        #Path not shared
        res_user, res_path, res_share, res_team = \
            self._c.check_special_folder(_user, '/a')
        self.assertEquals(_user , res_user)
        self.assertEquals('/a' , res_path)
        self.assertEquals(False , res_share)
        self.assertEquals(False , res_team)
        #Path is shared
        res_user, res_path, res_share, res_team = \
            self._c.check_special_folder(_user, '/shared/a')
        self.assertEquals(real_user , res_user)
        self.assertEquals('/s' , res_path)
        self.assertEquals(True , res_share)
        self.assertEquals(False , res_team)
        #Path is shared
        res_user, res_path, res_share, res_team = \
            self._c.check_special_folder(_user, '/shared/a/d')
        self.assertEquals(real_user , res_user)
        self.assertEquals('/s/d' , res_path)
        self.assertEquals(True , res_share)
        self.assertEquals(False , res_team)
        #Path is team
        res_user, res_path, res_share, res_team = \
            self._c.check_special_folder(_user, '/team/team/a')
        self.assertEquals(team_user , res_user)
        self.assertEquals('/a' , res_path)
        self.assertEquals(False , res_share)
        self.assertEquals(True , res_team)
        #Path is team
        res_user, res_path, res_share, res_team = \
            self._c.check_special_folder(_user, '/team/team/d')
        self.assertEquals(team_user , res_user)
        self.assertEquals('/d' , res_path)
        self.assertEquals(False , res_share)
        self.assertEquals(True , res_team)
        #Path is locked
        res_user, res_path, res_share, res_team = \
            self._c.check_special_folder(_user, '/shared/a/d',lock = True)
        self.assertEquals(real_user , res_user)
        self.assertEquals('/s/d' , res_path)
        self.assertEquals(True , res_share)
        self.assertEquals(False , res_team)
        #permission
        res_user, res_path, res_share, res_team = \
            self._c.check_special_folder(_user, '/shared/a/d', 'write')
        self.assertEquals(real_user , res_user)
        self.assertEquals('/s/d' , res_path)
        self.assertEquals(True , res_share)
        self.assertEquals(False , res_team)
        try: 
            self._c.check_special_folder(_user, '/shared')
        except BadRequestError:
            pass
            
    def test_modfied_shared_contents(self):
        ref = {
            'path' : '/s',
            'contents' : [{'path':'/s/obj'},{'path':'/s/dir'}]
        }
        res = {
            'path' : '/shared/a',
            'contents' : [{'path':'/shared/a/obj'},{'path':'/shared/a/dir'}]
        }
        _res = self._c.modfied_shared_contents(json.dumps(ref), None, 
                                               '/shared/a')
        self.assertEquals(json.loads(_res) , res)
        
    def test_modfied_team_contents(self):
        ref = {
            'path' : '/s',
            'contents' : [{'path':'/s/obj'},{'path':'/s/dir'}]
        }
        res = {
            'path' : '/team/b/s',
            'contents' : [{'path':'/team/b/s/obj'},{'path':'/team/b/s/dir'}]
        }
        _res = self._c.modfied_team_contents(json.dumps(ref), '/team/b')
        self.assertEquals(json.loads(_res) , res)
        
    def test_modfiy_userinfo(self):
        orig = {'tenant_id' : 'a', 'tenant_name' : 'b'}
        new  = {'tenant_id' : 'tenant_id', 'tenant_name' : 'tenant_name'}
        self.assertEquals(new, self._c.modify_userinfo(orig, new, True))
        self.assertEquals(orig, self._c.modify_userinfo(orig, new, False))
        
if __name__ == '__main__':
    unittest.main()
