from __future__ import with_statement
from swift.common.wsgi import WSGIContext
from swift.common.utils import json, get_logger, TRUE_VALUES
from webob import Request
from swift.common.swob import HTTPBadRequest, HTTPMethodNotAllowed
from monga.common.backend.mongo import MongoDBConnector
from monga.controller.base import Controller
from monga.common import response as RESP
from bson.objectid import ObjectId
from monga.common.utils import json_dump, split_path
from monga.fileop.FileOp import FileOp
from monga.common.ks_client import KeystoneClient
from monga.common.exception import *
from dateutil.parser import parse as time_parse
from monga.common.pika_client import PikaClient
import time
import datetime
import json

class AdminExtMiddleware(WSGIContext, Controller):

    def __init__(self, app, conf):
        self.app = app
        self.conf = conf
        self.logger = get_logger(conf, log_route = 'Admin-Ext')
        self.logger.info('AdminExt Middleware Start')
        self.mongo_path = conf.get('mongo_path', 'localhost')
        self.mongo_port = int(conf.get('mongo_port', 27017))
        #Auth conf
        self.auth_url = conf.get('auth_url',
                                 'http://localhost:35357/v3/')
        self.admin_role = conf.get('admin_role', 'admin')
        self.admin_token = conf.get('auth_admin_token', 'ADMIN')
        self.admin_name = conf.get('admin_name', 'admin')
        self.admin_password = conf.get('admin_password', 'admin')
        self.admin_tenant_name = conf.get('admin_tenant_name', 'admin')
        self.admin_domain_name = conf.get('admin_domain_name', 'Default')
        self.ks = KeystoneClient(path   = self.auth_url,
                                 token  = self.admin_token,
                                 admin  = self.admin_name,
                                 pwd    = self.admin_password,
                                 tenant = self.admin_tenant_name,
                                 domain = self.admin_domain_name)
        #self.token = self.ks.get_admin_token()
        self.token = None
        self.fileop = FileOp
        WSGIContext.__init__(self, app)
        
    def get_db(self):
        return MongoDBConnector(self.mongo_path, self.mongo_port)

    def check_token(self, req):
        #Check token first
        token = req.headers.get('X-Auth-Token', None)
        if not token :
            return RESP.unauthorized('Lack Token')

        _res = None
        _auth = False

        try: 
            _res = self.ks.verify_token(token, self.token)
        except UnauthorizedError :
            self.token = self.ks.token
            _res = self.ks.verify_token(token, self.token)
        except Exception as err:
            self.logger.error(err)
            return RESP.unauthorized('Auth Failed')

        if _res :
            for _role in _res['token']['roles'] :
                if _role.get('name', '') == 'admin': _auth = True

        if not _auth :
            return RESP.unauthorized('Your account can\'t access admin api')

        return None
            
    def api_controllers(self, req, action):
        #Check admin token first
        check_token_result = self.check_token(req)
        if check_token_result :
            return check_token_result
        handler = getattr(self, action)
        return handler(req)
            
    def used_api(self, req):
        _path = split_path(req.path)
        if len(_path) == 2 :
            data = self.get_db().find_quota({}, multi = True)
            entries = []
            for _data in data :
                del _data['_id']
                entries.append(_data)
            return RESP.ok(content = json_dump(entries))
        elif len(_path) == 3 :
            data = self.get_db().find_quota({'tenant_id': _path[2]})
            return RESP.ok(content = json_dump(data))
        else :
            return RESP.not_found('Wrong URL')

    def device_api(self, req):
        _path = split_path(req.path)
        #/v1/device?user=<user>&domain=<domain>
        if len(_path) == 2 and req.method == 'GET':
            try:
                user   = self.decode_url(req.GET['user'])
                domain = self.decode_url(req.GET['domain'])
            except Exception:
                return RESP.bad_request('Lack query value')
            #Get data
            datas = self.get_db().find_device(user, domain)
            entries = []
            for data in datas :
                _data = data.copy()
                _data['id'] = str(_data['_id'])
                del _data['_id']
                entries.append(_data)
            return RESP.ok(content = json_dump(entries))
        #/v1/device/<id>          -->disable
        #/v1/device/<id>?enable=1 -->enable
        elif len(_path) == 3 and req.method == 'PUT':
            try:
                self.decode_url(req.GET['enable'])
                enable = 1
            except Exception:
                enable = 0
            if enable :
                _res = self.get_db().enable_device(_path[2])
            else :
                _res = self.get_db().disable_device(_path[2])
                _device = self.get_db().find_device_by_id(_path[2])
                _message = {
                    'user_name'   : _device['user'],
                    'domain_name' : _device['domain'],
                    'agent'       : _device['agent'],
                    'action'      : 'wipeout'
                }
                #user pika to send wipeout comment
                PikaClient(self.logger, self.conf).publish_msg(_message)
            if _res.get('ok', None) :
                return RESP.created()
            else :
                return RESP.internal_error('Failed to update DB')
        #/v1/device/<id>
        elif len(_path) == 3 and req.method == 'DELETE':
            _res = self.get_db().delete_device(_path[2])
            if _res:
                return RESP.no_content()
            else :
                return RESP.internal_error('Failed to update DB')
        else :
            return RESP.not_found('Wrong URL')
            
    def deleted_api(self, req):
        _path = split_path(req.path)
        if len(_path) == 3 :
            tenant_id = _path[2]
            fp = self.fileop(self.logger, self.conf)
            fp.deletetenant(req, tenant_id)
            #Add log to clean all record in DB
            self.get_db().insert_log(
                       {'tenant_id' : tenant_id},
                        'CleanTenant',
                        method   = req.method,
                        result   = True)
            return RESP.no_content()
        else:
            return RESP.not_found('Wrong URL')
            
    def activity_api(self, req):
        def get_num(value, default) :
            try :
                value = int(value)
            except Exception:
                value = default
            return value
    
        #Handle request
        _path = split_path(req.path)
        if len(_path) == 3 :
            user_id = _path[2]
            _from = req.headers.get('X-Log-From', None)
            _to   = req.headers.get('X-Log-To',   None)
            _pass = get_num(req.headers.get('X-Log-Pass', 0), 0)
            _sort = get_num(req.headers.get('X-Log-Sort', 1), 1)
            _query = {'user_id' : user_id, 
                      'delta'   : { "$in" : ['Create', 'DELETE']}}
            _time = {}
            try :
                _from = int(_from)
                _time['$gte'] = _from
            except Exception:
                pass
            try :
                _to = int(_to)
                _time['$lte'] = _to
            except Exception:
                pass
            if _time != {}:
                _query['updated_time'] = _time
            _res = self.get_db().find_log(_query, sort = _sort, skip = _pass)
            entries = []
            count = 0
            #Fit entry data
            for _d in _res:
                _e = {
                    'size'   : _d['file_size'],
                    'action' : _d['action'],
                    'is_dir' : _d['is_dir'],
                    'update_time' : _d['updated_time']
                }
                if _d['action'] == 'FileCopy' or _d['action'] == 'FileMove' :
                    _e['from_path'] = self.check_path(_d['from_path'])
                    _e['to_path']   = self.check_path(_d['to_path'])
                else:
                    _e['path'] = self.check_path(_d['to_path'])
                entries.append(_e)
                count += 1
                if count == 100 :
                    break
            #Has more delta or not
            if count == 100:
                has_more = True
            else: has_more = False
            #Generate resp body
            resp_body = {
                'entries'  : entries,
                'has_more' : has_more,
                'counts'   : self.get_db().find_log_count(_query)
            } 
            return RESP.ok(content = json_dump(resp_body))
        else:
            return RESP.not_found('Wrong URL')

    def __call__(self, env, start_response):
        req = Request(env)
        if req.path.startswith('/v1/used') and req.method == 'GET':
            resp = self.api_controllers(req, 'used_api')
        elif req.path.startswith('/v1/delete') and req.method == 'DELETE':
            resp = self.api_controllers(req, 'deleted_api')
        elif req.path.startswith('/v1/activity') and req.method == 'GET':
            resp = self.api_controllers(req, 'activity_api')
        elif req.path.startswith('/v1/device') and \
            (req.method in ['GET', 'DELETE', 'PUT']):
            resp = self.api_controllers(req, 'device_api')
        else :
            resp = None
        if resp :
            return resp(env, start_response)
        else :
            return self.app(env, start_response)

def filter_factory(global_conf, **local_conf):
    conf = global_conf.copy()
    conf.update(local_conf)
    def adminext_filter(app):
        return AdminExtMiddleware(app, conf)
    return adminext_filter
