from __future__ import with_statement
from swift.common.wsgi import WSGIContext
from swift.common.utils import json, get_logger, split_path, TRUE_VALUES
from swift.common.constraints import check_utf8
from swift.common.swob import Request, Response
from swift.common.swob import HTTPBadRequest, HTTPMethodNotAllowed, \
    HTTPPreconditionFailed
from monga.common.backend.mongo import MongoDBConnector
from monga.common.ks_client import KeystoneClient
from monga.fileop.FileOp import FileOp
from monga.controller.base import Controller
from monga.common.utils import json_dump
from monga.common import response as RESP
import urllib
import time
import json

class DirectLinkMiddleware(WSGIContext, Controller):

    def __init__(self, app, conf):
        self.app = app
        self.conf = conf
        self.logger = get_logger(conf, log_route = 'DirectLink')
        self.logger.info('DirectLink Middleware Start')
        self.auth_url = conf.get('auth_url',
                                 'http://localhost:35357/v3/')
        self.admin_token = conf.get('auth_admin_token', 'ADMIN')
        self.admin_name = conf.get('admin_name', 'admin')
        self.admin_password = conf.get('admin_password', 'admin')
        self.admin_tenant_name = conf.get('admin_tenant_name', 'admin')
        self.admin_domain_name = conf.get('admin_domain_name', 'Default')
        self.ks = KeystoneClient(path   = self.auth_url,
                                 token  = self.admin_token,
                                 admin  = self.admin_name,
                                 pwd    = self.admin_password,
                                 tenant = self.admin_tenant_name,
                                 domain = self.admin_domain_name)
        self.mongo_path = conf.get('mongo_path', 'localhost')
        self.mongo_port = int(conf.get('mongo_port', 27017))
        self.fileop = FileOp
        WSGIContext.__init__(self, app)

    def get_db(self):
        return MongoDBConnector(self.mongo_path, self.mongo_port)
        
    def _check_utf8(self, req):
        try:
            if not check_utf8(req.path_info):
                self.logger.increment('errors')
                return HTTPPreconditionFailed(request=req,
                                              body='Invalid UTF8')
        except UnicodeError:
            self.logger.increment('errors')
            return HTTPPreconditionFailed(request=req, 
                                          body='Invalid UTF8')
        return None

    def __call__(self, env, start_response):
        req = Request(env)
        if req.path.startswith('/v1/links/') and req.method == 'GET':
        
            #Check UTF8
            _check_utf8 = self._check_utf8(req)
            if _check_utf8 :
                return _check_utf8(env, start_response)
                
            #Split path
            _spath = split_path(req.path, 1, 4, True)
            _match_url = '/' + '/'.join(_spath[0:3])
            
            #Direct link
            pwd = req.headers.get('X-Public-Password', None)
            _link = self.get_db().find_dlink({'match_url' : _match_url})

            #Check link exist or not
            if not _link:
                return RESP.not_found(error = 'Link not exist')(env,
                    start_response)

            if _link['pwd'] and not pwd :
                return RESP.unauthorized('Password not correct')(env,
                    start_response)
            elif _link['pwd'] :
                if _link['pwd'] != pwd :
                    return RESP.unauthorized('Password not correct')(env,
                        start_response)
                                        
            #Get fileop instance
            fp = self.fileop(self.logger, self.conf)
            
            #Check shared/team folder
            _user, _path, is_share, is_team = \
                self.check_special_folder(_link, _link['file_path'])
                
            #real file path
            if _spath[3] :
                _real_path = _path + '/' + \
                             urllib.unquote(_spath[3]).decode('utf-8')
            else:
                _real_path = _path
                
            #Check path is folder or file
            _resp = fp.get_meta(_user, _real_path, req)
            
            if not self.get_result(_resp.status):
                return _resp(env, start_response)
            else : 
                #Check this path is dir or not
                #If is dir, list subfolder
                _body = json.loads(_resp.body)
                if _body['is_dir'] :
                    #modified path for team and share case
                    if is_team :
                        _body['path'] = _body['path'].replace(
                            _path, _link['public_url'], 1)
                    elif is_share :
                        _body['path'] = _body['path'].replace(
                            _path, _link['public_url'], 1)
                    else :
                        _body['path'] = _body['path'].replace(
                            _link['file_path'], _link['public_url'], 1)
                            
                    _new_content = []
                    for _content in _body['contents'] :
                        #Modified path to link path
                        if is_team :
                            _content['path'] = _content['path'].replace(
                                _path, _link['public_url'], 1)
                        elif is_share :
                            _content['path'] = _content['path'].replace(
                                _path, _link['public_url'], 1)
                        else :
                            _content['path'] = _content['path'].replace(
                                _link['file_path'], _link['public_url'], 1)
                        _new_content.append(_content)
                        
                     #Generate body
                    _body['contents'] = _new_content
                    _resp.body = json_dump(_body)
                    
                    #Insert log
                    self.get_db().insert_log(_user, 
                                             'DriectLinkListFiles',
                                             to_path  = _spath[3],
                                             result   = \
                                                 self.get_result(_resp.status),
                                             is_share = is_share)
                    return _resp(env, start_response)
                    
            #If not dir Download data
            resp = fp.downloadData(_user, _real_path, req)
            _user['client_ip'] = env.get('REMOTE_ADDR', '')
            _user['device_name'] = env.get('HTTP_USER_AGENT', '')
            
            #Add log
            self.get_db().insert_log(_user, 
                                     'DriectLinkDownloadFile',
                                     to_path  = _link['public_url'],
                                     size     = \
                                         resp.headers.get('Content-Length', 0),
                                     result   = self.get_result(resp.status),
                                     is_share = is_share)
            return resp(env, start_response)
        return self.app(env, start_response)

def filter_factory(global_conf, **local_conf):
    conf = global_conf.copy()
    conf.update(local_conf)
    def directlink_filter(app):
        return DirectLinkMiddleware(app, conf)
    return directlink_filter
