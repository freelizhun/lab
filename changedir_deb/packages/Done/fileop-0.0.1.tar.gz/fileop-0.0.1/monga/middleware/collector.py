from __future__ import with_statement
import time
import os, uuid, errno
import tempfile
from swift.common.swob import Request
from swift.common.utils import (get_logger, TRUE_VALUES)
from urllib import unquote, quote
from monga.common import response as RESP
from shutil import rmtree
from monga.common.exception import *
from monga.common.ks_client import KeystoneClient
import json

class UserInfoCollector(object):
    def __init__(self, app, conf):
        self.app = app
        self.auth_url = conf.get('auth_url',
                                 'http://localhost:35357/v3/')
        self.default_quota = int(conf.get('default_quota', 5368709120))
        self.timeout = int(conf.get('cache_timeout', 3600))
        self.admin_token = conf.get('auth_admin_token', 'ADMIN')
        self.admin_name = conf.get('admin_name', 'admin')
        self.admin_password = conf.get('admin_password', 'admin')
        self.admin_tenant_name = conf.get('admin_tenant_name', 'admin')
        self.admin_domain_name = conf.get('admin_domain_name', 'Default')
        self.ks = KeystoneClient(path   = self.auth_url,
                                 token  = self.admin_token,
                                 admin  = self.admin_name,
                                 pwd    = self.admin_password,
                                 tenant = self.admin_tenant_name,
                                 domain = self.admin_domain_name)
        self.logger = get_logger(conf, log_route = 'GetTenantQuota')
        self.logger.info('User Info Collector Start')
        
    def __call__(self, env, start_response):
        req = Request(env)
        _cache = req.environ.get('swift.cache', None)
        user_id = req.headers['X-User-Id']
        user_name = req.headers['X-User-Name']
        tenant_id = req.headers['X-Project-Id']
        token = req.headers['X-Auth-Token']
        try:
            if _cache:
                _key = 'tenant_' + tenant_id
                tenants = _cache.get(_key)
                if not tenants :
                    tenants = self.ks.get_user_tenants(user_id, token)
                    for _tenant in tenants :
                        if _tenant['name'] == user_name :
                            quota = _tenant.get('quota', self.default_quota)
                    _cache.set(_key, json.dumps(tenants), 
                               timeout = self.timeout)
                else :
                    tenants = json.loads(tenants)
                    for _tenant in tenants :
                        if _tenant['name'] == user_name :
                            quota = _tenant.get('quota', self.default_quota)
            else:
                quota = self.ks.get_tenant(tenant_id, token).get('quota',
                                                             self.default_quota)
        except UnauthorizedError as e:
            return RESP.unauthorized(e)(env, start_response)
        except BadRequestError as e:
            return RESP.bad_request(e)(env, start_response)
        except InternalServerError as e:
            return RESP.internal_error(e)(env, start_response)
        env['HTTP_X_TENANT_QUOTA'] = quota
        return self.app(env, start_response)

def filter_factory(global_conf, **local_conf):
    conf = global_conf.copy()
    conf.update(local_conf)
    def exten_filter(app):
        return UserInfoCollector(app, conf)
    return exten_filter
