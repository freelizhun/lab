# -*- coding: UTF-8 -*-
#from webob import Request, Response
from monga.fileop import fileiter
import uuid
import hashlib
import os
import json
from monga.fileop.connector import Connector
import monga.fileop.dropBoxResponse as getRespBody
from monga.fileop.Error import MyError
from monga.fileop import utils
from monga.common import response as RESP
from monga.connector import get_connector
from eventlet import Timeout
import lz4
import unicodedata
#from monga.fileop.encutils import encData
from monga.fileop.encutils import encData
from swift.common.swob import HTTPAccepted, HTTPBadRequest, HTTPCreated, \
    HTTPInternalServerError, HTTPNoContent, HTTPNotFound, HTTPNotModified, \
    HTTPPreconditionFailed, HTTPRequestTimeout, HTTPUnprocessableEntity, \
    HTTPClientDisconnect, HTTPMethodNotAllowed, Request, Response, UTC, \
    HTTPInsufficientStorage, multi_range_iterator
from monga.common.exception import FileNotFoundError as FileNotFound
from monga.common.exception import UploadTimeOut
from monga.common.exception import BadRequestError as BadRequest
from monga.common.exception import FileBusyError 

#exception
#from monga.common import exception as exception
#from monga.common.exception import *
#from monga.fileop import excep 
#from excep import *
import md5

class FileOp(object):

    def __init__(self, log, conf):
        #self.conn = Connector()
        self.conn = get_connector(log, conf)
        self.log = log
        self.enc = encData()
        self.conf = conf
        self.upload_timeout = int(conf.get('upload_timeout',900))
        self.storage_chunk_size = int(conf.get('storage_chunk_size',1024000))
        
        

    def createUUID(self):
        return str(uuid.uuid1())

    def createHashUUID(self, hashName):
        self.log.debug(_( 'create HashUUID -------------'))
        if type(hashName).__name__=='unicode':
            hashNameStr =  unicodedata.normalize('NFKD', hashName).encode('ascii','ignore')
            hashName = hashNameStr

        #ret = uuid.uuid5(uuid.NAMESPACE_DNS, unicode(hashName))
        #return str(uuid.uuid5(uuid.NAMESPACE_DNS, hashNameStr))
        return str(md5.new(hashName).hexdigest())
          
        
    def getCheckSum(self, chunk):
        return hashlib.sha256(chunk).hexdigest()


    def _revisions(self, req, t_id, filepath):
        ret = self.conn.get_version_metadata(t_id, filepath)
        return ret
    def _uploadData(self, req, ud, t_id, fp, compressFlag=False, encryptFlag=False):
            self.log.debug(_( 'the uuid is %s'%ud))
            CHUNKSIZE = self.storage_chunk_size 
            fname = t_id+'/'+fp
            count = 0
            count_raw=0
            count_store=0
            chunk='init'
            #self.log.debug(_( req.environ['HTTP_X_META_FC_COMPRESS']
            #self.log.debug(_( bool(req.environ['HTTP_X_META_FC_COMPRESS'])

            #while chunk:
            try:
                #chunk = req.environ["wsgi.input"].read(CHUNKSIZE)
                reader = req.environ['wsgi.input'].read
                for chunk in iter(lambda: reader(CHUNKSIZE), ''):
                    count_raw=count_raw+len(chunk)
                    if compressFlag:
                        comchunk = lz4.compress(chunk)
                        chunk = comchunk

                    checksum = self.getCheckSum(chunk)
                    checksumFileName = checksum

                    if encryptFlag:
                        enc_data = self.enc.encrypt(chunk, checksum)
                        chunk = enc_data
                        checksumFileName ='e-'+checksum

                    self.log.debug(_('upload -------'))
                    ret = self.conn.upload(t_id, ud, chunk, checksumFileName )
                    self.log.debug(_('upload finished -------'))
                    count_store=count_store+len(chunk)
                    self.log.debug(_('store size %r %r'%(count_raw, count_store)))

            except:
                raise MyError('connection break')
                self.log.debug(_( 'connection break'))
            if count_raw==0 and count_store==0:
                chunk=''
                checksum = self.getCheckSum(chunk)
                checksumFileName = checksum
                ret = self.conn.upload(t_id, ud, chunk, checksumFileName )
                
            return str(count_raw),str(count_store)

    def _checkFileMetaFlag(self, filemeta, flagtype):

        FlagC = False
        if filemeta[flagtype]:
            if filemeta[flagtype].lower()=='true':
                FlagC = True
                return FlagC
        else:
            FlagC = False
        return FlagC
        
    def _downloadData(self, req, resp, t_id, fp, file_version):
        try:
            chunksize= self.storage_chunk_size
            uid='aaa'
            self.log.debug(_( 'file path %s'%fp))
            self.log.debug(_( 'tid %s'%t_id))
            fpp = t_id+'/'+fp
            filemeta= self.conn.get_metadata(t_id, fp, file_version)
            chunkList= filemeta['manifest']
            comFlag = filemeta.get('compress')
            encFlag = filemeta.get('encrypt')
            self.log.debug(_('compress encrypt flag %r %r'%(comFlag, encFlag)))
            resp.app_iter = fileiter.FileIterable(chunkList, t_id, self.log, self.conf, comFlag, encFlag)
        except:
            self.log.info(_('download exception'))
            raise MyError('connection break')
        return resp

    def _getMeta(self, req, t_id, path):
        metainfo = self.conn.get_metadata(t_id, path, file_version=None, is_list=True)
        return metainfo

    def _createFolder(self, req, t_id, filepath):
        ret = self.conn.create_folder(t_id, filepath)      
        return ret


    def _search(self, req, tenant_id, searchPath='.', searchKey='.'):
        searchRes = self.conn.search(tenant_id, searchPath, searchKey)
        self.log.info(_('---show search result: %s'%searchRes))
        return searchRes
        
        
    
    def uploadData(self,user_info, filepath, req, chunk_id=None):
        #raise StorageError('StorageError')
        #upload collision =0 revision (not yet)
        #upload collision =1 (file is budy)
        #upload collision =2 (endfix by -copy)
        uploadcollision = 2
        self.log.debug(_('---into file upload'))
        def overwriteFilepath(filepathtmp):
            try:
                filen, filef = filepathtmp.rsplit('.',1)
            except ValueError:
                filen = filepathtmp
                filef = None
            newfile = filen+'-copy'
            if filef:
                newfile = newfile+'.'+filef
            return newfile

        def getNewFilepath(chunk_id, filepath, user_info, req):
            tmpFileFlag = True
            getFileFlag = utils.getQueryStringDict(req)
            getOverWrite = getFileFlag.get('overwrite')
            while(tmpFileFlag):
                if not chunk_id:
                    udtmp = str(self.createUUID())
                else:
                    udtmp = chunk_id
                hashName = user_info.get('tenant_id')+'/'+ filepath
                hashstring = self.createHashUUID(hashName)+'_'
                self.log.debug(_('---hash string %s'%hashstring))
                ud = hashstring + udtmp
                tmpFileFlag = self.conn.check_upload_temp_exists( user_info.get('tenant_id'), hashstring)
                # make sure self chunk file can upload 
                chunkFileFlag = self.conn.check_upload_temp_exists( user_info.get('tenant_id'), udtmp)
                self.log.debug(_('---chunkFileFlag %s'%chunkFileFlag))
                if chunkFileFlag:
                    tmpFileFlag = False

                #if not chunk_id:
                if tmpFileFlag:
                   
                    if getOverWrite is None:
                    #if uploadcollision ==2 :
                        raise FileBusyError((filepath))
                    elif getOverWrite:
                        tmpFileFlag = False
                        #filepath = filepath + '-copy'
                    elif not getOverWrite:
                        filepath = overwriteFilepath(filepath)
                    #ud = udtmp
                #else:
                #    return filepath, ud
                    
            return filepath, ud

        filepath, ud = getNewFilepath(chunk_id, filepath, user_info, req)


        compressFlag = req.environ.get('HTTP_X_META_FC_COMPRESS')
        comFlag = False
        if compressFlag is not None:
            if compressFlag.lower()=='true':
                comFlag = True
            
        encryptFlag =  req.environ.get('HTTP_X_META_FC_ENCRYPT')
        encFlag = False
        if encryptFlag is not None:
            if encryptFlag.lower()=='true':
                encFlag = True
        size_raw = '0'
        size_store = '0'
        try:
            with Timeout(self.upload_timeout):
                size_raw, size_store =  self._uploadData(req, ud, user_info.get('tenant_id'), filepath, comFlag, encFlag)
                self.log.debug(_(' going to next step %r %r'%(size_raw, size_store)))
                fsize =  int(req.headers.get('Content-Length', 0))
                #fsize = req.environ.get('CONTENT_LENGTH')
                # This happened only for client disconnect, we shoud return bad request and kill binary
                if not chunk_id:
                    if int(fsize) != int(size_raw):
                        #self.conn.delete_uncommited_upload(user_info.get('tenant_id'), ud)
                        raise Disconnect

        except MyError, e:
            if not chunk_id:
                self.conn.delete_uncommited_upload(user_info.get('tenant_id'), ud)
                self.log.debug(_( 'connection break'))
        except Timeout:
            if not chunk_id:
                self.conn.delete_uncommited_upload(user_info.get('tenant_id'), ud)
                self.log.debug(_( 'time out'))
            raise UploadTimeOut('Upload Time Out')
        except: 
            if not chunk_id:
                #self.conn.delete_uncommited_upload(user_info.get('tenant_id'), ud)
                self.log.debug(_( 'bad request exception'))
            raise BadRequest('BadRequest')

    
        #ret = self.conn.commit()
        #for paul
        if chunk_id:
            return chunk_id
        self.log.debug(_( ' --- now commit--------------------------'))
        self.log.debug(_( 'get mtime ---------------------'))
        mTime =  req.environ.get('HTTP_X_META_FC_MTIME')
        #we force that empty file cannot compress and encryption
        if int(size_raw)==0 and int(size_store)==0:
            comFlag = False
            encFlag = False
        ret = self.conn.commit(user_info.get('tenant_id'),
             filepath, ud, int(size_raw), int(size_store), mTime, comFlag, encFlag  )
        respbody = getRespBody.commit(ret)
        resp = Response("200 OK")
        resp.body = json.dumps(respbody, ensure_ascii=False)
        resp.headers['Content-Type']='application/json'
        self.log.debug(_( 'return resp upload'))
        return resp
    def downloadData(self,user_info, filepath, req):
        self.log.debug(_( '----------- into download data ---------'))
        resp = Response(request=req)
        #self.log.error(_("hahaha debug"))
        #compressFlag =  bool(req.environ.get('HTTP_X_META_FC_COMPRESS'))
        #encryptFlag =  bool(req.environ.get('HTTP_X_META_FC_ENCRYPT'))
        
        fileVersion = utils.getQueryStringDict(req).get('rev')
        self.log.debug(_( '----------- file version -----------'))
        self.log.debug(_( '%r'%fileVersion))
        
        try:
            resp =  self._downloadData(req, resp, user_info.get('tenant_id'), filepath, fileVersion)
            self.log.debug(_( 'check ret-----------------------'))
        except MyError, e:
            self.log.debug(_( 'download error'))
        self.log.debug(_( '--------into download-------------'))
        size='0'
        filemeta= self.conn.get_metadata(user_info.get('tenant_id'), filepath, fileVersion)
        respheader = getRespBody.download(size, req, filemeta)
        resp.headers['x-dropbox-metadata']=json.dumps(respheader, ensure_ascii=False)
        resp.headers['Content-Length']=filemeta.get('bytes')
        return resp 
    def create_folder(self, user_info, filepath, req):
        try:
            resp = self._createFolder(req, user_info.get('tenant_id'), filepath)
        except MyError, e:
            resp = Response(request=req)
            resp.body = 'can not create folder'
            resp.headers['Content-Type']='application/json'
            return resp
            self.log.debug(_( '----- can not create folder'))
        self.log.debug(_( 'create folder----------'))
        respbody = getRespBody.createFolder(resp)
        resp = Response(request=req)
        resp.body = json.dumps(respbody, ensure_ascii=False)
        resp.headers['Content-Type']='application/json'

        return resp
    def get_meta(self, user_info, filepath, req):
        def _retMetadata(ret):
            respbody = getRespBody.metaData(ret)
            resp = Response(status='200 OK')
            resp.body = json.dumps(respbody, ensure_ascii=False)
            resp.headers['Content-Type']='application/json'
            return resp
        try:
            ret = self._getMeta(req, user_info.get('tenant_id'), filepath)
        #except MyError, e:
        except FileNotFound:
            if filepath == '.':
                self.log.debug(_( 'root folder ----------'))
                ret = self.create_folder(user_info, '.', req)
                ret = self._getMeta(req, user_info.get('tenant_id'), filepath)
                resp = _retMetadata(ret)
                return resp
            raise FileNotFound(filepath)
        self.log.debug(_( 'get metadata succ'))
        resp = _retMetadata(ret)
        return resp

    def revisions(self, user_info, filepath, req):
        try:
            ret = self._revisions(req, user_info.get('tenant_id'), filepath)
        except MyError, e:
            resp = Response(request=req)
            resp.body = 'can not get revision'
            resp.headers['Content-Type']='application/json'
            return resp
            self.log.debug(_( '----- can not create folder'))
        respbody = getRespBody.revisions(ret)
        resp = Response(status='200 OK')
        resp.body = json.dumps(respbody, ensure_ascii=False)
        resp.headers['Content-Type']='application/json'
        return resp

    def _move(self, src_path, dest_path, src_tenant_id, False, dest_tenant_id):
        ret = self.conn.move(src_path, dest_path, src_tenant_id, False, dest_tenant_id)
        return ret
    def _delete(self, req, tenant_id, src_path):
        self.log.debug(_( 'delete %s %s'%(tenant_id, src_path)))
        
        #ret = self.conn.delete(tenant_id, src_path)
        ret = self.conn.trash(tenant_id, src_path)
        print 'filop ---- delete'
        print ret
        return ret

    def move(self, req, dest_path, src_path, dest_tenant_id, src_tenant_id, is_copy=False):
        #resp = self.fileop.move(to_path, from_path, to_user, from_user)
        try:
            #ret = self.conn.move(src_path, dest_path, src_tenant_id, False, dest_tenant_id)
            self.log.debug(_('path %s %s %s'%(src_path, dest_path, src_tenant_id)))
            #ret = self.conn.move(src_path, dest_path, src_tenant_id.get('tenant_id'), False, dest_tenant_id.get('tenant_id'))
            ret = self._move(src_path, dest_path, src_tenant_id.get('tenant_id'), is_copy, dest_tenant_id.get('tenant_id'))
            self.log.debug(_( ' get move output--------------------'))
        except MyError, e:
            self.log.debug(_( 'into error-------------------'))
            resp = Response(request=req)
            resp.body = 'can not move'
            resp.headers['Content-Type']='application/json'
            return resp
        respbody = getRespBody.move(ret)
        self.log.debug(_( 'check returning--------------------'))
        resp = Response(status='200 OK')
        resp.body = json.dumps(respbody, ensure_ascii=False)
        resp.headers['Content-Type']='application/json'
        return resp, ret.get('is_dir'), ret.get('bytes')
    """ no use for this function insteaded by move(True)"""
    def copy(self, req, dest_path, src_path, dest_tenant_id, src_tenant_id):
        resp = self.move(req, dest_path, src_path, dest_tenant_id, src_tenant_id, True)
        return resp

    def trash_remove(self, req, tenant_id, trash_id):

        try:
            t_id = tenant_id.get('tenant_id')
            ret = self.conn.trash_remove(t_id, trash_id)
        except MyError, e:
            self.log.debug(_( 'into error-------------------'))
            resp = Response(request=req)
            resp.body = 'can not delete'
            resp.headers['Content-Type']='application/json'
            return resp
        #respbody = getRespBody.delete(ret)
        respbody = ret
        resp = Response(status='200 OK')
        resp.body = json.dumps(respbody, ensure_ascii=False)
        resp.headers['Content-Type']='application/json'
        return resp

    def trash_restore(self, req, tenant_id, trash_id):

        try:
            t_id = tenant_id.get('tenant_id')
            ret = self.conn.trash_restore(t_id, trash_id)
        except MyError, e:
            self.log.debug(_( 'into error-------------------'))
            resp = Response(request=req)
            resp.body = 'can not delete'
            resp.headers['Content-Type']='application/json'
            return resp
        #respbody = getRespBody.delete(ret)
        respbody = ret
        resp = Response(status='200 OK')
        resp.body = json.dumps(respbody, ensure_ascii=False)
        resp.headers['Content-Type']='application/json'
        return resp
    def trash_list(self, req, tenant_id):

        try:
            t_id = tenant_id.get('tenant_id')
            ret = self.conn.trash_list(t_id)
        except MyError, e:
            self.log.debug(_( 'into error-------------------'))
            resp = Response(request=req)
            resp.body = 'can not delete'
            resp.headers['Content-Type']='application/json'
            return resp
        #respbody = getRespBody.delete(ret)
        respbody = ret
        resp = Response(status='200 OK')
        resp.body = json.dumps(respbody, ensure_ascii=False)
        resp.headers['Content-Type']='application/json'
        return resp

    def trash(self, req, tenant_id, src_path):

        try:
            t_id = tenant_id.get('tenant_id')
            ret = self.conn.trash(t_id, src_path)
        except MyError, e:
            self.log.debug(_( 'into error-------------------'))
            resp = Response(request=req)
            resp.body = 'can not delete'
            resp.headers['Content-Type']='application/json'
            return resp
        #respbody = getRespBody.delete(ret)
        respbody = ret
        resp = Response(status='200 OK')
        resp.body = json.dumps(respbody, ensure_ascii=False)
        resp.headers['Content-Type']='application/json'
        print 'left fileop trash'
        return resp, ret.get('is_dir'), ret.get('bytes')

    def delete(self, req, tenant_id, src_path):

        try:
            t_id = tenant_id.get('tenant_id')
            ret = self.conn.get_metadata(t_id, src_path, file_version=None, is_list=True)
            rett = self._delete(req, tenant_id.get('tenant_id'), src_path)
        except MyError, e:
            self.log.debug(_( 'into error-------------------'))
            resp = Response(request=req)
            resp.body = 'can not delete'
            resp.headers['Content-Type']='application/json'
            return resp
        respbody = getRespBody.delete(ret)
        resp = Response(status='200 OK')
        resp.body = json.dumps(respbody, ensure_ascii=False)
        resp.headers['Content-Type']='application/json'
        return resp, ret.get('is_dir'), ret.get('bytes')
        #return resp

    def deletetenant(self, req, t_id):
        src_path = '.'
        def recurDelete(fdir=None):
            if not fdir:
                fdir = '.'
            rett = self.conn.get_metadata(t_id, fdir, file_version=None, is_list=True)
            ret = rett.get('contents')
            for re in ret:
                #if re.get('path')!='/shared':
                if re.get('is_dir'):
                    ret = recurDelete(re.get('path'))
                    #delete(re.get('path'))
                    self.conn.delete(t_id, re.get('path'))
                else:
                    self.log.debug(_( 'sub delete %s'%(re.get('path'))))
                    #delete(re.get('path'))
                    self.conn.delete(t_id, re.get('path'))
            return fdir

        ret = recurDelete()
        retdtid = self.conn.delete_tenant(t_id)
        
        return None


    def search(self, tenant_id, path, req, query):
        try:
            self.log.debug(_( 'into search------------------'))
            ret = self._search(req, tenant_id.get('tenant_id'), path, query)
        except MyError, e:
            self.log.debug(_( 'into error-------------------'))
            resp = Response(request=req)
            resp.body = 'can not find'
            resp.headers['Content-Type']='application/json'
            return resp
        respbody = getRespBody.search(ret)
        resp = Response(status='200 OK')
        resp.body = json.dumps(respbody, ensure_ascii=False)
        resp.headers['Content-Type']='application/json'
        return resp

    def chunk_upload(self,user_info, filepath1, req):
        print '---------11-------------------'
        #print type(filepath)
        filepath = filepath1.decode('utf-8')
        chunkInfo = utils.getQueryStringDict(req)
        upload_id = chunkInfo.get('upload_id')
        offset = chunkInfo.get('offset')

        print '---------22-------------------'
        if not offset:
            offsetnum=0
        else:
            offsetnum=int(offset)
        print '---------33-------------------'

        hashName = user_info.get('tenant_id')+'/'+filepath
        hashstring = self.createHashUUID(hashName)+'_'
        print hashstring
        print '---------55-------------------'

        if upload_id:
            self.log.debug(_( 'got upload_id:%s'%upload_id))
            self.log.debug(_( 'got offset:%s'%offset))
            #check offset

            ud = hashstring + upload_id

            existedFilesNum = len(self.conn.list_uncommited_upload(user_info.get('tenant_id'), ud))
            if existedFilesNum * self.storage_chunk_size != int(offset):
                self.log.debug(_( 'size not equal ---------'))
                raise BadRequest('wrong offset or upload_id parameters')
           
        else:
            self.log.debug(_( 'setup initial ------------'))
            upload_id = str(self.createUUID())


        upload_id = self.uploadData(user_info, filepath, req, upload_id)
        offsetnum=offsetnum+self.storage_chunk_size

        respbody ={'upload_id':upload_id,'offset':str(offsetnum)}
        resp = Response(status='200 OK')
        resp.body = json.dumps(respbody, ensure_ascii=False)
        return resp, upload_id

        

    def commit_chunk_upload(self,user_info, filepath, req):
        print '--------------------1 ---------------'
        print type(filepath)
        chunkInfo = utils.getQueryStringDict(req)
        upload_id = chunkInfo.get('upload_id')

        udtmp = upload_id
        hashName = user_info.get('tenant_id')+'/'+filepath
        hashstring = self.createHashUUID(hashName)+'_'
        ud = hashstring + udtmp
        print ud
        comFlag = False
        encFlag = False

        print '--------------------2 ---------------'

        #ud = upload_id
        checktmpfile = self.conn.list_uncommited_upload(user_info.get('tenant_id'), ud)
        fsize = 0
        num_checkfile = len(checktmpfile)
        for sizes in checktmpfile:
            fsize = fsize + sizes
        print '--------------------3 ---------------'
            
        
        size_raw= int(num_checkfile)*self.storage_chunk_size
        size_store=int(fsize)
        self.log.debug(_( ' size check ------------------'))
        self.log.debug(_( 'get mtime ---------------------'))
        mTime =  req.environ.get('HTTP_X_META_FC_MTIME')
        ret = self.conn.commit(user_info.get('tenant_id'),
             filepath, ud, int(size_store), int(size_store), mTime, comFlag, encFlag  )


        respbody = getRespBody.commit(ret)
        resp = Response("200 OK")
        resp.body = json.dumps(respbody, ensure_ascii=False)
        resp.headers['Content-Type']='application/json'
        self.log.debug(_( 'return resp upload'))
        return resp, upload_id

        
    def restore(self, user_info, filepath, req):   
        getquery = utils.getQueryStringDict(req)
        rev = getquery.get('rev')
        try:
            if rev:
                ret = self.conn.restore(user_info.get('tenant_id'), filepath, rev)
                self.log.debug(_( '--------restore --------'))
            else:
                raise revneed
        except:
            raise BadRequest('need rev parameter')

        respbody = getRespBody.restore(ret)
        resp = Response("200 OK")
        resp.body = json.dumps(respbody, ensure_ascii=False)
        resp.headers['Content-Type']='application/json'
        self.log.debug(_( 'return resp upload'))
        return resp
        
        
    
        
    

 

