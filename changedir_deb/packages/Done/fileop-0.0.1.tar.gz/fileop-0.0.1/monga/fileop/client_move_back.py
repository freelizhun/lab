import httplib
import sys
import mimetypes
import os
import json
import urllib
#CHUNKSIZE = 65563  
CHUNKSIZE = 4096
#CHUNKSIZE = 6
url="http://127.0.0.1:7000/"
conn = httplib.HTTPConnection("127.0.0.1", 7000)
#conn.putrequest("POST", "/?file=save.jpg")
#conn.putrequest("POST", "/?file=save.jpg")
#conn.putrequest("PUT", "/test?file=haha")
#conn.putrequest("POST", "/fileops", body)
#conn.putheader("Content-Type", "application/zip")
#conn.putheader("Content-Type", "application/json")
#conn.putheader("Transfer-Encoding", "chunked")
##conn.putheader("Filepath","/tmp/size/s.txt")
#conn.endheaders(body)
#params = urllib.urlencode({'root':'tenant_id','path':'/haahah'})
body = json.dumps({'root':'tenant_id','path':'/hahalala'})

conn.request('POST', '/v1/fileops/move?root=tenant_id&from_path=sizemove.txt&to_path=size.txt') 
response = conn.getresponse()
#response = getresponse()
print '------status--------'
print response.status
print '------resaon--------'
print response.reason
print '----- read -------'
#ret= response.read()
#print ret
#retd= json.loads(ret)
#print retd
#print response.headers


