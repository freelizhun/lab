import httplib, urllib
import json
params = urllib.urlencode({'spam': 1, 'eggs': 2, 'bacon': 0})
headers = {"Content-type": "application/x-www-form-urlencoded",
        "Accept": "text/plain"}
#url = 'http://localhost:8090/search?q=haha&aq=f'

conn = httplib.HTTPConnection("localhost:7000")
conn.request("GET", "/v1/files/zero3.txt", params, headers)
response = conn.getresponse()
f = open('/tmp/decomenc_large.txt',"wb")
chunksize = 1024
#data = response.read(chunksize)
data = 'init'
while data:
    data = response.read(chunksize)
    if len(data)!=0:
        f.write(data)
    else:
        break
f.close()
conn.close()
print '------status--------'
print response.status
print '------resaon--------'
print response.reason
print '----- read -------'
print response.getheader('x-dropbox-metadata')
#ret= response.read()
#print ret
#retd= json.loads(ret)
#print retd

