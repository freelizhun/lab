import httplib
import sys
import mimetypes
import os
import json
import urllib
url="http://127.0.0.1:7000/"
conn = httplib.HTTPConnection("127.0.0.1", 7000)
conn.putrequest('DELETE', '/v1/fileops/trash/3db9a4a1-e335-445a-ae74-9edf8149e82b?team=Sharon.Lalor') 
conn.putheader("X-AUTH-Token","9e94f61ce9114e50b9ee75e02c315f80")
#conn.putheader("team","Sharon.Lalor")
conn.endheaders()


response = conn.getresponse()
print '------status--------'
print response.status
print '------resaon--------'
print response.reason
print '----- read -------'
ret= response.read()
print ret
retd= json.loads(ret)
print retd
#print response.headers


