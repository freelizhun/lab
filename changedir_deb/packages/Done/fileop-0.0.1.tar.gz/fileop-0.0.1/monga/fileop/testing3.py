import unittest
import sys
import mimetypes
import os
import json
import httplib, urllib
import time
import commands
from monga.fileop import utils
#CHUNKSIZE = 65563
global token
token ='fc06ddd343b44c9daf54fcf4fa64d546'
global loop
def metadata(fname):
    headers = {"Content-type": "application/x-www-form-urlencoded",
            "Accept": "text/plain"}
#url = 'http://localhost:8090/search?q=haha&aq=f'

    conn = httplib.HTTPConnection("localhost:7000")
    conn.putrequest("GET", "/v1/metadata/%s"%fname)
    global token
    conn.putheader("X-Auth-Token","%s"%token)
    conn.endheaders()

    response = conn.getresponse()
    print response.status, response.reason

    print '------status--------'
    print response.status
    print '------resaon--------'
    print response.reason
    print '----- read -------'
    #print response.getheader('x-dropbox-metadata')
    ret= response.read()
#print ret
    retd= json.loads(ret)
    #print retd
    return retd

def download(downloadfile, downloadpath, rev=None):
#url = 'http://localhost:8090/search?q=haha&aq=f'

    conn = httplib.HTTPConnection("localhost:7000")
    if not rev:
        conn.putrequest("GET", "/v1/files/%s"%downloadpath)
    else:
        conn.putrequest("GET", "/v1/files/%s?rev=%s"%(downloadpath,rev))

    global token
    conn.putheader("X-Auth-Token","%s"%token)
    conn.endheaders()

    response = conn.getresponse()
    f = open(downloadfile,"wb")
    chunksize = 1024
#data = response.read(chunksize)
    data = 'init'
    while data:
        data = response.read(chunksize)
        if len(data)!=0:
            f.write(data)
        else:
            break
    f.close()
    conn.close()
    print '------status--------'
    print response.status
    print '------resaon--------'
    print response.reason
    print '----- read -------'
    print response.getheader('x-dropbox-metadata')
    return response
def upload_compress(uploadfile, uploadpath, comFlag=False, encFlag=False):
    CHUNKSIZE = 4096
    url="http://127.0.0.1:7000/"
    conn = httplib.HTTPConnection("127.0.0.1", 7000)
    #conn.putrequest("POST", "/v1/files/%s?overwrite=true&parent_rev=notyet"%uploadpath)
    conn.putrequest("POST", "/v1/files/%s?overwrite=true&parent_rev=notyet"%uploadpath)

    conn.putheader("Content-Type", "application/json")
    global token
    conn.putheader("X-Auth-Token","%s"%token)
    #conn.putheader("Transfer-Encoding", "chunked")
    f=uploadfile
    fsize = utils.getFileSize(f)
    conn.putheader("CONTENT-LENGTH", str(fsize))
    conn.putheader("X-META-FC-COMPRESS",str(comFlag))
    conn.putheader("X-META-FC-ENCRYPT",str(encFlag))
    conn.endheaders()

    with open(f, 'r') as fp:
         chunk = fp.read(CHUNKSIZE)
         #print chunk
         while chunk:
             #conn.send('%x\r\n%s\r\n' % (len(chunk), chunk))
             conn.send('%s' % (chunk))
             chunk = fp.read(CHUNKSIZE)
         #conn.send('0\r\n\r\n')
    response = conn.getresponse()
    print '------status--------'
    print response.status
    print '------resaon--------'
    print response.reason
    print '----- read -------'
    ret= response.read()
    print ret
    retd= json.loads(ret)
    print retd
    return response


def copy(uploadpath, uploadpath1=None):

    url="http://127.0.0.1:7000/"
    conn = httplib.HTTPConnection("127.0.0.1", 7000)
    if uploadpath1:
        conn.putrequest('POST', '/v1/fileops/copy?root=tenant_id&from_path=%s&to_path=%s'%(uploadpath, uploadpath1))
    else:
        conn.putrequest('POST', '/v1/fileops/copy?root=tenant_id&from_path=%s&to_path=%s'%(uploadpath, uploadpath+'.copy'))
    global token
    conn.putheader("X-Auth-Token","%s"%token)
    conn.endheaders()
    response = conn.getresponse()
    print '------status--------'
    print response.status
    print '------resaon--------'
    print response.reason
    print '----- read -------'
    return response

def move(uploadpath, uploadpath1=None):

    url="http://127.0.0.1:7000/"
    conn = httplib.HTTPConnection("127.0.0.1", 7000)
    if uploadpath1:
        conn.putrequest('POST', '/v1/fileops/move?root=tenant_id&from_path=%s&to_path=%s'%(uploadpath, uploadpath1))
    else:
        conn.putrequest('POST', '/v1/fileops/move?root=tenant_id&from_path=%s&to_path=%s'%(uploadpath, uploadpath+'.move'))
    global token
    conn.putheader("X-Auth-Token","%s"%token)
    conn.endheaders()
    response = conn.getresponse()
    print '------status--------'
    print response.status
    print '------resaon--------'
    print response.reason
    print '----- read -------'
    return response


def moveback():
    url="http://127.0.0.1:7000/"
    conn = httplib.HTTPConnection("127.0.0.1", 7000)
    conn.putrequest('POST', '/v1/fileops/move?root=tenant_id&from_path=%s&to_path=%s'%(uploadpath+'.move', uploadpath))
    global token
    conn.putheader("X-Auth-Token","%s"%token)
    conn.endheaders()
    response = conn.getresponse()
    print '------status--------'
    print response.status
    print '------resaon--------'
    print response.reason
    print '----- read -------'
    return response

def revisions(fpath):

    CHUNKSIZE = 4096
#CHUNKSIZE = 6
    url="http://127.0.0.1:7000/"
    conn = httplib.HTTPConnection("127.0.0.1", 7000)
    body = json.dumps({'root':'tenant_id','path':'/hahalala'})

    conn.putrequest('GET', '/v1/revisions/%s'%fpath)
    global token
    conn.putheader("X-Auth-Token","%s"%token)
    conn.endheaders()
    response = conn.getresponse()
#response = getresponse()
    print '------status--------'
    print response.status
    print '------resaon--------'
    print response.reason
    print '----- read -------'
    ret= response.read()
#print ret
    retd= json.loads(ret)
    print retd
    return retd



def upload_createdFolder():
    CHUNKSIZE = 4096
#CHUNKSIZE = 6
    url="http://127.0.0.1:7000/"
    conn = httplib.HTTPConnection("127.0.0.1", 7000)
    conn.putrequest("POST", "/v1/files/%s/%s?overwrite=true&parent_rev=notyet"%(createfoldername, createfolderfile))
    conn.putheader("Content-Type", "application/json")
    conn.putheader("Transfer-Encoding", "chunked")
    global token
    conn.putheader("X-Auth-Token","%s"%token)
    conn.endheaders()
    f=uploadfile
    with open(f, 'r') as fp:
         chunk = fp.read(CHUNKSIZE)
         #print chunk
         while chunk:
             conn.send('%x\r\n%s\r\n' % (len(chunk), chunk))
             chunk = fp.read(CHUNKSIZE)
         conn.send('0\r\n\r\n')
    response = conn.getresponse()
    print '------status--------'
    print response.status
    print '------resaon--------'
    print response.reason
    print '----- read -------'
    ret= response.read()
    print ret
    retd= json.loads(ret)
    print retd
    return response


def upload(uploadfile, uploadpath ):
    CHUNKSIZE = 4096
#CHUNKSIZE = 6
    url="http://127.0.0.1:7000/"
    conn = httplib.HTTPConnection("127.0.0.1", 7000)
#conn.putrequest("POST", "/?file=save.jpg")
#conn.putrequest("POST", "/?file=save.jpg")
#conn.putrequest("PUT", "/test?file=haha")
    conn.putrequest("POST", "/v1/files/%s?overwrite=true&parent_rev=notyet"%uploadpath)
#conn.putheader("Content-Type", "application/zip")
    conn.putheader("Content-Type", "application/json")
    global token
    conn.putheader("X-Auth-Token","%s"%token)
    #conn.putheader("Transfer-Encoding", "chunked")
    f=uploadfile
    fsize = utils.getFileSize(f)

    conn.putheader("Content-Length", str(fsize) )
#conn.putheader("Filepath","/tmp/size/s.txt")
    conn.endheaders()

#fp = '/root/random.zip'
#fp = './zero.txt'
#fp = './ddd.jpg'
#fp = './size.txt'
#fp='./random.txt'
# fp = 'C:\Users\haow\Downloads\MONACO.TTF'
#f = os.path.basename(fp)
#print f
#print mimetypes.guess_type(f)
    with open(f, 'r') as fp:
         chunk = fp.read(CHUNKSIZE)
         #print chunk
         while chunk:
             #conn.send('%x\r\n%s\r\n' % (len(chunk), chunk))
             conn.send('%s' % (chunk))
             chunk = fp.read(CHUNKSIZE)
         #conn.send('0\r\n\r\n')
    response = conn.getresponse()
    print '------status--------'
    print response.status
    print '------resaon--------'
    print response.reason
    print '----- read -------'
    ret= response.read()
    print ret
    retd= json.loads(ret)
    print retd
    conn.close()
    return response

def maprealpath(pathf):
    mapdir = '/opt/monga/tenant_id/home/'
    return mapdir+uploadpath
    
def checkFileDiff(downloadfile, uploadfile):
    ret = commands.getoutput('diff %s %s'%(downloadfile, uploadfile))
    if len(ret)==0:
        return True
    else:
        return False
def checkFileExisted(uploadpath):
    mapdir = '/opt/monga/tenant_id/home/'
    checkpath = mapdir+uploadpath
    return os.path.exists(checkpath)
def createFolder(pathfolder):
    CHUNKSIZE = 4096
    url="http://127.0.0.1:7000/"
    conn = httplib.HTTPConnection("127.0.0.1", 7000)
    body = json.dumps({'root':'tenant_id','path':'/hahalala'})
    conn.putrequest('POST', '/v1/fileops/create_folder?path=%s'%pathfolder)
    global token
    conn.putheader("X-Auth-Token","%s"%token)
    conn.endheaders()

    response = conn.getresponse()
#response = getresponse()
    print '------status--------'
    print response.status
    print '------resaon--------'
    print response.reason
    print '----- read -------'
    ret= response.read()
    print ret
    retd= json.loads(ret)
    print retd
    return response
def delete(path):
    url="http://127.0.0.1:7000/"
    conn = httplib.HTTPConnection("127.0.0.1", 7000)
    conn.putrequest('POST', '/v1/fileops/delete?root=tenant_id&path=%s'%path)
    global token
    conn.putheader("X-Auth-Token","%s"%token)
    response = conn.getresponse()
    print '------status--------'
    print response.status
    print '------resaon--------'
    print response.reason
    print '----- read -------'
    return response

def downloadandCheck(uploadfile, uploadpath, rev=None, comFlag=False):
    count = 0
    looplen = len(uploadfile)
    for count in range(0, looplen):
        if rev:
            ret = download(uploadfile[count], uploadpath[count], rev[count])
        else:
            ret = download(uploadfile[count], uploadpath[count])
        yield ret,count
        #assertEqual(ret.status, 200)
        #assertEqual(checkFileExisted(uploadpath[count]), True)
        count = count + 1

def uploadandCheck(uploadfile, uploadpath, comFlag=False, encFlag=False):
    count = 0
    looplen = len(uploadfile)
    for count in range(0, looplen):
        if comFlag or encFlag:
            print comFlag
            print encFlag
            ret = upload_compress(uploadfile[count], uploadpath[count], comFlag, encFlag)
        else:
            ret = upload(uploadfile[count], uploadpath[count])
        yield ret,count
        #assertEqual(ret.status, 200)
        #assertEqual(checkFileExisted(uploadpath[count]), True)
        count = count + 1

class FileOpTest(unittest.TestCase):
    global loop
    def setUp(self):
        self.uploadfile=['/root/small.txt', '/root/medium.txt']
        self.uploadpath=['testsmall3%s.txt'%str(loop), 'testmedium3%s.txt'%str(loop)]
    def testupload(self):
        for ret, count in uploadandCheck(self.uploadfile, self.uploadpath):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True)

class FolderOpTest(unittest.TestCase):
    global loop
    def setUp(self):
        self.foldername = 'folderintest%s'%str(loop)
        self.uploadfile=['/root/small.txt', '/root/medium.txt']
        self.uploadpath=['/%s/testsmall3%s.txt'%(self.foldername,str(loop)), '/%s/testmedium4%s.txt'%(self.foldername,str(loop))]
    def testCreateFolder(self):
        ret = createFolder(self.foldername)
        self.assertEqual(ret.status, 200)
        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True)

class CopyOpTest(unittest.TestCase):
    global loop
    def setUp(self):
        self.foldername = ['foldertestncopy1%s'%str(loop),'foldertestcopy2%s'%str(loop)]
        self.uploadfile=['/root/small.txt', '/root/medium.txt']
        self.uploadpath=['/%s/testsmall3%s.txt'%(self.foldername[0],str(loop)), '/%s/testmedium4%s.txt'%(self.foldername[0],str(loop))]
        self.uploadpathcopy=['/%s/testsmall3%s.txt'%(self.foldername[1],str(loop)), '/%s/testmedium4%s.txt'%(self.foldername[1],str(loop))]
        for folder in self.foldername:
            ret = createFolder(folder)
            self.assertEqual(ret.status, 200)

        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True)

    def testCopyFolder(self):

        for uppath in self.uploadpath:
            ret = copy(uppath)
            self.assertEqual(ret.status, 200)
        count = 0
        for uppath in self.uploadpath:
            print uppath
            print self.uploadpathcopy[count]
            ret = copy(uppath, self.uploadpathcopy[count])
            self.assertEqual(ret.status, 200)
            count = count +1
    
class MoveOpTest(unittest.TestCase):
    global loop
    def setUp(self):
        self.foldername = ['foldertestmove1%s'%str(loop),'foldertestmove2%s'%str(loop)]
        self.uploadfile=['/root/small.txt', '/root/medium.txt']
        self.uploadpath=['/%s/testsmall3%s.txt'%(self.foldername[0],str(loop)), '/%s/testmedium4%s.txt'%(self.foldername[0],str(loop))]
        self.uploadpathcopy=['/%s/testsmall3%s.txt'%(self.foldername[1],str(loop)), '/%s/testmedium4%s.txt'%(self.foldername[1],str(loop))]
        for folder in self.foldername:
            ret = createFolder(folder)
            self.assertEqual(ret.status, 200)

        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True)
    def testCopyFolder(self):

        for uppath in self.uploadpath:
            ret = copy(uppath)
            self.assertEqual(ret.status, 200)
        count = 0
        for uppath in self.uploadpath:
            print uppath
            print self.uploadpathcopy[count]
            ret = move(uppath, self.uploadpathcopy[count])
            self.assertEqual(ret.status, 200)
            count = count +1


class DeleteOpTest(unittest.TestCase):
    global loop
    def setUp(self):
        self.foldername = ['foldertestdelete%s'%str(loop)]
        self.uploadfile=['/root/small.txt', '/root/medium.txt']
        self.uploadpath=['/%s/testdelete1%s.txt'%(self.foldername[0],str(loop)), '/%s/testdelete2%s.txt'%(self.foldername[0],str(loop))]

        for folder in self.foldername:
            ret = createFolder(folder)
            self.assertEqual(ret.status, 200)

        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True)
    def testDeleteFile(self):

        for uppath in self.uploadpath:
            ret = delete(uppath)
            self.assertEqual(ret.status, 200)
            #ret = checkFileExisted(uppath)
            #self.assertEqual(ret, False )
        for dfolder in self.foldername:
            ret = delete(dfolder)
            self.assertEqual(ret.status, 200)
            
class DownloadOpTest(unittest.TestCase):
    global loop
    def setUp(self):    
        self.foldername = ['foldertestdownload%s'%str(loop)]
        self.uploadfile=['/root/medium.txt']
        self.uploadpath=['/%s/medium%s.txt'%(self.foldername[0],str(loop))]
        self.downloadfile=['/tmp/medium%s.txt'%str(loop)]
        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True)
    def testDownload(self):
        for ret,count in downloadandCheck(self.downloadfile, self.uploadpath):
            self.assertEqual(ret.status, 200)
            self.assertEqual(checkFileDiff(self.downloadfile[count], self.uploadfile[count]), True)


class CompressionOpTest(unittest.TestCase):
    global loop
    def setUp(self):    
        self.foldername = ['foldertestcompress%s'%str(loop)]
        self.uploadfile=['/root/zero.txt']
        self.uploadpath=['/%s/compress%s.txt'%(self.foldername[0],str(loop))]
        self.downloadfile=['/tmp/decompress%s.txt'%str(loop)]
        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath,True, False):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True, False)
    def testCompression(self):
        for ret,count in downloadandCheck(self.downloadfile, self.uploadpath):
            self.assertEqual(ret.status, 200)
            self.assertEqual(checkFileDiff(self.downloadfile[count], self.uploadfile[count]), True)

class EncryptOpTest(unittest.TestCase):
    global loop
    def setUp(self):    
        self.foldername = ['foldertestencrypt%s'%str(loop)]
        self.uploadfile=['/root/zero.txt']
        self.uploadpath=['/%s/encrypt%s.txt'%(self.foldername[0],str(loop))]
        self.downloadfile=['/tmp/decrypt%s.txt'%str(loop)]
        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath, False, True):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True)
    def testEncryption(self):
        for ret,count in downloadandCheck(self.downloadfile, self.uploadpath):
            self.assertEqual(ret.status, 200)
            self.assertEqual(checkFileDiff(self.downloadfile[count], self.uploadfile[count]), True)
        
class CompressEncryptOpTest(unittest.TestCase):
    global loop
    def setUp(self):    
        self.foldername = ['foldertestcompressencrypt%s'%str(loop)]
        self.uploadfile=['/root/zero.txt']
        self.uploadpath=['/%s/compressencrypt%s.txt'%(self.foldername[0],str(loop))]
        self.downloadfile=['/tmp/compressdecrypt%s.txt'%str(loop)]
        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath, True, True):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True)
    def testCompressEncryption(self):
        for ret,count in downloadandCheck(self.downloadfile, self.uploadpath):
            self.assertEqual(ret.status, 200)
            self.assertEqual(checkFileDiff(self.downloadfile[count], self.uploadfile[count]), True)
            

class MetadataOpTest(unittest.TestCase):
    global loop
    def setUp(self):    
        self.foldername = ['foldertestmetadata%s'%str(loop)]
        self.uploadfile=['/root/zero.txt']
        self.uploadpath=['/%s/compressencrypt.txt%s'%(self.foldername[0],str(loop))]
        self.downloadfile=['/tmp/compressdecrypt.txt%s'%str(loop)]
        self.createdfolder = ['/'+self.foldername[0]+'/testmeta%s'%str(loop)]
        createFolder(self.createdfolder)
        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath, True, True):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True)
    def testMetaData(self):
        def checkInlist(target, *src):
            for tsrc in src:
                for ttsrc in tsrc:
                    print '===== in compare ========'
                    print ttsrc
                    if target == ttsrc:
                        return True
            return False


        getmeta = metadata(self.foldername[0])        
        print getmeta
        metacontent = getmeta.get('contents')
        print metacontent
        for mc in metacontent:
            print '=== source meta======='
            print mc.get('path')
            res = checkInlist(mc.get('path'), self.foldername, self.uploadpath, self.createdfolder)
            self.assertEqual(res , True)
            
        
class revisionOpTest(unittest.TestCase):
    global loop
    def setUp(self):    
        self.foldername = ['foldertestrevision%s'%str(loop)]
        self.uploadfile=['/root/v1size.txt','/root/v2size.txt','/root/v3size.txt']
        self.uploadpath=['/%s/vsize.txt%s'%(self.foldername[0],str(loop)),'/%s/vsize.txt%s'%(self.foldername[0],str(loop))
                ,'/%s/vsize.txt%s'%(self.foldername[0],str(loop))]
        self.downloadfile=['/tmp/vd1size.txt%s'%str(loop),'/tmp/vd2size.txt%s'%str(loop),'/tmp/vd3size.txt%s'%str(loop)]

        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath, False, False):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True)
            time.sleep(2)
        
    def testRevision(self):
        def _timeToValue(ha):
            print ha
            hha= ha.replace(':','').split()
            ss = str(hha[3]+hha[4])
            print ss
            return int(ss)

        def sortdict(vals, data):
            sortvals = []
            for val in vals:
                sortvals.append( _timeToValue(val))
            newsortval = sorted(sortvals, key=int)
            newsort = []
            #print 'start sort'
            for i in newsortval:
                #print i
                newsort.append(data.get(i))
            return newsort
            
            
        #print 'get revision'
        revstmp = revisions(self.uploadpath[0])
        revs=[]
        revsdict={}
        datestr=[]
        for rev in revstmp:
            print rev.get('modified'),rev.get('rev')
            revsdict[_timeToValue(rev.get('modified'))]=rev.get('rev')
            datestr.append(rev.get('modified'))
        revs = sortdict(datestr, revsdict)
        #print ' sorted data =========='
        #print revs
        
        for ret,count in downloadandCheck(self.downloadfile, self.uploadpath, revs):
            self.assertEqual(ret.status, 200)
            self.assertEqual(checkFileDiff(self.downloadfile[count], self.uploadfile[count]), True)
"""
if __name__=='__main__':
    global loop
    for i in range(0,1):
        loop = i
        unittest.main(exit=False)
"""
global loop
loop = 0
suite = unittest.TestLoader().loadTestsFromTestCase(DeleteOpTest)
unittest.TextTestRunner(verbosity=2).run(suite)
