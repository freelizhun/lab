import httplib
import sys
import mimetypes
import os
import json
from monga.fileop import utils
#CHUNKSIZE = 65563  
CHUNKSIZE = 4096
#CHUNKSIZE = 6
url="http://127.0.0.1:7000/"
conn = httplib.HTTPConnection("127.0.0.1", 7000)
#conn.putrequest("POST", "/?file=save.jpg")
#conn.putrequest("POST", "/?file=save.jpg")
#conn.putrequest("PUT", "/test?file=haha")
#conn.putrequest("POST", "/v1/files/size1.txt?overwrite=true&parent_rev=notyet")
#conn.putrequest("POST", "/v1/files/size1.txt?overwrite=true&parent_rev=notyet")
conn.putrequest("PUT", "/v1/files_put/%D9%81%D8%A7%D8%B1%D8%B3%DB%8C?overwrite=true&parent_rev=notyet")
#conn.putheader("Content-Type", "application/zip")
#conn.putheader("Content-Type", "application/json")
conn.putheader("Content-Type", "application/json")
conn.putheader("X-AUTH-Token","f3d354f46e0747cc836e9b03c7c422b4")
f='/root/medium.txt'
fsize = utils.getFileSize(f)# - 1
print fsize
#conn.putheader("Content-Type", "application/json")
conn.putheader("Content-Length", str(fsize))
#conn.putheader("Transfer-Encoding", "chunked")
#conn.putheader("Filepath","/tmp/size/s.txt")
#conn.putheader("X-META-FC-COMPRESS","false")
#conn.putheader("X-META-FC-ENCRYPT","false")
conn.endheaders()
 
#fp = '/root/random.zip'
#fp = './zero.txt'
#fp = './ddd.jpg'
#fp = './size.txt'
#fp='./random.txt'
# fp = 'C:\Users\haow\Downloads\MONACO.TTF'
#f = os.path.basename(fp)
#print f
#print mimetypes.guess_type(f)


with open(f, 'r') as fp:
     chunk = fp.read(CHUNKSIZE)
     #print chunk
     while chunk:
         #conn.send('%x\r\n%s\r\n' % (len(chunk), chunk))
         conn.send('%s' % (chunk))
         #conn.send('%s\r\n' % ( chunk))
         chunk = fp.read(CHUNKSIZE)
     #conn.send('0\r\n\r\n')

response = conn.getresponse()
print '------status--------'
print response.status
print '------resaon--------'
print response.reason
#print '----- read -------'
ret= response.read()
print ret
retd= json.loads(ret)
print retd
#print response.headers


