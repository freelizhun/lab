import unittest
import sys
import mimetypes
import os
import json
import httplib, urllib
import time
import commands
import time
from monga.fileop import utils
#CHUNKSIZE = 65563
#token ='d2d321ed4c884d1392c02faea7a8a689'
global loop
global tenant_id
#tenant_id='0132ca642aee4550940ccba6a5d96b48'
global keystoneIP
#keystoneIP='10.90.0.148'
keystoneIP='10.90.0.52'
fcip='localhost'
#testing Data path
dirpath='/tmp/testing'
chunkUploadSize = 1024000
#token = sys.argv[1]
#tenant_id= sys.argv[2]
def getTenantid(user, password):
    global keystoneIP
    headerss = {"Content-type": "application/json"}
    msgbody = {"auth":{"identity":{"methods":["password"],"password":{"user":{"domain":{"name":"cs.promise.com.tw"},"name":"%s"%user,"password":"%s"%password}}},
            "scope":{"project":{"domain":{"name":"cs.promise.com.tw"},"name":"%s"%user}}}}

    conn = httplib.HTTPConnection("%s"%keystoneIP, 35357)
    conn.request('POST', '/v3/auth/tokens',  body=json.dumps(msgbody), headers = headerss)

    response = conn.getresponse()
    print '------statusgetTenantid--------'
    print response.status
    print '------resaongetTenantid--------'
    print response.reason
    print '----- readgetTenantid -------'
    ret= response.read()
    print ret 
    retd= json.loads(ret)
    print retd
    return retd['token']['project']['id']
    

def getTokenTid(user, password):
    global keystoneIP
    s ="""curl -X POST -v -H 'Content-Type: application/json' %s:35357/v3/auth/tokens -d '{"auth":{"identity":{"methods":["password"],"password":
        {"user":{"domain":{"name":"cs.promise.com.tw"},"name":"%s","password":"%s"}}},"scope":{"project":{"domain":{"name":"cs.promise.com.tw"},"name":"%s"}}}}'"""%(keystoneIP, user,password,user)
    #print s
    strr = commands.getoutput(s)
    print strr
    ss= strr.split('left intact')
#print ss.get('project')
#print '---------------'
#print ss[0]
    #print '------------------------------------'
    token =  ss[0].split('X-Subject-Token:')[1].split()[0]
    print 'show token ---------------',token
    #t_idtmp= ss[1].split('*')[0].strip()
    #t_id =  json.loads(t_idtmp)['token']['project']['id']
    return token

global token
global tenant_id
#token = getTokenTid('joe','joe')
if len(sys.argv)<2:
    token = getTokenTid('Carol.Wilson','Password1')
    tenant_id = getTenantid('Carol.Wilson','Password1')
else:
    token = getTokenTid(sys.argv[1],sys.argv[2])
    tenant_id = getTenantid(sys.argv[1],sys.argv[2])
print token
print tenant_id
time.sleep(5)




def createData(filen, fcount=1):
    if filen.find('small')>=0:
        fcount =2

    if filen.find('medium')>=0:
        fcount =20 

    if filen.find('large')>=0:
        fcount =200

    if filen.find('zero')>=0:
        ret = commands.getoutput('dd if=/dev/zero of=%s bs=1024000 count=%s'%(filen, fcount))
    else:
        ret = commands.getoutput('dd if=/dev/urandom of=%s bs=1024000 count=%s'%(filen, fcount))
    return ret 

def checkexisted(file_path):
    return os.path.exists(file_path)
    

def iniTestData(filelists):
    testfolder= checkexisted(dirpath)
    if not testfolder:
        os.mkdir(dirpath)
    for filelist in filelists:
        pathf = dirpath+'/'+filelist
        if not checkexisted(pathf):
            print createData(pathf)
    #createData(filelist)


def iniChunkData(filen='chunk_'):
    filenn=dirpath+'/'+'chunkfiletest'
    testfolder= checkexisted(filenn)
    if not testfolder:
        os.mkdir(filenn)
    filennn = filenn+'/'+filen
    for i in range(0,38):
        filep = filennn+str(i).zfill(3)
        if not checkexisted(filep):
            createData(filep)



def deletetenant():
    conn = httplib.HTTPConnection("%s"%fcip, 7000)
    conn.putrequest('DELETE', '/v1/delete/%s'%tenant_id) 
    conn.putheader("X-AUTH-Token","ADMIN")
    conn.endheaders()

    response = conn.getresponse()
    print '------statusdeletetenant--------'
    print response.status
    print '------resaondeletetenant--------'
    print response.reason
    print '----- readdeletetenant -------'
    return response.status

def restore(fname, rev):
    global token
    #conn = httplib.HTTPConnection("localhost:7000")
    conn = httplib.HTTPConnection("%s:7000"%fcip)
    conn.putrequest("POST", "/v1/restore/%s?rev=%s"%(fname, rev))
    conn.putheader("X-AUTH-Token","%s"%token)
    conn.endheaders()
    response = conn.getresponse()
    print response.status, response.reason
    print '------statusrestore--------'
    print response.status
    print '------resaonrestore--------'
    print response.reason
    ret= response.read()
    retd= json.loads(ret)
    print retd
    return retd

def chunk_commit(upload_id):
    CHUNKSIZE = 4096
    checkstatus = '200'
    loop = 0
    loopfin = 10
    offset = str(0)
    url="http://127.0.0.1:7000/"
    #conn = httplib.HTTPConnection("127.0.0.1", 7000)
    conn = httplib.HTTPConnection("%s:7000"%fcip)
    conn.putrequest("POST", "/v1/commit_chunked_upload/chunkupload1.txt?upload_id=%s"%upload_id)
    conn.putheader("Content-Type", "application/json")
    global token
    conn.putheader("X-AUTH-Token","%s"%token)
#conn.putheader("X--Token","165196cc37b74dd6bf78d707b87f9b1b")
    conn.endheaders()
    response = conn.getresponse()
    print '------status chunk_commit--------'
    print response.status
    print '------resaon chunk_commit--------'
    print response.reason
    ret= response.read()
    print ret
    retd= json.loads(ret)
    print 'ret data ------------'
    print retd
    return retd


def chunk_upload(upload_id = None, offset=None, cloop=0):
    CHUNKSIZE = 4096
    url="http://127.0.0.1:7000/"
    #conn = httplib.HTTPConnection("127.0.0.1", 7000)
    conn = httplib.HTTPConnection("%s:7000"%fcip)
    #time.sleep(10)
    if upload_id:
        cloop= int(offset)/chunkUploadSize
        if cloop < 10:
            f='/tmp/testing/chunkfiletest/chunk_00%s'%str(cloop)
        if cloop >=10 and cloop <100:
            f='/tmp/testing/chunkfiletest/chunk_0%s'%str(cloop)
        #conn.putrequest("POST", "/v1/chunked_upload?upload_id=%s&offset=%s&overwrite=True"%(upload_id, offset))
        conn.putrequest("POST", "/v1/chunked_upload?upload_id=%s&offset=%s"%(upload_id, offset))
    else:
        f='/tmp/testing/chunkfiletest/chunk_000'
        #conn.putrequest("POST", "/v1/chunked_upload?overwrite=True")
        conn.putrequest("POST", "/v1/chunked_upload")
    conn.putheader("Content-Type", "application/json")
    global token
    conn.putheader("X-AUTH-Token","%s"%token)
    conn.putheader("X-File-Path",u"chunkupload1.txt")
    #fmtime = time.ctime(os.path.getmtime(uploadfile))
    #conn.putheader("X-META-FC-Mtime",fmtime)
    fsize = utils.getFileSize(f)# - 1
    print fsize
    conn.putheader("Content-Length", str(fsize))
    conn.endheaders()

    with open(f, 'r') as fp:
         chunk = fp.read(CHUNKSIZE)
         while chunk:
             conn.send('%s' % (chunk))
             chunk = fp.read(CHUNKSIZE)
    response = conn.getresponse()
    print '------status chunk_upload--------'
    print response.status
    print '------resaon chunk_upload--------'
    print response.reason
    ret= response.read()
    print ret
    retd= json.loads(ret)
    print retd
    return retd.get('upload_id'),str(retd.get('offset'))

def search( path, fname):
    #conn = httplib.HTTPConnection("localhost:7000")
    conn = httplib.HTTPConnection("%s:7000"%fcip)
    #conn.putrequest("GET", "/v1/search?query=testmedium30.txt")
    conn.putrequest("GET", "/v1/search%s?query=%s"%( path, fname))
    conn.putheader("Content-Type", "application/json")
    global token
    conn.putheader("X-AUTH-Token","%s"%token)
    conn.endheaders()
    response = conn.getresponse()
    print response.status, response.reason

    print '------status search--------'
    print response.status
    print '------resaon search--------'
    print response.reason
    ret= response.read()
    retd= json.loads(ret)
    print retd
    return response, retd[0]

def metadata(fname = None):
    headers = {"Content-type": "application/x-www-form-urlencoded",
            "Accept": "text/plain"}
#url = 'http://localhost:8090/search?q=haha&aq=f'

    #conn = httplib.HTTPConnection("localhost:7000")
    conn = httplib.HTTPConnection("%s:7000"%fcip)
    if fname:
        conn.putrequest("GET", "/v1/metadata/%s"%fname)
    else:
        conn.putrequest("GET", "/v1/metadata")
        
    global token
    conn.putheader("X-Auth-Token","%s"%token)
    conn.endheaders()

    response = conn.getresponse()
    print response.status, response.reason

    print '------status metadata--------'
    print response.status
    print '------resaon metadata--------'
    print response.reason
    print '----- read -------'
    #print response.getheader('x-dropbox-metadata')
    ret= response.read()
#print ret
    retd= json.loads(ret)
    #print retd
    return retd

def download(downloadfile, downloadpath, rev=None):
#url = 'http://localhost:8090/search?q=haha&aq=f'

    #conn = httplib.HTTPConnection("localhost:7000")
    conn = httplib.HTTPConnection("%s:7000"%fcip)
    if not rev:
        conn.putrequest("GET", "/v1/files/%s"%downloadpath)
    else:
        conn.putrequest("GET", "/v1/files/%s?rev=%s"%(downloadpath,rev))

    global token
    conn.putheader("X-Auth-Token","%s"%token)
    conn.endheaders()

    response = conn.getresponse()
    f = open(downloadfile,"wb")
    chunksize = 1024
#data = response.read(chunksize)
    data = 'init'
    while data:
        data = response.read(chunksize)
        if len(data)!=0:
            f.write(data)
        else:
            break
    f.close()
    conn.close()
    print '------status download--------'
    print response.status
    print '------resaon download--------'
    print response.reason
    print '----- read download-------'
    print response.getheader('x-dropbox-metadata')
    return response
def upload_compress(uploadfile, uploadpath, comFlag=False, encFlag=False):
    CHUNKSIZE = 4096
    url="http://127.0.0.1:7000/"
    #conn = httplib.HTTPConnection("127.0.0.1", 7000)
    #conn = httplib.HTTPConnection("%s:7000",%fcip)
    conn = httplib.HTTPConnection("%s:7000"%fcip)
    #conn.putrequest("POST", "/v1/files/%s?overwrite=true&parent_rev=notyet"%uploadpath)
    conn.putrequest("POST", "/v1/files/%s?overwrite=true&parent_rev=notyet"%uploadpath)

    conn.putheader("Content-Type", "application/json")
    global token
    conn.putheader("X-Auth-Token","%s"%token)
    #conn.putheader("Transfer-Encoding", "chunked")
    f=uploadfile
    fsize = utils.getFileSize(f)
    conn.putheader("CONTENT-LENGTH", str(fsize))
    conn.putheader("X-META-FC-COMPRESS",str(comFlag))
    conn.putheader("X-META-FC-ENCRYPT",str(encFlag))
    fmtime = time.ctime(os.path.getmtime(uploadfile))
    conn.putheader("X-META-FC-Mtime",fmtime)
    conn.endheaders()

    with open(f, 'r') as fp:
         chunk = fp.read(CHUNKSIZE)
         #print chunk
         while chunk:
             #conn.send('%x\r\n%s\r\n' % (len(chunk), chunk))
             conn.send('%s' % (chunk))
             chunk = fp.read(CHUNKSIZE)
         #conn.send('0\r\n\r\n')
    response = conn.getresponse()
    print '------status upload_compress--------'
    print response.status
    print '------resaon upload_compress--------'
    print response.reason
    print '----- read upload_compress-------'
    ret= response.read()
    print ret
    retd= json.loads(ret)
    print retd
    return response


def copy(uploadpath, uploadpath1=None):
    global tenant_id

    url="http://127.0.0.1:7000/"
    #conn = httplib.HTTPConnection("127.0.0.1", 7000)
    conn = httplib.HTTPConnection("%s:7000"%fcip)
    if uploadpath1:
        conn.putrequest('POST', '/v1/fileops/copy?root=%s&from_path=%s&to_path=%s'%(tenant_id, uploadpath, uploadpath1))
    else:
        conn.putrequest('POST', '/v1/fileops/copy?root=%s&from_path=%s&to_path=%s'%(tenant_id, uploadpath, uploadpath+'.copy'))
    global token
    conn.putheader("X-Auth-Token","%s"%token)
    conn.endheaders()
    response = conn.getresponse()
    print '------status copy--------'
    print response.status
    print '------resaon copy--------'
    print response.reason
    print '----- read -------'
    return response

def move(uploadpath, uploadpath1=None):

    global tenant_id
    url="http://127.0.0.1:7000/"
    #conn = httplib.HTTPConnection("127.0.0.1", 7000)
    conn = httplib.HTTPConnection("%s:7000"%fcip)
    if uploadpath1:
        conn.putrequest('POST', '/v1/fileops/move?root=%s&from_path=%s&to_path=%s'%(tenant_id, uploadpath, uploadpath1))
    else:
        conn.putrequest('POST', '/v1/fileops/move?root=%s&from_path=%s&to_path=%s'%(tenant_id, uploadpath, uploadpath+'.move'))
    global token
    conn.putheader("X-Auth-Token","%s"%token)
    conn.endheaders()
    response = conn.getresponse()
    print '------status move--------'
    print response.status
    print '------resaon move--------'
    print response.reason
    print '----- read move -------'
    return response


def moveback():
    global tenant_id
    url="http://127.0.0.1:7000/"
    #conn = httplib.HTTPConnection("127.0.0.1", 7000)
    conn = httplib.HTTPConnection("%s:7000"%fcip)
    conn.putrequest('POST', '/v1/fileops/move?root=%s&from_path=%s&to_path=%s'%(tenant_id, uploadpath+'.move', uploadpath))
    global token
    conn.putheader("X-Auth-Token","%s"%token)
    conn.endheaders()
    response = conn.getresponse()
    print '------status moveback--------'
    print response.status
    print '------resaon movebak--------'
    print response.reason
    print '----- read  moveback-------'
    return response

def revisions(fpath):

    global tenant_id
    CHUNKSIZE = 4096
#CHUNKSIZE = 6
    url="http://127.0.0.1:7000/"
    #conn = httplib.HTTPConnection("127.0.0.1", 7000)
    conn = httplib.HTTPConnection("%s:7000"%fcip)
    body = json.dumps({'root':'%s'%tenant_id,'path':'/hahalala'})

    conn.putrequest('GET', '/v1/revisions/%s'%fpath)
    global token
    conn.putheader("X-Auth-Token","%s"%token)
    conn.endheaders()
    response = conn.getresponse()
#response = getresponse()
    print '------status revision--------'
    print response.status
    print '------resaon revision--------'
    print response.reason
    print '----- read -------'
    ret= response.read()
#print ret
    retd= json.loads(ret)
    print retd
    return retd



def upload_createdFolder():
    CHUNKSIZE = 4096
#CHUNKSIZE = 6
    url="http://127.0.0.1:7000/"
    #conn = httplib.HTTPConnection("127.0.0.1", 7000)
    conn = httplib.HTTPConnection("%s:7000"%fcip)
    conn.putrequest("POST", "/v1/files/%s/%s?overwrite=true&parent_rev=notyet"%(createfoldername, createfolderfile))
    conn.putheader("Content-Type", "application/json")
    conn.putheader("Transfer-Encoding", "chunked")
    global token
    conn.putheader("X-Auth-Token","%s"%token)
    f=uploadfile
    fmtime = time.ctime(os.path.getmtime(uploadfile))
    conn.putheader("X-META-FC-Mtime",fmtime)
    conn.endheaders()
    with open(f, 'r') as fp:
         chunk = fp.read(CHUNKSIZE)
         #print chunk
         while chunk:
             conn.send('%x\r\n%s\r\n' % (len(chunk), chunk))
             chunk = fp.read(CHUNKSIZE)
         conn.send('0\r\n\r\n')
    response = conn.getresponse()
    print '------status upload_createFolder--------'
    print response.status
    print '------resaon uplaod_createFolder--------'
    print response.reason
    print '----- read upload_createFolder-------'
    ret= response.read()
    print ret
    retd= json.loads(ret)
    print retd
    return response


def upload(uploadfile, uploadpath ):
    CHUNKSIZE = 4096
#CHUNKSIZE = 6
    url="http://127.0.0.1:7000/"
    #conn = httplib.HTTPConnection("127.0.0.1", 7000)
    conn = httplib.HTTPConnection("%s:7000"%fcip)
#conn.putrequest("POST", "/?file=save.jpg")
#conn.putrequest("POST", "/?file=save.jpg")
#conn.putrequest("PUT", "/test?file=haha")
    conn.putrequest("POST", "/v1/files/%s?overwrite=true&parent_rev=notyet"%uploadpath)
#conn.putheader("Content-Type", "application/zip")
    conn.putheader("Content-Type", "application/json")
    global token
    conn.putheader("X-Auth-Token","%s"%token)
    #conn.putheader("Transfer-Encoding", "chunked")
    f=uploadfile
    fsize = utils.getFileSize(f)

    conn.putheader("Content-Length", str(fsize) )
#conn.putheader("Filepath","/tmp/size/s.txt")
    conn.endheaders()

#fp = '/root/random.zip'
#fp = './zero.txt'
#fp = './ddd.jpg'
#fp = './size.txt'
#fp='./random.txt'
# fp = 'C:\Users\haow\Downloads\MONACO.TTF'
#f = os.path.basename(fp)
#print f
#print mimetypes.guess_type(f)
    with open(f, 'r') as fp:
         chunk = fp.read(CHUNKSIZE)
         #print chunk
         while chunk:
             #conn.send('%x\r\n%s\r\n' % (len(chunk), chunk))
             conn.send('%s' % (chunk))
             chunk = fp.read(CHUNKSIZE)
         #conn.send('0\r\n\r\n')
    response = conn.getresponse()
    print '------status upload--------'
    print response.status
    print '------resaon upload--------'
    print response.reason
    print '----- read upload-------'
    ret= response.read()
    print ret
    retd= json.loads(ret)
    print retd
    conn.close()
    return response

def maprealpath(pathf):
    global tenant_id
    mapdir = '/opt/monga/%s/home/'%tenant_id
    return mapdir+uploadpath
    
def checkFileDiff(downloadfile, uploadfile):
    ret = commands.getoutput('diff %s %s'%(downloadfile, uploadfile))
    if len(ret)==0:
        return True
    else:
        return False
def checkFileExisted(uploadpath):
    global tenant_id
    mapdir = '/opt/monga/%s/home/'%tenant_id
    checkpath = mapdir+uploadpath
    return os.path.exists(checkpath)
def createFolder(pathfolder):
    global tenant_id
    CHUNKSIZE = 4096
    url="http://127.0.0.1:7000/"
    #conn = httplib.HTTPConnection("127.0.0.1", 7000)
    conn = httplib.HTTPConnection("%s:7000"%fcip)
    body = json.dumps({'root':'%s'%tenant_id,'path':'/hahalala'})
    conn.putrequest('POST', '/v1/fileops/create_folder?path=%s'%pathfolder)
    global token
    conn.putheader("X-Auth-Token","%s"%token)
    conn.endheaders()

    response = conn.getresponse()
#response = getresponse()
    print '------status createFolder--------'
    print response.status
    print '------resaon createFolder--------'
    print response.reason
    print '----- read createFolder-------'
    ret= response.read()
    print ret
    retd= json.loads(ret)
    print retd
    return response
def delete(path):
    global tenant_id
    url="http://127.0.0.1:7000/"
    #conn = httplib.HTTPConnection("127.0.0.1", 7000)
    conn = httplib.HTTPConnection("%s:7000"%fcip)
    conn.putrequest('POST', '/v1/fileops/delete?root=%s&path=%s'%(tenant_id, path))
    global token
    conn.putheader("X-Auth-Token","%s"%token)
    conn.endheaders()
    response = conn.getresponse()
    print '------status delete--------'
    print response.status
    print '------resaon delete--------'
    print response.reason
    print '----- read delete -------'
    return response

def downloadandCheck(uploadfile, uploadpath, rev=None, comFlag=False):
    count = 0
    looplen = len(uploadfile)
    for count in range(0, looplen):
        if rev:
            ret = download(uploadfile[count], uploadpath[count], rev[count])
        else:
            ret = download(uploadfile[count], uploadpath[count])
        yield ret,count
        #assertEqual(ret.status, 200)
        #assertEqual(checkFileExisted(uploadpath[count]), True)
        count = count + 1

def uploadandCheck(uploadfile, uploadpath, comFlag=False, encFlag=False):
    count = 0
    looplen = len(uploadfile)
    for count in range(0, looplen):
        if comFlag or encFlag:
            print comFlag
            print encFlag
            ret = upload_compress(uploadfile[count], uploadpath[count], comFlag, encFlag)
        else:
            ret = upload(uploadfile[count], uploadpath[count])
        yield ret,count
        #assertEqual(ret.status, 200)
        #assertEqual(checkFileExisted(uploadpath[count]), True)
        count = count + 1

def checkInside(pathes, target):
    return target == pathes

class FileOpTest(unittest.TestCase):
    global loop
    def setUp(self):
        self.uploadfile=['/tmp/testing/small.txt', '/tmp/testing/medium.txt']
        self.uploadpath=['testsmall3%s.txt'%str(loop), 'testmedium3%s.txt'%str(loop)]
    def testupload(self):
        for ret, count in uploadandCheck(self.uploadfile, self.uploadpath):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True)

class FolderOpTest(unittest.TestCase):
    global loop
    def setUp(self):
        self.foldername = 'folderintest%s'%str(loop)
        self.uploadfile=['/tmp/testing/small.txt', '/tmp/testing/medium.txt']
        self.uploadpath=['/%s/testsmall3%s.txt'%(self.foldername,str(loop)), '/%s/testmedium4%s.txt'%(self.foldername,str(loop))]
    def testCreateFolder(self):
        ret = createFolder(self.foldername)
        self.assertEqual(ret.status, 200)
        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True)

class CopyOpTest(unittest.TestCase):
    global loop
    def setUp(self):
        self.foldername = ['foldertestncopy1%s'%str(loop),'foldertestcopy2%s'%str(loop)]
        self.uploadfile=['/tmp/testing/small.txt', '/tmp/testing/medium.txt','/tmp/testing/small.txt']
        self.uploadpath=['/%s/testsmall3%s.txt'%(self.foldername[0],str(loop)), '/%s/testmedium4%s.txt'%(self.foldername[0],str(loop))
            ,u'/%s/%s'%(self.foldername[0],'%D9%81%D8%A7%D8%B1%D8%B3%DB%8C')]
        self.uploadpathcopy=['/%s/testsmall3%s.txt'%(self.foldername[1],str(loop)), '/%s/testmedium4%s.txt'%(self.foldername[1],str(loop))
            ,u'/%s/%s'%(self.foldername[1],'%D9%81%D8%A7%D8%B1%D8%B3%DB%8C')]
        for folder in self.foldername:
            ret = createFolder(folder)
            self.assertEqual(ret.status, 200)

        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True)

    def testCopyFolder(self):

        for uppath in self.uploadpath:
            ret = copy(uppath)
            self.assertEqual(ret.status, 200)
        count = 0
        for uppath in self.uploadpath:
            print uppath
            print self.uploadpathcopy[count]
            ret = copy(uppath, self.uploadpathcopy[count])
            self.assertEqual(ret.status, 200)
            count = count +1
    
class MoveOpTest(unittest.TestCase):
    global loop
    def setUp(self):
        self.foldername = ['foldertestmove1%s'%str(loop),'foldertestmove2%s'%str(loop)]
        self.uploadfile=['/tmp/testing/small.txt', '/tmp/testing/medium.txt','/tmp/testing/small.txt']
        self.uploadpath=['/%s/testsmall3%s.txt'%(self.foldername[0],str(loop)), '/%s/testmedium4%s.txt'%(self.foldername[0],str(loop))
            ,u'/%s/%s'%(self.foldername[0],'%D9%81%D8%A7%D8%B1%D8%B3%DB%8C')]
        self.uploadpathcopy=['/%s/testsmall3%s.txt'%(self.foldername[1],str(loop)), '/%s/testmedium4%s.txt'%(self.foldername[1],str(loop))
            ,u'/%s/%s'%(self.foldername[1],'%D9%81%D8%A7%D8%B1%D8%B3%DB%8C')]
        for folder in self.foldername:
            ret = createFolder(folder)
            self.assertEqual(ret.status, 200)

        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True)
    def testCopyFolder(self):

        for uppath in self.uploadpath:
            ret = copy(uppath)
            self.assertEqual(ret.status, 200)
        count = 0
        for uppath in self.uploadpath:
            print uppath
            print self.uploadpathcopy[count]
            ret = move(uppath, self.uploadpathcopy[count])
            self.assertEqual(ret.status, 200)
            count = count +1


class DeleteOpTest(unittest.TestCase):
    global loop
    def setUp(self):
        self.foldername = ['foldertestdelete%s'%str(loop)]
        self.uploadfile=['/tmp/testing/small.txt', '/tmp/testing/medium.txt','/tmp/testing/small.txt']
        self.uploadpath=['/%s/testdelete1%s.txt'%(self.foldername[0],str(loop)), '/%s/testdelete2%s.txt'%(self.foldername[0],str(loop))
            ,u'/%s/%s'%(self.foldername[0],'%D9%81%D8%A7%D8%B1%D8%B3%DB%8C')]

        for folder in self.foldername:
            ret = createFolder(folder)
            self.assertEqual(ret.status, 200)

        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True)
    def testDeleteFile(self):

        for uppath in self.uploadpath:
            ret = delete(uppath)
            self.assertEqual(ret.status, 200)
            #ret = checkFileExisted(uppath)
            #self.assertEqual(ret, False )
        for dfolder in self.foldername:
            ret = delete(dfolder)
            self.assertEqual(ret.status, 200)
            
class DownloadOpTest(unittest.TestCase):
    global loop
    def setUp(self):    
        self.foldername = ['foldertestdownload%s'%str(loop)]
        self.uploadfile=['/tmp/testing/medium.txt','/tmp/testing/medium.txt']
        self.uploadpath=['/%s/medium%s.txt'%(self.foldername[0],str(loop))
            ,'/%s/%s'%(self.foldername[0],'%D9%81%D8%A7%D8%B1%D8%B3%DB%8C')]
        self.downloadfile=['/tmp/medium%s.txt'%str(loop),'/tmp/mediumuni%s.txt'%str(loop)]
        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True)
    def testDownload(self):
        for ret,count in downloadandCheck(self.downloadfile, self.uploadpath):
            self.assertEqual(ret.status, 200)
            self.assertEqual(checkFileDiff(self.downloadfile[count], self.uploadfile[count]), True)


class CompressionOpTest(unittest.TestCase):
    global loop
    def setUp(self):    
        self.foldername = ['foldertestcompress%s'%str(loop)]
        self.uploadfile=['/tmp/testing/zero.txt','/tmp/testing/zero.txt']
        self.uploadpath=['%s/compress%s.txt'%(self.foldername[0],str(loop))
            ,u'/%s/%s'%(self.foldername[0],'%D9%81%D8%A7%D8%B1%D8%B3%DB%8C')]
        self.downloadfile=['/tmp/decompress%s.txt'%str(loop),'/tmp/decompressuni%s.txt'%str(loop)]
        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath,True, False):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True, False)
    def testCompression(self):
        for ret,count in downloadandCheck(self.downloadfile, self.uploadpath):
            self.assertEqual(ret.status, 200)
            self.assertEqual(checkFileDiff(self.downloadfile[count], self.uploadfile[count]), True)

class EncryptOpTest(unittest.TestCase):
    global loop
    def setUp(self):    
        self.foldername = ['foldertestencrypt%s'%str(loop)]
        self.uploadfile=['/tmp/testing/zero.txt','/tmp/testing/zero.txt']
        self.uploadpath=['/%s/encrypt%s.txt'%(self.foldername[0],str(loop))
            ,u'/%s/%s'%(self.foldername[0],'%D9%81%D8%A7%D8%B1%D8%B3%DB%8C')]
        self.downloadfile=['/tmp/decrypt%s.txt'%str(loop),'/tmp/decryptUni%s.txt'%str(loop)]
        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath, False, True):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True)
    def testEncryption(self):
        for ret,count in downloadandCheck(self.downloadfile, self.uploadpath):
            self.assertEqual(ret.status, 200)
            self.assertEqual(checkFileDiff(self.downloadfile[count], self.uploadfile[count]), True)
        
class CompressEncryptOpTest(unittest.TestCase):
    global loop
    def setUp(self):    
        self.foldername = ['foldertestcompressencrypt%s'%str(loop)]
        self.uploadfile=['/tmp/testing/zero.txt','/tmp/testing/zero.txt']
        self.uploadpath=['/%s/compressencrypt%s.txt'%(self.foldername[0],str(loop))
            ,u'/%s/%s'%(self.foldername[0],'%D9%81%D8%A7%D8%B1%D8%B3%DB%8C')]
        self.downloadfile=['/tmp/compressdecrypt%s.txt'%str(loop),'/tmp/compressdecryptUNI%s.txt'%str(loop)]
        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath, True, True):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True)
    def testCompressEncryption(self):
        for ret,count in downloadandCheck(self.downloadfile, self.uploadpath):
            self.assertEqual(ret.status, 200)
            self.assertEqual(checkFileDiff(self.downloadfile[count], self.uploadfile[count]), True)
            

class MetadataOpTest(unittest.TestCase):
    global loop
    def setUp(self):    
        self.foldername = ['foldertestmetadata%s'%str(loop)]
        self.uploadfile=['/tmp/testing/zero.txt']
        self.uploadpath=['/%s/compressencrypt.txt%s'%(self.foldername[0],str(loop))]
        self.downloadfile=['/tmp/compressdecrypt.txt%s'%str(loop)]
        self.createdfolder = ['/'+self.foldername[0]+'/testmeta%s'%str(loop)]
        createFolder(self.createdfolder[0])
        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath, True, True):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True)
    def testMetaData(self):
        def checkInlist(target, *src):
            for tsrc in src:
                for ttsrc in tsrc:
                    print '===== in compare ========'
                    print ttsrc
                    if target == ttsrc:
                        return True
            return False


        getmeta = metadata(self.foldername[0])        
        print getmeta
        metacontent = getmeta.get('contents')
        print metacontent
        for mc in metacontent:
            print '=== source meta======='
            print mc.get('path')
            res = checkInlist(mc.get('path'), self.foldername, self.uploadpath, self.createdfolder)
            self.assertEqual(res , True)
"""
class unirevisionOpTest(unittest.TestCase):
    global loop
    def setUp(self):    
        self.foldername = ['unifoldertestrevision%s'%str(loop)]
        self.uploadfile=['/tmp/testing/v1size.txt','/tmp/testing/v2size.txt','/tmp/testing/v3size.txt']
        self.uploadpath=['/%s/%s%s'%(self.foldername[0],'%D9%81%D8%A7%D8%B1%D8%B3%DB%8C',str(loop))
                ,'/%s/%s%s'%(self.foldername[0],'%D9%81%D8%A7%D8%B1%D8%B3%DB%8C',str(loop))
                ,'/%s/%s%s'%(self.foldername[0],'%D9%81%D8%A7%D8%B1%D8%B3%DB%8C',str(loop))]



        self.downloadfile=['/tmp/vd1unisize.txt%s'%str(loop),'/tmp/vd2unisize.txt%s'%str(loop),'/tmp/vd3unisize.txt%s'%str(loop)]

        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath, False, False):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True)
        
    def testuniRevision(self):
        def _timeToValue(ha):
            print ha
            hha= ha.replace(':','').split()
            ss = str(hha[3]+hha[4])
            print ss
            return int(ss)

        def sortdict(vals, data):
            sortvals = []
            for val in vals:
                sortvals.append( _timeToValue(val))
            newsortval = sorted(sortvals, key=int)
            newsort = []
            #print 'start sort'
            for i in newsortval:
                #print i
                newsort.append(data.get(i))
            return newsort
            
            
        time.sleep(30)
        #print 'get revision'
        revstmp = revisions(self.uploadpath[0])
        revs=[]
        revsdict={}
        datestr=[]
        for rev in revstmp:
            print rev.get('modified'),rev.get('rev')
            revsdict[_timeToValue(rev.get('modified'))]=rev.get('rev')
            datestr.append(rev.get('modified'))
        revs = sortdict(datestr, revsdict)
        #print ' sorted data =========='
        #print revs
        print 'check download ---------'
        for ret,count in downloadandCheck(self.downloadfile, self.uploadpath, revs):
            self.assertEqual(ret.status, 200)
            self.assertEqual(checkFileDiff(self.downloadfile[count], self.uploadfile[count]), True)
"""

class revisionOpTest(unittest.TestCase):
    global loop
    def setUp(self):    
        self.foldername = ['foldertestrevision%s'%str(loop)]
        self.uploadfile=['/tmp/testing/v1size.txt','/tmp/testing/v2size.txt','/tmp/testing/v3size.txt']
        self.uploadpath=['/%s/vsize.txt%s'%(self.foldername[0],str(loop)),'/%s/vsize.txt%s'%(self.foldername[0],str(loop))
                ,'/%s/vsize.txt%s'%(self.foldername[0],str(loop))]
        self.downloadfile=['/tmp/vd1size.txt%s'%str(loop),'/tmp/vd2size.txt%s'%str(loop),'/tmp/vd3size.txt%s'%str(loop)]

        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath, False, False):
            self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True)
            time.sleep(2)
        
    def testRevision(self):
        def _timeToValue(ha):
            print ha
            hha= ha.replace(':','').split()
            ss = str(hha[3]+hha[4])
            print ss
            return int(ss)

        def sortdict(vals, data):
            sortvals = []
            for val in vals:
                sortvals.append( _timeToValue(val))
            newsortval = sorted(sortvals, key=int)
            newsort = []
            #print 'start sort'
            for i in newsortval:
                #print i
                newsort.append(data.get(i))
            return newsort
            
            
        #print 'get revision'
        revstmp = revisions(self.uploadpath[0])
        revs=[]
        revsdict={}
        datestr=[]
        for rev in revstmp:
            print rev.get('modified'),rev.get('rev')
            revsdict[_timeToValue(rev.get('modified'))]=rev.get('rev')
            datestr.append(rev.get('modified'))
        revs = sortdict(datestr, revsdict)
        #print ' sorted data =========='
        #print revs
        
        for ret,count in downloadandCheck(self.downloadfile, self.uploadpath, revs):
            self.assertEqual(ret.status, 200)
            self.assertEqual(checkFileDiff(self.downloadfile[count], self.uploadfile[count]), True)

class initDataOp(unittest.TestCase):
    global loop
    def testinitData(self):
        filelists = ['medium.txt','size.txt','small.txt','v1size.txt','v2size.txt','v3size.txt','zero_large.txt','zero.txt']
        iniTestData(filelists)
#create chunkData
        iniChunkData()


class initFolderOp(unittest.TestCase):
    global loop
    def testInitFolder(self):
        print 'test initial folder'
        ret = metadata()        
        print ret
        self.assertEqual(ret.get('bytes'),0)

class unisearchOpTest(unittest.TestCase):
    def setUp(self):    
        self.foldername = ['/foldertestunisearch%s'%str(loop)]
        self.uploadfile=['/tmp/testing/zero.txt']
        self.uploadname = ['%s'%('%D9%81%D8%A7%D8%B1%D8%B3%DB%8C')]
        self.uploadpath=['%s/%s'%(self.foldername[0], self.uploadname[0])]
        self.createdfolder = [self.foldername[0]]
        createFolder(self.createdfolder[0])
        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath, False, False):
            self.assertEqual(ret.status, 200)
    def testSearch(self):
        resp, retd = search(self.foldername[0], self.uploadname[0])
        self.assertEqual(resp.status, 200)
        print retd.get('path')
        checkFlag = checkInside(retd.get('path'), self.uploadpath[0])
        #it not right for FAIL
        self.assertEqual(checkFlag,False)

class searchOpTest(unittest.TestCase):
    def setUp(self):    
        self.foldername = ['/foldertestsearch%s'%str(loop)]
        self.uploadfile=['/tmp/testing/zero.txt']
        self.uploadname = ['search.txt%s'%str(loop)]
        self.uploadpath=['%s/%s'%(self.foldername[0], self.uploadname[0])]
        self.createdfolder = [self.foldername[0]]
        #createFolder(self.createdfolder[0])
        print 'initial upload data'
        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath, False, False):
            self.assertEqual(ret.status, 200)
    def testSearch(self):
        resp, retd = search( self.foldername[0], self.uploadname[0])
        self.assertEqual(resp.status, 200)
        print retd.get('path')
        checkFlag = checkInside(retd.get('path'), self.uploadpath[0])
        self.assertEqual(checkFlag,True)


class UnicodeUploadOpTest(unittest.TestCase):
    global loop
    def setUp(self):
        self.uploadfile=['/tmp/testing/small.txt', '/tmp/testing/medium.txt']
        self.uploadpath=['%D9%81%D8%A7%D8%B1%D8%B3%DB%8C', '%D9%81%D8%A7%D9%B1%D8%B3%DB%8C']
    def testupload(self):
        for ret, count in uploadandCheck(self.uploadfile, self.uploadpath):
            self.assertEqual(ret.status, 200)

class ChunkUploadOpTest(unittest.TestCase):
    global loop
    def setUp(self):    
        self.foldername = ['foldertestchunk%s'%str(loop)]
        self.uploadfile=['/tmp/testing/chunkfiletestzero.txt']
        self.uploadpath=['%s/compress%s.txt'%(self.foldername[0],str(loop))]
        self.downloadfile=['/tmp/decompress%s.txt'%str(loop)]
        #for ret,count in uploadandCheck(self.uploadfile, self.uploadpath,True, False):
        #    self.assertEqual(ret.status, 200)
            #self.assertEqual(checkFileExisted(self.uploadpath[count]), True, False)
    def testChunkUpload(self):
        cloop = 0
        offsetnum=0
        upload_id, offset = chunk_upload()
        for i in range(1,30):
            print i
            upoad_id, offset = chunk_upload(upload_id, offset, i)

        chunk_commit(upload_id)
            #offsetnum = int(offset) + 1024000
        
        #for ret,count in downloadandCheck(self.downloadfile, self.uploadpath):
        #    self.assertEqual(ret.status, 200)
        #    self.assertEqual(checkFileDiff(self.downloadfile[count], self.uploadfile[count]), True)
class RestoreOpTest(unittest.TestCase):
    global loop
    def setUp(self):    
        self.foldername = ['/foldertestrestore%s'%str(loop)]
        self.uploadfile=['/tmp/testing/zero.txt','/tmp/testing/zero.txt']
        self.uploadname = ['restore.txt%s'%str(loop),'restore.txt%s'%str(loop) ]
        self.uploadpath=['%s/%s'%(self.foldername[0], self.uploadname[0]),'%s/%s'%(self.foldername[0], self.uploadname[0])]
        self.createdfolder = [self.foldername[0]]
        createFolder(self.createdfolder[0])
        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath, False, False):
            self.assertEqual(ret.status, 200)
    def testRestore(self):
        rets = revisions(self.foldername[0]+'/'+self.uploadname[0])        
        print '---------------------'
        print rets
        print '------   start iter ------------'
        oldrevs = []
        for ret in rets:
            oldrevs.append(ret.get('rev'))
        rets = restore(self.foldername[0]+'/'+self.uploadname[0], oldrevs[1])
        rets = revisions(self.foldername[0]+'/'+self.uploadname[0])        
        newrevs = []
        for ret in rets:
            newrevs.append(ret.get('rev'))
        print 'old revs'
        print oldrevs
        print 'new revs'
        print newrevs
        self.assertEqual(newrevs[1], oldrevs[0])
        self.assertEqual(newrevs[0], oldrevs[1])

class DeepFolderOpTest(unittest.TestCase):
    global loop
    def setUp(self):
        self.foldername = 'folderdeep%s'%str(loop)
        self.uploadfile=['/tmp/testing/small.txt', '/tmp/testing/small.txt', '/tmp/testing/small.txt', '/tmp/testing/small.txt',
             '/tmp/testing/small.txt', '/tmp/testing/small.txt',
             '/tmp/testing/medium.txt','/tmp/testing/small.txt',
             '/tmp/testing/small.txt','/tmp/testing/small.txt',
             '/tmp/testing/small.txt','/tmp/testing/medium.txt']
        self.uploadpath=['/%s/aaa/testsmall3%s.txt'%(self.foldername,str(loop)), '/%s/aaa/bbb/testmedium4%s.txt'%(self.foldername,str(loop)),
            '/%s/aaa/bbb/ccc/testmedium4%s.txt'%(self.foldername,str(loop)),'/%s/aaa/bbb/ddd/testmedium4%s.txt'%(self.foldername,str(loop)),
            '/%s/aaa/bbb/eee/testmedium4%s.txt'%(self.foldername,str(loop)), '/%s/aaa/bbb/eee/fff/testmedium4%s.txt'%(self.foldername,str(loop)),
            '/%s/aaa/bbb/eee/testmedium41%s.txt'%(self.foldername,str(loop)),'/%s/aaa/bbb/eee/testmedium42%s.txt'%(self.foldername,str(loop)),
            '/%s/bbb/bbb/eee/testmedium41%s.txt'%(self.foldername,str(loop)),'/%s/bbb/bbb/eee/testmedium42%s.txt'%(self.foldername,str(loop)),
            '/%s/ccc/bbb/eee/testmedium41%s.txt'%(self.foldername,str(loop)),'/%s/ccc/bbb/eee/testmedium42%s.txt'%(self.foldername,str(loop))]
    def testCreateFolder(self):
        ret = createFolder(self.foldername)
        self.assertEqual(ret.status, 200)
        for ret,count in uploadandCheck(self.uploadfile, self.uploadpath):
            self.assertEqual(ret.status, 200)
class deletetenantOp(unittest.TestCase):
    global loop
    def testdeletetenant(self):
#create chunkData
        res = deletetenant()
        self.assertEqual(res, 204)
        

if __name__=='__main__':
    global loop
    loop = 0
    suite = unittest.TestLoader().loadTestsFromTestCase(initDataOp)
    unittest.TextTestRunner(verbosity=2).run(suite)

    suite = unittest.TestLoader().loadTestsFromTestCase(initFolderOp)
    unittest.TextTestRunner(verbosity=2).run(suite)
    for i in range(0,1):
        loop = i
        unittest.main(exit=False,argv=[sys.argv[0]])

    #suite = unittest.TestLoader().loadTestsFromTestCase(deletetenantOp)
    #unittest.TextTestRunner(verbosity=2).run(suite)
"""
global loop
loop = 0
suite = unittest.TestLoader().loadTestsFromTestCase(searchOpTest)
unittest.TextTestRunner(verbosity=2).run(suite)
"""
