import unittest
import sys
import mimetypes
import os
import json
import httplib, urllib
import time
#CHUNKSIZE = 65563
uploadfile='/root/small.txt'
uploadpath='size.txt'
downloadfile='/tmp/download_size.txt'
createfoldername='testfolder2'
createfolderfile='size1.txt'
def copy():
    url="http://127.0.0.1:7000/"
    conn = httplib.HTTPConnection("127.0.0.1", 7000)
    conn.request('POST', '/v1/fileops/copy?root=tenant_id&from_path=%s&to_path=%s'%(uploadpath, uploadpath+'.copy'))
    response = conn.getresponse()
    print '------status--------'
    print response.status
    print '------resaon--------'
    print response.reason
    print '----- read -------'
    return response

def move():
    url="http://127.0.0.1:7000/"
    conn = httplib.HTTPConnection("127.0.0.1", 7000)
    conn.request('POST', '/v1/fileops/move?root=tenant_id&from_path=%s&to_path=%s'%(uploadpath, uploadpath+'.move'))
    response = conn.getresponse()
    print '------status--------'
    print response.status
    print '------resaon--------'
    print response.reason
    print '----- read -------'
    return response


def moveback():
    url="http://127.0.0.1:7000/"
    conn = httplib.HTTPConnection("127.0.0.1", 7000)
    conn.request('POST', '/v1/fileops/move?root=tenant_id&from_path=%s&to_path=%s'%(uploadpath+'.move', uploadpath))
    response = conn.getresponse()
    print '------status--------'
    print response.status
    print '------resaon--------'
    print response.reason
    print '----- read -------'
    return response

def revisions():
    CHUNKSIZE = 4096
#CHUNKSIZE = 6
    url="http://127.0.0.1:7000/"
    conn = httplib.HTTPConnection("127.0.0.1", 7000)
#conn.putrequest("POST", "/?file=save.jpg")
#conn.putrequest("POST", "/?file=save.jpg")
#conn.putrequest("PUT", "/test?file=haha")
#conn.putrequest("POST", "/fileops", body)
#conn.putheader("Content-Type", "application/zip")
#conn.putheader("Content-Type", "application/json")
#conn.putheader("Transfer-Encoding", "chunked")
##conn.putheader("Filepath","/tmp/size/s.txt")
#conn.endheaders(body)
#params = urllib.urlencode({'root':'tenant_id','path':'/haahah'})
    body = json.dumps({'root':'tenant_id','path':'/hahalala'})

    conn.request('GET', '/v1/revisions/%s/%s'%(createfoldername, createfolderfile))
    response = conn.getresponse()
#response = getresponse()
    print '------status--------'
    print response.status
    print '------resaon--------'
    print response.reason
    print '----- read -------'
    ret= response.read()
#print ret
    retd= json.loads(ret)
    print retd
    return response



def upload_createdFolder():
    CHUNKSIZE = 4096
#CHUNKSIZE = 6
    url="http://127.0.0.1:7000/"
    conn = httplib.HTTPConnection("127.0.0.1", 7000)
    conn.putrequest("POST", "/v1/files/%s/%s?overwrite=true&parent_rev=notyet"%(createfoldername, createfolderfile))
    conn.putheader("Content-Type", "application/json")
    conn.putheader("Transfer-Encoding", "chunked")
    conn.endheaders()
    f=uploadfile
    with open(f, 'r') as fp:
         chunk = fp.read(CHUNKSIZE)
         #print chunk
         while chunk:
             conn.send('%x\r\n%s\r\n' % (len(chunk), chunk))
             chunk = fp.read(CHUNKSIZE)
         conn.send('0\r\n\r\n')
    response = conn.getresponse()
    print '------status--------'
    print response.status
    print '------resaon--------'
    print response.reason
    print '----- read -------'
    ret= response.read()
    print ret
    retd= json.loads(ret)
    print retd
    return response

def getMeta():
    params = urllib.urlencode({'spam': 1, 'eggs': 2, 'bacon': 0})
    headers = {"Content-type": "application/x-www-form-urlencoded",
            "Accept": "text/plain"}
#url = 'http://localhost:8090/search?q=haha&aq=f'

    conn = httplib.HTTPConnection("localhost:7000")
    conn.request("GET", "/v1/metadata/%s"%createfoldername, params, headers)
    response = conn.getresponse()
    print response.status, response.reason


#print data
#conn.close()

    print '------status--------'
    print response.status
    print '------resaon--------'
    print response.reason
    print '----- read -------'
    print response.getheader('x-dropbox-metadata')
    ret= response.read()
#print ret
    retd= json.loads(ret)
    print retd
    return response

def createfolder():
    url="http://127.0.0.1:7000/"
    conn = httplib.HTTPConnection("127.0.0.1", 7000)
    conn.request('POST', '/v1/fileops/create_folder?path=%s'%createfoldername)
    response = conn.getresponse()
#response = getresponse()
    #print '------status--------'
    #print response.status
    #print '------resaon--------'
    #print response.reason
    #print '----- read -------'
    #ret= response.read()
    #print ret
    #retd= json.loads(ret)
    #print retd
    conn.close()
    return response

def download():
    params = urllib.urlencode({'spam': 1, 'eggs': 2, 'bacon': 0})
    headers = {"Content-type": "application/x-www-form-urlencoded",
            "Accept": "text/plain"}
#url = 'http://localhost:8090/search?q=haha&aq=f'

    conn = httplib.HTTPConnection("localhost:7000")
    conn.request("GET", "/v1/files/%s"%uploadpath, params, headers)
    response = conn.getresponse()
    print response.status, response.reason
#print data
#conn.close()
    f = open(downloadfile,"wb")
    chunksize = 4096
    data = response.read(chunksize)
    while data:
        f.write(data)
        data = response.read(chunksize)
    f.close()

    #print '------status--------'
    #print response.status
    #print '------resaon--------'
    #print response.reason
    print '----- read -------'
    print response.getheader('x-dropbox-metadata')
    conn.close()
    return response


def upload(uploadname='/root/small.txt'):
    CHUNKSIZE = 4096
#CHUNKSIZE = 6
    url="http://127.0.0.1:7000/"
    conn = httplib.HTTPConnection("127.0.0.1", 7000)
#conn.putrequest("POST", "/?file=save.jpg")
#conn.putrequest("POST", "/?file=save.jpg")
#conn.putrequest("PUT", "/test?file=haha")
    conn.putrequest("POST", "/v1/files/%s?overwrite=true&parent_rev=notyet"%uploadpath)
#conn.putheader("Content-Type", "application/zip")
    conn.putheader("Content-Type", "application/json")
    conn.putheader("Transfer-Encoding", "chunked")
#conn.putheader("Filepath","/tmp/size/s.txt")
    conn.endheaders()

#fp = '/root/random.zip'
#fp = './zero.txt'
#fp = './ddd.jpg'
#fp = './size.txt'
    f=uploadfile
#fp='./random.txt'
# fp = 'C:\Users\haow\Downloads\MONACO.TTF'
#f = os.path.basename(fp)
#print f
#print mimetypes.guess_type(f)
    with open(f, 'r') as fp:
         chunk = fp.read(CHUNKSIZE)
         #print chunk
         while chunk:
             conn.send('%x\r\n%s\r\n' % (len(chunk), chunk))
             chunk = fp.read(CHUNKSIZE)
         conn.send('0\r\n\r\n')
    response = conn.getresponse()
    print '------status--------'
    print response.status
    print '------resaon--------'
    print response.reason
    print '----- read -------'
    ret= response.read()
    print ret
    retd= json.loads(ret)
    print retd
    conn.close()
    return response


class FileOpTest(unittest.TestCase):
    def testupload(self):
        print 'start upload--------------'
        resp=upload()
       
        self.assertEqual(resp.status, 200)
        #time.sleep(1)

        print 'start download-------------'
        respd=download()
        print respd
        self.assertEqual(respd.status, 200)
        
        respd= move()
        self.assertEqual(respd.status, 200)

        respd = moveback()
        self.assertEqual(respd.status, 200)

        respd = copy()
        self.assertEqual(respd.status, 200)
        
        #time.sleep(1)
    #def testdownload(self):
    #def testcreatefolder(self):
    #    respc=createfolder()
    #    self.assertEqual(respc.status, 200)
    #    time.sleep(1)
    
    def testcreateFolder(self):
        resp = createfolder()   
        self.assertEqual(resp.status, 200)
        resp = upload_createdFolder()
        self.assertEqual(resp.status, 200)
        resp = getMeta()
        self.assertEqual(resp.status, 200)
        resp = revisions()
        self.assertEqual(resp.status, 200)
    
        #self.assertEqual(func.calc(2,2), 4)



if __name__=='__main__':
    unittest.main()

