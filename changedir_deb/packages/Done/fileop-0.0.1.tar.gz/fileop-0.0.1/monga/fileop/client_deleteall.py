import httplib
import sys
import mimetypes
import os
import json
import urllib
url="http://127.0.0.1:7000/"
conn = httplib.HTTPConnection("127.0.0.1", 7000)
conn.putrequest('POST', '/v1/fileops/delete?path=aaa') 
conn.putheader("X-AUTH-Token","3e5091fe003a4a9793d93c6b0a171f23")
conn.putheader("deleteall","True")
conn.endheaders()


response = conn.getresponse()
print '------status--------'
print response.status
print '------resaon--------'
print response.reason
print '----- read -------'
ret= response.read()
print ret
retd= json.loads(ret)
print retd
#print response.headers


