keystoneIP='10.90.0.53'
import commands
def getTokenTid(user, password):
    global keystoneIP
    s ="""curl -X POST -v -H 'Content-Type: application/json' %s:35357/v3/auth/tokens -d '{"auth":{"identity":{"methods":["password"],"password":
        {"user":{"domain":{"name":"cs.promise.com.tw"},"name":"%s","password":"%s"}}},"scope":{"project":{"domain":{"name":"cs.promise.com.tw"},"name":"%s"}}}}'"""%(keystoneIP, user,password,user)
    #print s
    strr = commands.getoutput(s)
    print strr
    ss= strr.split('left intact')
#print ss.get('project')
#print '---------------'
#print ss[0]
    #print '------------------------------------'
    token =  ss[0].split('X-Subject-Token:')[1].split()[0]
    print 'show token ---------------',token
    #t_idtmp= ss[1].split('*')[0].strip()
    #t_id =  json.loads(t_idtmp)['token']['project']['id']
    return token

print getTokenTid('Adam.Woolley','Password1')
