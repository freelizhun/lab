import httplib
import sys
import mimetypes
import os
import json
#CHUNKSIZE = 65563  
CHUNKSIZE = 4096
#CHUNKSIZE = 6
url="http://127.0.0.1:7000/"
conn = httplib.HTTPConnection("127.0.0.1", 7000)
conn.putrequest("POST", "/v1/files/zero3.txt?overwrite=true&parent_rev=notyet")
conn.putheader("Content-Type", "application/json")
conn.putheader("Transfer-Encoding", "chunked")
conn.putheader("X-META-FC-COMPRESS","false")
conn.putheader("X-META-FC-ENCRYPT","true")
conn.endheaders()
 
f='/root/zero.txt'
with open(f, 'r') as fp:
     chunk = fp.read(CHUNKSIZE)
     #print chunk
     while chunk:
         conn.send('%x\r\n%s\r\n' % (len(chunk), chunk))
         chunk = fp.read(CHUNKSIZE)
     conn.send('0\r\n\r\n')
response = conn.getresponse()
print '------status--------'
print response.status
print '------resaon--------'
print response.reason
print '----- read -------'
ret= response.read()
print ret
retd= json.loads(ret)
print retd


