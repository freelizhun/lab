import httplib, urllib
import json

conn = httplib.HTTPConnection("localhost:7000")
conn.putrequest("GET", "/v1/search?query=testmedium30.txt")
conn.putheader("Content-Type", "application/json")
conn.putheader("X-AUTH-Token","cb2ec341ecf5447aad70c3d0659f2c39")
conn.endheaders()
response = conn.getresponse()
print response.status, response.reason

print '------status--------'
print response.status
print '------resaon--------'
print response.reason
ret= response.read()
retd= json.loads(ret)
print retd

