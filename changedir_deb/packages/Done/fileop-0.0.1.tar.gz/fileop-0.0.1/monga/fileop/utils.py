import commands
def getQueryStringDict(req):
    def parseQString():
        qs1=QS.split('&')
        for i in qs1:
            (a,b)=i.split('=')
            yield a,b
    QS = req.environ.get('QUERY_STRING')
    print QS
    if not QS:
        return {}
    retDict={}
    for i,j in parseQString():
        retDict[i]=j
    return retDict
def getFileSize(fp):
    return int( commands.getoutput('ls -al %s'%fp).split()[4])



def static_var(varname, value):
    def decorate(func):
        setattr(func, varname, value)
        return func
    return decorate

