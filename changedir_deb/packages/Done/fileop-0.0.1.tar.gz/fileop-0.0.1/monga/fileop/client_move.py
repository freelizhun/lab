import httplib
import sys
import mimetypes
import os
import json
import urllib
url="http://127.0.0.1:7000/"
conn = httplib.HTTPConnection("127.0.0.1", 7000)
conn.request('POST', '/v1/fileops/move?root=tenant_id&from_path=size.txt&to_path=sizemove.txt') 
response = conn.getresponse()
print '------status--------'
print response.status
print '------resaon--------'
print response.reason
print '----- read -------'
#ret= response.read()
#print ret
#retd= json.loads(ret)
#print retd
#print response.headers


