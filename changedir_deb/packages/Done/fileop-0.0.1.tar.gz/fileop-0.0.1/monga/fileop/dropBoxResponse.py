import time


def _getModifyTime():
    return time.strftime("%a, %d %b %Y %H:%M:%S %z")

def _getPath(req):
    return req.environ.get('HTTP_FILEPATH')

def _getMimeType(req):
    return req.environ.get('CONTENT_TYPE')

#def upload(size, req):
def commit(doc):
    #print doc
    metainfo = doc.pop('manifest')
    return doc
    
def upload(doc):
    metainfo = doc.pop('manifest')
    #metainfo = _filterBinary(doc)
    return metainfo
    """
    ret = {}
    ret['size']=str(int(size)/1024)+'KB'
    ret['thumb_exists']='false'
    ret['bytes']=size
    ret['modified']=_getModifyTime()
    ret['path']=_getPath(req)
    ret['id_dir']='false'
    ret['icon']='None'
    ret['root']='Tennant Name' 
    ret['mime_type']=_getMimeType(req)
    ret['revision']='None'
    return ret
    """

def download(size, req, filemeta):
    ret = {}
    ret['size']=str(int(filemeta.get('bytes')   )/1024)+'KB'
    ret['thumb_exists']=filemeta.get('thumb_exists')
    ret['bytes']=filemeta.get('bytes')
    ret['modified']= filemeta.get('modified')
    ret['path']=filemeta.get('path')
    ret['is_dir']=filemeta.get('is_dir')
    ret['icon']=filemeta.get('icon')
    ret['root']=filemeta.get('root')
    ret['mime_type']=_getMimeType(req)
    ret['revision']=filemeta.get('rev')
    ret['mtime']=filemeta.get('mtime')
    return ret

def createFolder(ret):
    #ret = {}
    return ret
    """
    ret = {
    "size": "0 bytes",
    "rev": "no used",
    "thumb_exists": "false",
    "bytes": 0,
    "modified":_getModifyTime(),
    "path":_getPath(req),
    "is_dir": "true",
    "icon": "folder",
    "root": "Tenant Name",
    "revision": "no used" 
    }
    return ret
    """

def _filterBinary(metainfo):
    #print metainfo
    if metainfo.get('is_dir'):
        data = metainfo.get('contents')
        if data != None:
            for aa in metainfo['contents']:
                if not aa['is_dir']:
                    aa.pop('manifest')
        else:
            return metainfo
    else:
        metainfo.pop('manifest')
        return metainfo

    return metainfo

def metaData(doc):
    metainfo = _filterBinary(doc)
    #print 'get metadata------------'
    #print metainfo
    return metainfo
def revisions(doc):
    ret1=[]                   
    for i in doc:            
        i.pop('manifest')   
        ret1.append(i)     
    #print 'revision pop'  
    return ret1       
    #return doc
def move(doc):
    ret = _filterBinary(doc)
    return ret
def delete(doc):
    #print doc
    ret = _filterBinary(doc)
    return ret

def search(docs):
    for doc in docs:
        if doc.get('manifest'):
            doc.pop('manifest')
    #searchRes = _filterBinary(doc)
    #return searchRes
    return docs
def restore(docs):
    """
    for doc in docs:
        if doc.get('manifest'):
            doc.pop('manifest')
    """
    doc = _filterBinary(docs)
    return docs



