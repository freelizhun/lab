import httplib, urllib
import json
params = urllib.urlencode({'spam': 1, 'eggs': 2, 'bacon': 0})
#headers = {"Content-type": "application/x-www-form-urlencoded",
#        "Accept": "text/plain","X-Auth-Token":"ab18d9bade5b4267a3061f31fed5d44d"}
#url = 'http://localhost:8090/search?q=haha&aq=f'

conn = httplib.HTTPSConnection("localhost:443")
conn.putrequest("GET", "/v1/files/test20")

token="727055163b794dd5b864ff69b3d56701"
conn.putheader("X-Auth-Token","%s"%token)
conn.endheaders()

response = conn.getresponse()
print response.status, response.reason


#print data
#conn.close()
f = open('/tmp/data20.txt',"wb")
chunksize = 4096
#data = response.read(chunksize)
data = response.read(chunksize)
while data:
    f.write(data)
    data = response.read(chunksize)
f.close()
conn.close()

print '------status--------'
print response.status
print '------resaon--------'
print response.reason
print '----- read -------'
print response.getheader('x-dropbox-metadata')
#et= response.read()
#print ret
#retd= json.loads(ret)
#print retd

