import httplib
import sys
import mimetypes
import os
import json
from monga.fileop import utils
import sys
CHUNKSIZE = 4096
checkstatus = '200'
loop = 0
loopfin = 10
upload_id = sys.argv[1]
offset = str(0)
url="http://127.0.0.1:7000/"
conn = httplib.HTTPConnection("127.0.0.1", 7000)
conn.putrequest("POST", "/v1/commit_chunked_upload/chunkupload.txt?upload_id=%s"%upload_id)
conn.putheader("Content-Type", "application/json")
conn.putheader("X-AUTH-Token","165196cc37b74dd6bf78d707b87f9b1b")
#conn.putheader("X--Token","165196cc37b74dd6bf78d707b87f9b1b")
conn.endheaders()
response = conn.getresponse()
print '------status--------'
print response.status
print '------resaon--------'
print response.reason
ret= response.read()
print ret
retd= json.loads(ret)
print 'ret data ------------'
print retd


