from random import random
from time import time
from eventlet import sleep, Timeout
from swift.common.daemon import Daemon
from swift.common.utils import get_logger
from paste.deploy import loadapp, appconfig
from monga.connector.utils import execute
from monga.connector.utils import read_metadata
from monga.connector.path import MongaSystemPath as SPath
from monga.common.exception import StorageError
from monga.connector.exception import ProcessExecutionError
#from monga.connector.lockfile import *
from monga.connector.lockfile import LockFile 
#import monga.connector.lockfile.FileLock
#from monga.connector.lockfile.mkdirlockfile import MkdirLockFile
import os
import shutil

try:
    import simplejson as json
except ImportError:
    import json
    
class ChunkCleaner(Daemon):
    def __init__(self, conf):
        self.conf = conf
        self.logger = get_logger(conf, log_route = 'Chunk-Cleaner')
        self.interval = int(conf.get('interval') or 10)
        self._access_point = conf.get(
                'storage_access_point', '/opt/monga')
        self.logger.debug('Start')
        self.logger.debug('Access Point: {0}'.\
                            format(self._access_point))
        self._access_path = SPath.path_to_ts(self._access_point)
        self._execute = execute
                               
    def run_once(self, *args, **kwargs):
        if not os.path.exists(self._access_path):
            self.logger.debug('TOMBSTONE is not created yet!')
            return
        delete_dir_list = []
        delete_file_list = []
        for dp, dn, fn in os.walk(self._access_path):
            if dn.__len__() > 0 :
                for d in dn:
                    delete_dir_list.append(os.path.join(dp, d))
            for f in fn:
                path = os.path.join(dp, f)
                delete_file_list.append(path)
                try:
                    with open(path, 'r') as fd:
                        meta = read_metadata(fd)
                except Exception as e:
                    self.logger.debug(
                        'Unable to read metadata : {0}'.format(path))
                    raise StorageError(e)
                if not 'manifest' in meta :
                    continue
                for chunk_id in meta['manifest']:
                    self.logger.debug('CHUNK ID: {0}'.format(chunk_id))
                    path_to_chunk = SPath.path_to_chunk(
                                self._access_point, chunk_id)
                    self.logger.debug('PATH TO CHUNK: {0}'.format(
                                        path_to_chunk))
                    path_to_count = SPath.path_to_chunk_count(
                                self._access_point, chunk_id)
                    self.logger.debug('PATH TO CHUNK COUNT: {0}'.format(
                                path_to_count))
                    lock_count = LockFile(path_to_count, timeout=3)
                    try:
                        lock_count.acquire()
                        self._decrease_binary_usage(path_to_count)
                        if int(self._get_binary_usage(path_to_count)) == 0:
                            self.logger.debug(
                                'Delete Chunk : {0}'.format(path_to_chunk))
                            self._delete_file(path_to_chunk)
                            self._delete_file(path_to_count)
                        lock_count.release()
                    except (LockTimeout, AlreadyLocked, LockFailed):
                        self.logger.debug('Unable to acquire lock for {0}'.\
                                            format(path_to_count))
                        continue
                    except (NotLocked, NotMyLock, UnlockError):
                        self.logger.debug('Unable to release lock for {0}'.\
                                            format(path_to_count))
                        continue
                         

        for fn in delete_file_list:
            self._delete_file(fn)

        for dn in delete_dir_list:
            if os.path.exists(dn):
                self._delete_folder(dn)

    def run_forever(self, *args, **kwargs):
        sleep(random() * self.interval)
        while True:
            begin = time()
            try:
                self.run_once()
            except (Exception, Timeout):
                self.logger.exception(_('Unhandled exception'))
            elapsed = time() - begin
            if elapsed < self.interval:
                sleep(random() * (self.interval - elapsed))

    def _delete_file(self, path):
        os.remove(path)

    def _delete_folder(self, path):
        shutil.rmtree(path)

    def _get_binary_usage(self, path):
        '''
        Get Binary usage
        Return usage as an INT
        :param chunk_id : Chunk ID
        '''
        #driver._execute('wc','-l',
        #    '/opt/monga/binary/221387a915a2b606e54907ed8ecec348.count')
        #('15 /opt/monga/binary/221387a915a2b606e54907ed8ecec348.count\n', '')
        #driver._execute('wc','-l',
        #    '/opt/monga/binary/221387a915a2b606e54907ed8ecec348.count')[0].split()[0]
        #Out[72]: '15'
        try:
            return self._execute(self.logger, 'wc','-l',path)[0].split()[0]
        except ProcessExecutionError as exc:
            raise StorageError(exc.stderr)
        except Exception as e:
            raise StorageError(e)

    def _decrease_binary_usage(self, path):
        self.logger.debug('Decrease Chunk Count : {0}'.format(path))
        try:
            self._execute(self.logger, u'sed', u'-i', u'$d', 
                    path)
        except ProcessExecutionError as exc:
            raise StorageError(exc.stderr)
        except Exception as e:
            raise StorageError(e)
