from random import random
from time import time
from eventlet import sleep, Timeout
from swift.common.daemon import Daemon
from swift.common.utils import get_logger
from paste.deploy import loadapp, appconfig
from monga.connector.utils import execute
from monga.connector.utils import read_metadata
from monga.connector.path import MongaSystemPath as SPath
from monga.connector.path import MongaTenantPath as TPath
from monga.connector.path import MONGA_SYSTEM_LIBS as sLib
from monga.common.exception import StorageError
from monga.connector.exception import ProcessExecutionError
import os
import shutil

try:
    import simplejson as json
except ImportError:
    import json
    
class VersionCleaner(Daemon):
    def __init__(self, conf):
        self.conf = conf
        self.logger = get_logger(conf, log_route = 'Version-Cleaner')
        self.interval = int(conf.get('interval') or 60)
        self._access_point = conf.get(
                'storage_access_point', '/opt/monga')
        self._max_number = int(conf.get(
                'max_number', 5))
        self.logger.debug('Start')
        self.logger.debug('Access Point: {0}'.\
                            format(self._access_point))
        self.logger.debug('Max # of Version: {0}'.\
                            format(self._max_number))
        self._execute = execute
                               
    def run_once(self, *args, **kwargs):
        self.logger.debug('Start')
        working_list = []
        tenants = [ t for t in os.listdir('/opt/monga') \
                        if t not in sLib.values()]
        for tenant in tenants:
            path_to_ver = TPath.path_to_version_folder(
                self._access_point, tenant)
            for dp, dn, fn in os.walk(path_to_ver):
                if fn.__len__() > self._max_number:
                    working_list.append(dp)
        for d in working_list :
            for v in self._get_list_sorted_by_mtime(d)[self._max_number:]:
                p = os.path.join(d,v)
                self._move_to_ts(p)
                
    def run_forever(self, *args, **kwargs):
        sleep(random() * self.interval)
        while True:
            begin = time()
            try:
                self.run_once()
            except (Exception, Timeout):
                self.logger.exception(_('Unhandled exception'))
            elapsed = time() - begin
            if elapsed < self.interval:
                sleep(random() * (self.interval - elapsed))

    def _move_to_ts(self, src):
        # Move ver file to tombstone
        self.logger.debug('Move {0} to Tombstone'.format(src))
        path_to_ts = SPath.path_to_ts(self._access_point)
        if not os.path.exists(path_to_ts):
            os.mkdir(path_to_ts)
        dest = os.path.join(path_to_ts, os.path.basename(src))
        while os.path.exists(dest):
            dest = os.path.join(path_to_ts, utils.get_uuid4())
        shutil.move(src, dest)

    def _get_list_sorted_by_mtime(self, path):
        '''
        List a folder and sorted by modified time
        [NEW -> OLD]
        Return a list
        '''
        try:
            mtime = lambda f: os.stat(os.path.join(path, f)).st_mtime
            return list(sorted(os.listdir(path), key=mtime, reverse=True))
        except Exception as e:
            self._logger.debug(_('Unable to list : ${0}'.format(path)))
            self._logger.debug(_('Exception : ${0}'.format(e)))
            raise StorageError(e)

    def _delete_file(self, path):
        os.remove(path)
