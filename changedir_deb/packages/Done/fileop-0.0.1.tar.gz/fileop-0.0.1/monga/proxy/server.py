from __future__ import with_statement
try:
    import simplejson as json
except ImportError:
    import json
import mimetypes
import os
import re
import time
import traceback
from ConfigParser import ConfigParser
from datetime import datetime
from urllib import unquote, quote
import uuid
import functools
from hashlib import md5
from random import shuffle
from eventlet import sleep, spawn_n, GreenPile, Timeout
from eventlet.queue import Queue, Empty, Full
from eventlet.timeout import Timeout
from swift.common.swob import HTTPAccepted, HTTPBadRequest, HTTPForbidden, \
    HTTPMethodNotAllowed, HTTPNotFound, HTTPPreconditionFailed, \
    HTTPRequestEntityTooLarge, HTTPRequestTimeout, HTTPServerError, \
    HTTPServiceUnavailable, status_map
from webob import Request, Response
from swift.common.utils import cache_from_env, ContextPool, get_logger, \
    get_remote_client, normalize_timestamp, split_path, TRUE_VALUES, public
from swift.common.bufferedhttp import http_connect
from swift.common.constraints import check_metadata, check_object_creation, \
    check_utf8, CONTAINER_LISTING_LIMIT, MAX_ACCOUNT_NAME_LENGTH, \
    MAX_CONTAINER_NAME_LENGTH, MAX_FILE_SIZE
from swift.common.exceptions import ChunkReadTimeout, \
    ChunkWriteTimeout, ConnectionTimeout, ListingIterNotFound, \
    ListingIterNotAuthorized, ListingIterError
from monga.controller.files import FileController
from monga.controller.account import AccountController
from monga.controller.meta import MetaController
from monga.controller.delta import DeltaController
from monga.controller.revision import RevisionController
from monga.controller.restore import RestoreController
from monga.controller.search import SearchController
from monga.controller.share import ShareController
from monga.controller.chunk_upload import ChunkUploadController
from monga.controller.commit_chunk_upload import CommitChunkUploadController
from monga.controller.copy import FileCopyController
from monga.controller.create_folder import FileCreateFolderController
from monga.controller.delete import FileDeleteController
from monga.controller.lock import LockController
from monga.controller.move import FileMoveController
from monga.controller.trash import TrashController
from monga.controller.event import EventController
from monga.controller.cursor import CursorController
from monga.controller.share_file import ShareFileController
from monga.controller.comment import CommentController
from routes import Mapper

def update_headers(response, headers):
    if hasattr(headers, 'items'):
        headers = headers.items()
    for name, value in headers:
        if name == 'etag':
            response.headers[name] = value.replace('"', '')
        elif name not in ('date', 'content-length', 'content-type',
                          'connection', 'x-put-timestamp', 
                          'x-delete-after'):
            response.headers[name] = value
            
def get_user_info(env):
    return {
        'user_id'     : env.get('HTTP_X_USER_ID', ''),
        'user_name'   : env.get('HTTP_X_USER_NAME', ''),
        'tenant_id'   : env.get('HTTP_X_TENANT_ID', ''),
        'tenant_name' : env.get('HTTP_X_TENANT_NAME', ''),
        'domain_id'   : env.get('HTTP_X_USER_DOMAIN_ID', ''),
        'domain_name' : env.get('HTTP_X_USER_DOMAIN_NAME', ''),
        'client_ip'   : env.get('REMOTE_ADDR', ''),
        'device_name' : env.get('HTTP_USER_AGENT', ''),
        'user_roles'  : env.get('HTTP_X_ROLE','').split(','),
        'user_token'  : env.get('HTTP_X_AUTH_TOKEN', ''),
        'quota'       : env.get('HTTP_X_TENANT_QUOTA', 5368709120)
    }         

def delay_denial(func):
    func.delay_denial = True
    @functools.wraps(func)
    def wrapped(*a, **kw):
        return func(*a, **kw)
    return wrapped

class BaseApplication(object):
    special_vars = ['controller','action']

    def __init__(self, conf, memcache=None, logger=None, account_ring=None,
                 container_ring=None, object_ring=None):
        if conf is None:
            conf = {}
        if logger is None:
            self.logger = get_logger(conf, log_route='monga')
            access_log_conf = {}
            for key in ('log_facility', 'log_name', 'log_level',
                        'log_udp_host', 'log_udp_port'):
                value = conf.get('access_' + key, conf.get(key, None))
                if value:
                    access_log_conf[key] = value
            self.access_logger = get_logger(access_log_conf,
                                            log_route='monga-access')
        else:
            self.logger = self.access_logger = logger

        self.conf = conf
        self.server_addr =  conf.get('server_addr', 
                                 'http://localhost:7000')        
        self.mongo_path = conf.get('mongo_path', 'localhost')
        self.mongo_port = int(conf.get('mongo_port', 27017))
        self.mongo_db_name = conf.get('mongo_db_name', 'monga')
        self.default_tenant = conf.get('default_tenant','')
        self.node_timeout = int(conf.get('node_timeout', 10))
        self.conn_timeout = float(conf.get('conn_timeout', 0.5))
        self.client_timeout = int(conf.get('client_timeout', 60))
        self.default_quota = int(conf.get('default_quota', 5368709120))
        self.admin_token = conf.get('auth_admin_token', 'ADMIN')
        self.admin_name = conf.get('admin_name', 'admin')
        self.admin_password = conf.get('admin_password', 'admin')
        self.admin_tenant_name = conf.get('admin_tenant_name', 'admin')
        self.admin_domain_name = conf.get('admin_domain_name', 'Default')
        self.auth_url = conf.get('auth_url', 'http://localhost:35357/v3/')
        self.log_headers = conf.get('log_headers', 'no').lower() in TRUE_VALUES
        self.memcache = memcache
        self.mapper = Mapper()
        self.mapper.connect('/v1/account/info',
                            controller = AccountController,
                            conditions = dict(method=['GET']))
        self.mapper.connect('/v1/files/*path',
                            controller = FileController,
                            conditions = dict(method=['GET', 'POST']))
        self.mapper.connect('/v1/files_put/*path',
                            controller = FileController,
                            conditions = dict(method=['PUT']))
        self.mapper.connect('/v1/metadata',
                            controller = MetaController,
                            conditions = dict(method=['GET']))
        self.mapper.connect('/v1/metadata/',
                            controller = MetaController,
                            conditions = dict(method=['GET']))
        self.mapper.connect('/v1/metadata/*path',
                            controller = MetaController,
                            conditions = dict(method=['GET']))
        self.mapper.connect('/v1/delta',
                            controller = DeltaController,
                            conditions = dict(method=['POST']))
        self.mapper.connect('/v1/revisions/*path',
                            controller = RevisionController,
                            conditions = dict(method=['GET']))
        self.mapper.connect('/v1/restore/*path',
                            controller = RestoreController,
                            conditions = dict(method=['POST']))
        self.mapper.connect('/v1/search/*path',
                            controller = SearchController,
                            conditions = dict(method=['GET', 'POST']))
        self.mapper.connect('/v1/search',
                            controller = SearchController,
                            conditions = dict(method=['GET', 'POST']))
        self.mapper.connect('/v1/shares/*path',
                            controller = ShareController,
                            conditions = dict(method=['POST']))
        self.mapper.connect('/v1/shares',
                            controller = ShareController,
                            conditions = dict(method=['GET']))
        self.mapper.connect('/v1/shares/*_id',
                            controller = ShareController,
                            conditions = dict(method=['DELETE', 'PUT']))
        #Pass copy_ref, thumbnails
        self.mapper.connect('/v1/chunked_upload',
                            controller = ChunkUploadController,
                            conditions = dict(method=['POST']))
        self.mapper.connect('/v1/commit_chunked_upload/*path',
                            controller = CommitChunkUploadController,
                            conditions = dict(method=['POST']))
        self.mapper.connect('/v1/fileops/copy',
                            controller = FileCopyController,
                            conditions = dict(method=['POST']))
        self.mapper.connect('/v1/fileops/create_folder',
                            controller = FileCreateFolderController,
                            conditions = dict(method=['POST']))
        self.mapper.connect('/v1/fileops/delete',
                            controller = FileDeleteController,
                            conditions = dict(method=['POST']))
        self.mapper.connect('/v1/fileops/move',
                            controller = FileMoveController,
                            conditions = dict(method=['POST']))
        self.mapper.connect('/v1/fileops/share_file',
                            controller = ShareFileController,
                            conditions = dict(method=['POST', 'GET']))
        self.mapper.connect('/v1/fileops/share_file/*_id',
                            controller = ShareFileController,
                            conditions = dict(method=['DELETE']))
        self.mapper.connect('/v1/fileops/trash',
                            controller = TrashController,
                            conditions = dict(method=['GET']))
        self.mapper.connect('/v1/fileops/trash/*path',
                            controller = TrashController,
                            conditions = dict(method=['POST']))
        self.mapper.connect('/v1/fileops/trash/*_id',
                            controller = TrashController,
                            conditions = dict(method=['PUT', 'DELETE']))
        self.mapper.connect('/v1/fileops/comment/*path',
                            controller = CommentController,
                            conditions = dict(method=['POST', 'GET']))
        self.mapper.connect('/v1/lock/*path',
                            controller = LockController,
                            conditions = dict(method=['POST', 'DELETE']))
        self.mapper.connect('/v1/cursor',
                            controller = CursorController,
                            conditions = dict(method=['GET']))
        self.mapper.connect('/v1/events',
                            controller = EventController,
                            conditions = dict(method=['GET']))

    def __call__(self, env, start_response):
        try:
            if self.memcache is None:
                self.memcache = cache_from_env(env)
            req = Request(env)
            return self.handle_request(req)(env, start_response)
        except UnicodeError:
            err = HTTPPreconditionFailed(request=req, body='Invalid UTF8')
            return err(env, start_response)
        except (Exception, Timeout):
            start_response('500 Server Error',
                    [('Content-Type', 'text/plain')])
            return ['Internal server error.\n']

    def handle_request(self, req):
        try:
            #self.logger.set_statsd_prefix('proxy-server')
            if req.content_length and req.content_length < 0:
                self.logger.increment('errors')
                return HTTPBadRequest(request=req,
                                      body='Invalid Content-Length')
            try:
                if not check_utf8(req.path_info):
                    self.logger.increment('errors')
                    return HTTPPreconditionFailed(request=req,
                                                  body='Invalid UTF8')
            except UnicodeError:
                self.logger.increment('errors')
                return HTTPPreconditionFailed(request=req, 
                                              body='Invalid UTF8')
            results = self.mapper.routematch(environ=req.environ)
            if not results:
                return HTTPNotFound(request=req, body='url not found')
            match, route = results
            controller = match['controller'](self)
            try:
                handler = getattr(controller, req.method)
                getattr(handler, 'publicly_accessible')
            except AttributeError:
                self.logger.increment('method_not_allowed')
                return HTTPMethodNotAllowed(request=req)
            kwargs = match.copy()
            for attr in self.special_vars:
                if attr in kwargs:
                    del kwargs[attr]
            #Get user info
            context = get_user_info(req.environ)
            return handler(context, req, **kwargs)
        except (Exception, Timeout):
            self.logger.exception(_('ERROR Unhandled exception in request'))
            return HTTPServerError(request=req)

class Application(BaseApplication):
    def handle_request(self, req):
        req.start_time = time.time()
        req.response = super(Application, self).handle_request(req)
        return req.response

def app_factory(global_conf, **local_conf):
    """paste.deploy app factory for creating WSGI proxy apps."""
    conf = global_conf.copy()
    conf.update(local_conf)
    return Application(conf)
