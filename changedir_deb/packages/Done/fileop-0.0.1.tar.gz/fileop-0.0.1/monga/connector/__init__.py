# vim: tabstop=4 shiftwidth=4 softtabstop=4
# -*- coding: UTF-8 -*-
import sys
import traceback
from monga.common.exception import StorageError

DRIVER_MAP = {
    'local':'monga.connector.drivers.local.LocalDriver',
    'nas':'monga.connector.drivers.nas.NASDriver'
}

def import_class(import_str):
    """Returns a class from a string including module and class"""
    mod_str, _sep, class_str = import_str.rpartition('.')
    try:
        __import__(mod_str)
        return getattr(sys.modules[mod_str], class_str)
    except (ValueError, AttributeError):
        raise ImportError('Class %s cannot be found (%s)' %
                          (class_str,
                           traceback.format_exception(*sys.exc_info())))

def get_connector(logger, conf={}):
    conn_type = conf.get('storage_type','local')
    # UNKOWN TYPE will raise KeyError
    try :
        return  import_class(DRIVER_MAP[conn_type])(conf, logger)
    except Exception as e: 
        raise StorageError(e)

