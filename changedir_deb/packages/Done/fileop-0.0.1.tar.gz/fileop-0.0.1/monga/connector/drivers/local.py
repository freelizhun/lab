# vim: tabstop=4 shiftwidth=4 softtabstop=4
# -*- coding: UTF-8 -*-
import os
import subprocess
from eventlet import greenthread
import sys
import gettext
import signal
import random
import cPickle as pickle
import uuid
import datetime
import hashlib
from monga.connector.base import FileBackendBaseDriver
from monga.connector.exception import ProcessExecutionError
from monga.common.exception import InvalidParameter

gettext.install('connector', unicode=1)


class LocalDriver(FileBackendBaseDriver):
    def __init__(self, conf, logger):
        if not logger :
            raise InvalidParameter('LocalDriver')

        FileBackendBaseDriver.__init__(self, conf, logger)
        self._do_setup()

    def _do_setup(self):
        """Any initialization the backend storage does while starting"""
        self._init_system_folder()
    
    def __str__(self):
        return '{0} Connector for MONGA SYSTEM'.format(self.__name__)
