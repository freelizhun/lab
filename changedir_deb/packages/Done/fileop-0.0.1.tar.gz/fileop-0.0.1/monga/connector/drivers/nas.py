# vim: tabstop=4 shiftwidth=4 softtabstop=4
# -*- coding: UTF-8 -*-
import os
import subprocess
from eventlet import greenthread
import sys
import gettext
import signal
import random
import cPickle as pickle
import uuid
import datetime
import hashlib
from monga.connector.exception import ProcessExecutionError
from monga.connector.base import FileBackendBaseDriver
from monga.common.exception import InvalidParameter

gettext.install('connector', unicode=1)

class NasDriver(FileBackendBaseDriver):
    def __init__(self, conf, logger):
        #self._logger = logger
        #conf = utils.readconf(conf_path)['backend']
        #conf = {}
        if not conf or not logger:
             raise InvalidParameter

        self._nfs_mount_options = conf.get('nfs_mount_options',None)
        self._mount_path = conf.get('mount_path','/tmp/monga')
        #TODO: share_path is required for mount NFS
        self._share_path = conf.get('share_path', '127.0.0.1:/media/nfs/share')
        FileBackendBaseDriver.__init__(self, conf, logger)

    def _do_setup(self):
        """Any initialization the backend storage does while starting"""
        #TODO : call system exit if user did not define this section
        if not os.path.ismount(self._mount_path):
            self._mount_nfs()
        self._init_system_folder()

    def _mount_nfs(self):
        """Mount NFS storage
        access_point : system will access nfs from here.
                        It's a soft link to a folder, 
                        created at first time, in NFS.
                        User need to define it in CONF file.
        mount_point  : NFS will be mounted here.
                        Default : /tmp/monga/nfs
        
        The reason seperate them is due to the fact that
        network connection may be broken in the middle.
        """

        if not self._path_exists(self._mount_path):
            self._execute('mkdir', '-p', self._mount_path)

        # Construct the NFS mount command.
        nfs_cmd = ['mount', '-t', 'nfs']
        if self._nfs_mount_options is not None:
            nfs_cmd.extend(
                ['-o', self._nfs_mount_options])
        
        nfs_cmd.extend([self._share_path ,self._mount_path])

        try:
            self._execute(*nfs_cmd, attempts=3, run_as_root=True)
        except ProcessExecutionError as exc:
            if 'already mounted' in exc.stderr:
                self._logger.warn(_("%s is already mounted"), self._mount_path)
            else:
                raise
