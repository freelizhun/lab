#!/usr/bin/env python
# vim: tabstop=4 shiftwidth=4 softtabstop=4
# -*- coding: UTF-8 -*-
import hashlib
import datetime
import subprocess
from eventlet import greenthread
import sys
import gettext
import signal
import os
import simplejson as json
import cPickle as pickle
import time
import functools
from monga.connector.exception import ProcessExecutionError
from monga.common.exception import StorageError
import uuid
import random
DATETIME_FMT = '%a, %d %b %Y %H:%M:%S %z'
gettext.install('connector', unicode=1)

def write_data(data, fd):
    fd.write(data)
    os.fdatasync(fd)

def write_metadata(meta, fd):
    #json.dump(meta,fd)
    pickle.dump(meta, fd)
    os.fdatasync(fd)


def read_metadata(fd):
    attempts = 3
    while attempts > 0:
        attempts -= 1
        try :
            #return json.load(fd)
            return pickle.load(fd)
        except:
            greenthread.sleep(random.randint(20, 200) / 1000.0)
    raise StorageError
    #return json.load(fd)
    #return pickle.load(fd)

def get_md5(content):
    m = hashlib.md5()
    m.update(content)
    return m.hexdigest()

def get_datetime():
    return '{0}{1}'.format( 
            datetime.datetime.utcnow().strftime(
            DATETIME_FMT), '+0000'
    )

def get_timestamp():
    return datetime.datetime.utcnow().strftime("%s")

def get_uuid():
    return uuid.uuid4().__str__()

def get_mtime(path):
    return '{0}{1}'.format(
        datetime.datetime.fromtimestamp(
            os.path.getmtime(path)).strftime(DATETIME_FMT), 
            '+0000')

def get_ctime(path):
    return '{0}{1}'.format(
        datetime.datetime.fromtimestamp(
            os.path.getctime(path)).strftime(DATETIME_FMT), 
            '+0000')

def human_readable_size(num):
    num /= 1024.0
    for x in [ 'KB', 'MB', 'GB', 'TB']:
        if num < 1024.0:
            return "%3.3f %s" % (num, x)
        num /= 1024.0
    return "%3.1f %s" % (num, 'TB')

def create_folder_metadata(path,rpath):
    """Create Folder Metadata
        "size": "0 bytes",
        "hash": "37eb1ba1849d4b0fb0b28caf7ef3af52", <- md5(mtime)
        "bytes": 0,
        "thumb_exists": false,
        "rev": "714f029684fe", <- md5(ctime)
        "modified": "Wed, 27 Apr 2011 22:18:51 +0000",
        "path": "/Public",
        "is_dir": true,
        "icon": "folder_public",
        "root": "dropbox",
    """
    mtime = get_mtime(path)
    return {
        "size" : "0 Bytes",
        "hash" : get_md5(mtime),
        "bytes" : 0,
        "thumb_exists": False,
        "rev": get_md5(mtime),
        "modified" : mtime,
        "path" : rpath,
    	"is_dir": True,
        "icon" : "folder_public",
        "root" : "File Cruiser"
    }

def create_file_metadata(
        save_path, temp_meta, temp_uuid, file_size, 
        store_size, mtime, compress, encrypt):
    """Creates a file's metadata.
    {
        "size": "225.4KB",
        "store_size": "225.4KB",
        "rev": "35e97029684fe",
        "thumb_exists": false,
        "bytes": 230783,
        "store_bytes": 230783,
        "modified": "Tue, 19 Jul 2011 21:55:38 +0000",
        "path": "/Getting_Started.pdf",
        "is_dir": false,
        "icon": "page_white_acrobat",
        "root": "dropbox",
        "manifest":[
            adfjilljn <-- MD5 for first chunk
            ,fjdkjaijj <-- MD5 for second chunk
            ,klsdfdwee <-- MD5 for third chunk
        ]},
    """
    temp_meta['size'] = human_readable_size(file_size)
    temp_meta['store_size'] = human_readable_size(store_size)
    temp_meta['rev'] = get_md5(temp_uuid)
    temp_meta['thumb_exists'] = False
    temp_meta['bytes'] = file_size
    temp_meta['store_bytes'] = store_size
    temp_meta['modified'] = get_datetime()
    temp_meta['is_dir'] = False
    temp_meta['icon'] = 'page_white_acrobat'
    temp_meta['root'] = 'File Cruiser'
    temp_meta['mtime'] = mtime or get_datetime()
    temp_meta['compress'] = compress
    temp_meta['encrypt'] = encrypt
    return temp_meta

def subprocess_setup():
    signal.signal(signal.SIGPIPE, signal.SIG_DFL)

def execute(logger,*cmd, **kwargs):
    """Helper method to execute command with optional retry.

    If you add a run_as_root=True command, don't forget to add the
    corresponding filter to etc/cinder/rootwrap.d !

    :param cmd:                Passed to subprocess.Popen.
    :param process_input:      Send to opened process.
    :param check_exit_code:    Single bool, int, or list of allowed exit
                               codes.  Defaults to [0].  Raise
                               exception.ProcessExecutionError unless
                               program exits with one of these code.
    :param delay_on_retry:     True | False. Defaults to True. If set to
                               True, wait a short amount of time
                               before retrying.
    :param attempts:           How many times to retry cmd.
    :param run_as_root:        True | False. Defaults to False. If set to True,
                               the command is prefixed by the command specified
                               in the root_helper FLAG.

    :raises exception.Error: on receiving unknown arguments
    :raises exception.ProcessExecutionError:

    :returns: a tuple, (stdout, stderr) from the spawned process, or None if
             the command fails.
    """

    process_input = kwargs.pop('process_input', None)
    check_exit_code = kwargs.pop('check_exit_code', [0])
    ignore_exit_code = False
    if isinstance(check_exit_code, bool):
        ignore_exit_code = not check_exit_code
        check_exit_code = [0]
    elif isinstance(check_exit_code, int):
        check_exit_code = [check_exit_code]
    delay_on_retry = kwargs.pop('delay_on_retry', True)
    attempts = kwargs.pop('attempts', 1)
    run_as_root = kwargs.pop('run_as_root', True)
    shell = kwargs.pop('shell', False)

    if len(kwargs):
        raise exception.Error(_('Got unknown keyword args '
                                'to utils.execute: %r') % kwargs)

    if run_as_root:
        cmd =['sudo'] + list(cmd)

    cmd = map(unicode, cmd)

    while attempts > 0:
        attempts -= 1
        try:
            logger.debug(_('Running cmd (subprocess): %s'), ' '.join(cmd))
            _PIPE = subprocess.PIPE  # pylint: disable=E1101
            obj = subprocess.Popen(cmd,
                       stdin=_PIPE,
                       stdout=_PIPE,
                       stderr=_PIPE,
                       close_fds=True,
                       preexec_fn=subprocess_setup,
                       shell=shell)
            result = None
            if process_input is not None:
                result = obj.communicate(process_input)
            else:
                result = obj.communicate()
            obj.stdin.close()  # pylint: disable=E1101
            _returncode = obj.returncode  # pylint: disable=E1101
            if _returncode:
                logger.debug(_('Result was %s') % _returncode)
                if not ignore_exit_code and _returncode not in check_exit_code:
                    (stdout, stderr) = result
                    raise ProcessExecutionError(
                        exit_code=_returncode,
                        stdout=stdout,
                        stderr=stderr,
                        cmd=' '.join(cmd))
            return result
        except ProcessExecutionError:
            if not attempts:
                raise
            else:
                logger.debug(_('%r failed. Retrying.'), cmd)
                if delay_on_retry:
                    greenthread.sleep(random.randint(20, 200) / 100.0)
        finally:
            greenthread.sleep(0)


def timefunc(logger, func):
    """Decorator that logs how long a particular function took to execute"""
    @functools.wraps(func)
    def inner(*args, **kwargs):
        start_time = time.time()
        try:
            return func(*args, **kwargs)
        finally:
            total_time = time.time() - start_time
            logger.debug(_("timefunc: '%(name)s' took %(total_time).2f secs") %
                      dict(name=func.__name__, total_time=total_time))
    return inner

