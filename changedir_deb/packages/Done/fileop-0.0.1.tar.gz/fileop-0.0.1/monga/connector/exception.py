#!/usr/bin/env python
# -*- coding: UTF-8 -*-

class ProcessExecutionError(IOError):
    def __init__(self, stdout=None, stderr=None, exit_code=None, cmd=None,
                 description=None):
        self.exit_code = exit_code
        self.stderr = stderr
        self.stdout = stdout
        self.cmd = cmd
        self.description = description

        if description is None:
            description = _('Unexpected error while running command.')
        if exit_code is None:
            exit_code = '-'
        message = _('%(description)s\nCommand: %(cmd)s\n'
                    'Exit code: %(exit_code)s\nStdout: %(stdout)r\n'
                    'Stderr: %(stderr)r') % locals()
        IOError.__init__(self, message)

class InvalidParameter(Exception):
    message = _("Invalid Parameter")


class FileNotFound(Exception):
    def __init__(self, path):
        message = '{0} not found.'.format(path)
        Exception.__init__(self, message)

class FileExists(Exception):
    def __init__(self, path):
        message = '{0} exists.'.format(path)
        Exception.__init__(self, message)
