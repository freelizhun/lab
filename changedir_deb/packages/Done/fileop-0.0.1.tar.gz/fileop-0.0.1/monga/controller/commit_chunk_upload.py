from monga.controller.base import Controller
from monga.common import response as RESP
from swift.common.utils import public
from monga.common import exception as exception
from monga.common.exception import *

class CommitChunkUploadController(Controller):
    server_type = _('CommitChunkUpload')

    def __init__(self, app, **kwargs):
        Controller.__init__(self, app)
        self.action = 'CommitChunkUpload'

    @public
    @exception.handle_exceptions()
    def POST(self, user_info, req, path):
    
        #check user role
        if not self.check_role(user_info['user_roles'], 'w'):
            raise ForbiddenError('Access denied')

        #decode the path
        path = self.decode_and_check_path(path)

        #Check shared folder
        _user, _path, is_share, is_team = \
            self.check_special_folder(user_info, path, 'write')
            
        #Get resp and chunk_id from fileop
        resp, chunk_id = self.fileop.commit_chunk_upload(_user, _path, req)
        
        #Modified resp body
        if is_share :
            resp.body = self.modfied_shared_contents(resp.body, user_info, path)
        elif is_team :
            # modified team folder contents
            team_path, junk, junk2 = self.get_team_path(path)
            resp.body = self.modfied_team_contents(resp.body, team_path)
            
        #Record Activty
        self.db.insert_log(self.modify_userinfo(user_info, _user ,is_team), 
                           self.action,
                           delta    = 'Create',
                           method   = 'POST',
                           to_path  = path,
                           result   = self.get_result(resp.status),
                           is_share = is_share,
                           is_team  = is_team,
                           is_chunk = True, 
                           chunk_id = chunk_id)
        return resp

