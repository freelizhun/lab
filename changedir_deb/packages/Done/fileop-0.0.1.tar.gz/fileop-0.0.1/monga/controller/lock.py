from monga.controller.base import Controller
from monga.common import response as RESP
from swift.common.utils import public
from monga.common import exception as exception
from monga.common.exception import *

class LockController(Controller):
    server_type = _('Lock')

    def __init__(self, app, **kwargs):
        Controller.__init__(self, app)
        self.action = 'LockFile'

    @public
    @exception.handle_exceptions()
    def POST(self, user_info, req, path):
    
        #check user role
        if not self.check_role(user_info['user_roles'], 'w'):
            raise ForbiddenError('Access denied')
            
        #Decode path
        path = self.decode_and_check_path(path)

        #Check shared folder
        _user, _path, is_share, is_team = \
            self.check_special_folder(user_info, path, 'write', True)
            
        #Change user_name, user_id
        _user['user_name'] = user_info['user_name']
        _user['user_id'] = user_info['user_id']
        
        #TODO check lock exist or not
        self.db.insert_lock(_user, _path)
        
        #Record Activty
        self.db.insert_log(user_info, 
                           self.action,
                           method   = 'POST',
                           to_path  = self.check_path(path),
                           result   = 1,
                           is_share = is_share,
                           is_team  = is_team,
                           notifier = True)
                           
        return RESP.created()
        
    @public
    @exception.handle_exceptions()
    def DELETE(self, user_info, req, path):
    
        #check user role
        if not self.check_role(user_info['user_roles'], 'w'):
            raise ForbiddenError('Access denied')
            
        #Decode path
        path = self.decode_and_check_path(path)

        #Check shared folder
        _user, _path, is_share, is_team = \
            self.check_special_folder(user_info, path, 'write', False)
            
        #Change user_name, user_id
        _user['user_name'] = user_info['user_name']
        _user['user_id'] = user_info['user_id']
        
        #Check lock exist or not
        if not self.db.find_user_lock(_user, _path) :
            raise BadRequestError('''This file wan\'t been locked''')
            
        #Delete lock
        self.db.delete_lock(_user, _path)
        
        #Record Activty
        self.db.insert_log(user_info, self.action,
                           method   = 'DELETE',
                           to_path  = self.check_path(path),
                           result   = 1,
                           is_share = is_share,
                           is_team  = is_team,
                           notifier = True)
                           
        return RESP.no_content()
