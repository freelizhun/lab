from monga.controller.base import Controller
from monga.common import response as RESP
from swift.common.utils import public
from monga.common import exception as exception
from monga.common.exception import *

class AccountController(Controller):
    server_type = _('Account')

    def __init__(self, app, **local_variables):
        Controller.__init__(self, app)

    @public
    def GET(self, req):
        """Handler for HTTP GET requests."""
        return RESP.ok()
