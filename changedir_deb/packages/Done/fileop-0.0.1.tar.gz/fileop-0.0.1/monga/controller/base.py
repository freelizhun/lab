from monga.common.backend.mongo import MongoDBConnector
from monga.fileop.FileOp import FileOp
from monga.common.exception import *
from monga.common.ks_client import KeystoneClient
from monga.common.utils import json_dump, split_path
import base64
import urllib
import uuid
import json

class Controller(object):
    """Base WSGI controller class for the proxy"""
    server_type = _('Base')

    def __init__(self, app, **local_variables):
        self.app    = app
        self.logger = app.logger
        self.db     = MongoDBConnector(app.mongo_path, app.mongo_port,
                                       db_name = app.mongo_db_name)
        self.fileop = FileOp(self.logger, app.conf)
        self.ks     = KeystoneClient(path   = app.auth_url, 
                                     token  = app.admin_token,
                                     admin  = app.admin_name, 
                                     pwd    = app.admin_password, 
                                     tenant = app.admin_tenant_name,
                                     domain = app.admin_domain_name)
        self.cache  = self.app.memcache
        self.deny_path = ['/shared', '/shared/', '/team', '/team/', '/']

    def check_special_path(self, path):
        #check specified folder to deny it
        if self.check_path(path) in self.deny_path :
            raise BadRequestError('This path can not access')
        elif self.check_path(path).startswith('/team/'):
            if len(split_path(self.check_path(path))) == 2 :
                raise BadRequestError('This path can not access')
        return path

    def decode_and_check_path(self, path) :
        return self.check_special_path(self.decode_url(path))
        
    def _ks_get_user_tenants(self, user_id, token):
        return self.ks.get_user_tenants(user_id, token)
        
    def encode_url(self, path):
        return urllib.quote(path)
        
    def decode_url(self, path):
        return urllib.unquote(path)    
        
    def check_role(self, roles, action = 'r'):
        '''
        action = 'w' ==> write (at least member)
               = 's' ==> share (at least admin)
               = 'r' ==> read  (at least guest)
        '''
        try:
            roles.index('admin')
            return True
        except ValueError:
            if action == 's':
                return False
        try:
            roles.index('member')
            return True
        except ValueError:
            if action == 'w':
                return False
        try:
            roles.index('guest')
            return True
        except ValueError:
            return False
        return False
        
    def check_special_folder(self, user_info, path, permission = None, 
                             lock = False):

        is_share, is_team = self.judge_special_folder_case(path)

        #Find match path then check permission
        if is_share : 
            #Check path correct or not
            _map_path, _new_path = self.get_share_path(path)
            if not _map_path:
                raise BadRequestError('Can\'t operate this path')
            _shared = self.db.find_mathched_shared_path(user_info, _map_path)
            
            #Check this path exist or not
            if not _shared :
                raise BadRequestError('Can\'t find this shared path')
                
            #Check Permssion
            if permission:
                if not _shared['permission'][permission] :
                    raise BadRequestError('''Can\'t operate object to this '''
                                          '''shared path''')
                                          
            #Combine new path
            if _new_path :
                _path = _shared['link_path'] + _new_path
            else:
                _path = _shared['link_path']
                
            #Combine real user info
            _user = self.get_real_user(user_info, _shared)
            
        elif is_team :
        
            #Check path correct or not
            _map_path, team_name, _new_path = self.get_team_path(path)
            if not _map_path:
                raise BadRequestError('Can\'t operate this path')
                
            #TODO permission
            
            #Combine new path
            if _new_path :
                _path = _new_path
            else:
                _path = '.'
            _key = 'tenant_' + user_info['tenant_id']
            try:
                tenants = json.loads(self.cache.get(_key))
            except Exception:
                tenants = self._ks_get_user_tenants(
                    user_info['user_id'], user_info.get(
                        'user_token', self.ks.get_admin_token()))
                        
            #Combine tenant user info
            _user = user_info.copy()
            
            #user path find correct tenant_id
            for tenant in tenants:
                if tenant['name'] == team_name :
                    _user['tenant_id'] = tenant['id']
                    _user['tenant_name'] = tenant['name']
                    _user['quota'] = tenant.get('quota', 5368709120)
        else :
            _user = user_info.copy()
            _path = path
        if lock:
            #Check file lock
            if not self.db.find_lock(_user['tenant_id'],
                                     _user['domain_id'], _path) :
                raise BadRequestError('File was locked')
        return _user, _path, is_share, is_team
        
    def get_tenant_quota(self, user_info):
        _key = 'tenant_' + user_info['tenant_id']
        #user_info already modified to file owner's teannt
        try:
            tenants = json.loads(self.cache.get(_key))
        except Exception:
            tenants = self._ks_get_user_tenants(
                user_info['user_id'], user_info.get(
                    'user_token', self.ks.get_admin_token()))
        for tenant in tenants :
            if tenant['name'] == user_info['tenant_name'] :
                return int(tenant.get('quota', 5368709120))
        return 5368709120
        
    def get_team_name(self, path):
        try:
            _path = split_path(path)
            return _path[1]
        except IndexError:
            return None

    def get_real_user(self, user_info, _shared):
        _user = user_info.copy()
        _user['user_id']     = _shared['link_user_id']
        _user['user_name']   = _shared['link_user_name']
        _user['tenant_id']   = _shared['link_tenant_id']
        _user['tenant_name'] = _shared['link_tenant_name']
        _user['domain_id']   = _shared['link_domain_id']
        _user['domain_name'] = _shared['link_domain_name']
        return _user
        
    def judge_special_folder_case(self, path):
        _path = split_path(path)
        _path = _path[0]
        if _path.lower() == 'shared':
            return True, False
        elif _path.lower() == 'team':
            return False, True
        else :
            return False, False
            
    def check_path(self, path):
        if path.startswith('/') :
            return path
        else:
            return '/' + path
            
    def get_team_path(self, path):
        _path = split_path(path)
    
        #path only has /team
        if len(_path) == 1 :
            return None, None, None
        
        team_name = _path[1]
        if len(_path) == 2:
            if path.startswith('/'):
                return path, team_name, None
            else:        
                return '/' + path, team_name, None
        elif len(_path) > 2:
            map_path = '/' + _path[0] + '/' +_path[1]
            del _path[0:2]
            new_path = '/' + '/'.join(_path)
            return map_path, team_name, new_path
        else :
            return None, None, None
            
    def get_share_path(self, path):

        _path = split_path(path)

        #path only has /share
        if len(_path) == 1 :
            return None, None

        if len(_path) == 2:
            if path.startswith('/'):
                return path, None
            else:        
                return '/' + path, None
        elif len(_path) > 2:
            map_path = '/' + _path[0] + '/' +_path[1]
            del _path[0:2]
            new_path = '/' + '/'.join(_path)
            return map_path, new_path
        else :
            return None, None
            
    def get_shared_path(self, path):
        _path = split_path(path)
        return '/' + '/'.join(_path[0:2])
            
    def modfied_shared_contents(self, body, user_info, path):
        _body = json.loads(body)
        data = self.db.find_shared(user_info, 
                                   action = 'to', 
                                   shared_path = self.get_shared_path(path), 
                                   once = True, 
                                   match = True)
        if data :
            _body['path'] = _body['path'].replace(data['link_path'], 
                                                  data['shared_path'], 1)
            if _body.get('contents', None):
                for _content in _body['contents']:
                    _content['path'] = \
                        _content['path'].replace(data['link_path'], 
                                                 data['shared_path'], 1)
        return json_dump(_body)
        
    def modfied_team_contents(self, body, path):
        path = self.get_shared_path(path)
        _body = json.loads(body)
        _body['path'] = _body['path'].replace('/', path + '/', 1)
        if _body.get('contents', None):
            for _content in _body['contents']:
                _content['path'] = _content['path'].replace('/', path + '/', 1)
        return json_dump(_body)

    def get_result(self, status):
        def _get_status_int(status):
            return int(status.split(' ', 1)[0])
        if _get_status_int(status) < 300 and \
            _get_status_int(status) >= 200 :
            return True
        else:
            return False
            
    def modify_userinfo(self, orig, new, is_team):
        user_info = orig.copy()
        if is_team :
            user_info['tenant_id']   = new['tenant_id']
            user_info['tenant_name'] = new['tenant_name']
        return user_info

    @staticmethod
    def get_uuid():
        return str(uuid.uuid4())
