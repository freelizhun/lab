from monga.controller.base import Controller
from monga.common import response as RESP
from swift.common.utils import public
from monga.common import exception as exception
from monga.common.exception import *
from monga.common.utils import json_dump
import json

class SearchController(Controller):
    server_type = _('Search')

    def __init__(self, app, **kwargs):
        Controller.__init__(self, app)
        self.action = 'Search'
        
    def get_link_user(self, data):
        return {
            'user_id'     : data['link_user_id'],
            'user_name'   : data['link_user_name'],
            'tenant_id'   : data['link_tenant_id'],
            'tenant_name' : data['link_tenant_name'],
            'domain_id'   : data['link_domain_id'],
            'domain_name' : data['link_domain_name']
        }

    @public
    @exception.handle_exceptions()
    def GET(self, user_info, req, path = '.'):
    
        #check user role
        if not self.check_role(user_info['user_roles'], 'r'):
            raise ForbiddenError('Access denied')
            
        #Get query condition from req
        try:
            query = self.decode_url(req.GET['query'])
        except Exception:
            raise BadRequestError('Lack query value')
            
        #Decode path
        path = self.decode_url(path)
        
        #Get response from fileop
        resp = self.fileop.search(user_info, path, req, query)
        entries = json.loads(resp.body)
        
        #get shared result
        _shares = self.db.find_shared(user_info, action = 'to')
        for _share in _shares :
            _user = self.get_link_user(_share)
            try:
                _resp = self.fileop.search(_user, _share['link_path'], req, query)
                _entries = json.loads(_resp.body)
                for _e in _entries :
                    _e['path'] = _e['path'].replace(_share['link_path'], 
                                                    _share['shared_path'], 1)
                    entries.append(_e)
            except FileNotFoundError:
                self.db.delete_shared(str(_share['_id']))
                
        #find team folder
        #Get tenants data from cache or keystone
        try:
            _key = 'tenant_' + user_info['tenant_id']
            tenants = json.loads(self.cache.get(_key))
        except :
            tenants = self._ks_get_user_tenants(user_info['user_id'],
                                                user_info['user_token'])
        for tenant in tenants :
            if tenant['name'] != user_info['tenant_name'] and \
                tenant['id'] != user_info['tenant_id'] :
                _user = user_info.copy()
                _user['tenant_id'] = tenant['id']
                _user['tenant_name'] = tenant['name']
                try:
                    _resp = self.fileop.search(_user, '.', req, query)
                    _entries = json.loads(_resp.body)
                    for _e in _entries :
                        team_path = '/team/' + tenant['name'] + '/'
                        _e['path'] = _e['path'].replace('/', team_path, 1)
                        entries.append(_e)
                except FileNotFoundError:
                    #Do nothing
                    pass

        #Generate resp.body        
        resp.body = json_dump(entries)
        
        #Record Activty
        self.db.insert_log(user_info, 
                           self.action,
                           to_path  = self.check_path(path),
                           result   = self.get_result(resp.status),
                           notifier = True)
        return resp

    @public
    @exception.handle_exceptions()
    def POST(self, user_info, req, path = '.'):
        return self.GET(user_info, req, path)

