from monga.controller.base import Controller
from monga.common import response as RESP
from swift.common.utils import public
from monga.common import exception as exception
from monga.common.exception import *
from monga.common.utils import json_dump, split_path
import json

class CommentController(Controller):
    server_type = _('ChunkUpload')

    def __init__(self, app, **kwargs):
        Controller.__init__(self, app)
        self.action = 'Comment'

    @public
    @exception.handle_exceptions()
    def POST(self, user_info, req, path = ''):
        '''
        *** Only allow file to add comment***

        {'msg' "<msg>"} #Length under 256
        '''
        #check user role
        if not self.check_role(user_info['user_roles'], 'w'):
            raise ForbiddenError('Access denied')
            
        #Decode path
        path = self.decode_and_check_path(path)

        #Check shared/team folder
        _user, _path, is_share, is_team = \
            self.check_special_folder(user_info, path, 'write', True)

        #Check file exist or not
        _resp = self.fileop.get_meta(_user, _path, req)
        if not self.get_result(_resp.status):
            return _resp

        #Read body
        body = json.loads(req.body)
        
        #Check msg
        msg = body.get('msg', None)
        if not msg:
            raise BadRequestError('Lack comment msg')
        else:
            msg = self.decode_url(msg)

        #Check msg length
        if len(msg) > 256 :
            raise BadRequestError('Over msg length')
            
        #Add comment
        self.db.insert_comment(_user, user_info, self.check_path(_path), msg)
            
        #Record it
        self.db.insert_log(self.modify_userinfo(user_info, _user ,is_team), 
                           self.action,
                           method    = 'POST',
                           to_path   = self.check_path(path),
                           result    = True,
                           is_share  = is_share,
                           is_team   = is_team)
            
        return RESP.created()

    @public
    @exception.handle_exceptions()
    def GET(self, user_info, req, path):
    
        #check user role
        if not self.check_role(user_info['user_roles'], 'w'):
            raise ForbiddenError('Access denied')
            
        #Decode path
        path = self.decode_and_check_path(path)

        #Check shared/team folder
        _user, _path, is_share, is_team = \
            self.check_special_folder(user_info, path, 'write', True)
            
        #Combine response body
        comments = self.db.find_comment(_user, self.check_path(_path))
        _entries = []
        for comment in comments :
            _comment = {
                'msg'  : comment['msg'],
                'time' : comment['updated_time'],
                'user' : comment['comment_user'],
                'icon' : comment['user_icon']
            }
            _entries.append(_comment)
            
        return RESP.ok(content = json_dump(_entries))
