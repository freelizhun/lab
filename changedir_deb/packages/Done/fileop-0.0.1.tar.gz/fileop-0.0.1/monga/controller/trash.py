from monga.controller.base import Controller
from monga.common import response as RESP
from swift.common.utils import public
from monga.common import exception as exception
from monga.common.exception import *
from monga.common.utils import json_dump
import json

class TrashController(Controller):
    server_type = _('Trash')

    def __init__(self, app, **kwargs):
        Controller.__init__(self, app)
        self.action = 'Trash'

    def get_tenant(self, tenants, name, orig_name) :
        _tenant = None
        is_team = True
        for tenant in tenants :
            if tenant['name'] == name :
                _tenant = tenant.copy()
                if tenant['name'] == orig_name :
                    is_team = False
        return _tenant, is_team

    @public
    @exception.handle_exceptions()
    def GET(self, user_info, req):

        #check user role
        if not self.check_role(user_info['user_roles'], 'r'):
            raise ForbiddenError('Access denied')

        #find team folder
        #Get tenants data from cache or keystone
        try:
            _key = 'tenant_' + user_info['tenant_id']
            tenants = json.loads(self.cache.get(_key))
        except :
            tenants = self._ks_get_user_tenants(user_info['user_id'],
                                                user_info['user_token'])
        _entries = {}
        for tenant in tenants :
            if tenant['name'] != user_info['tenant_name'] and \
                tenant['id'] != user_info['tenant_id'] :
                _user = user_info.copy()
                _user['tenant_id'] = tenant['id']
                _user['tenant_name'] = tenant['name']
                try:
                    _resp = self.fileop.trash_list(req, _user)
                    _entries[_user['tenant_name']] = json.loads(_resp.body)
                except FileNotFoundError:
                    #Do nothing
                    pass

        #Get response from connector
        resp = self.fileop.trash_list(req, user_info)
        _entries[user_info['tenant_name']] = json.loads(resp.body)

        _resp_body = []
        for _name, _array in _entries.iteritems():
            for _trash in _array:
                _trash = _trash.copy()
                _trash['team'] = _name
                _resp_body.append(_trash)

        #Record Activty
        self.db.insert_log(user_info, 
                           self.action,
                           method  = 'GET',
                           to_path = None,
                           result  = self.get_result(resp.status))

        return RESP.ok(content=json_dump(_resp_body))
        
    @public
    @exception.handle_exceptions()
    def DELETE(self, user_info, req, _id = None):

        #check user role
        if not self.check_role(user_info['user_roles'], 'w'):
            raise ForbiddenError('Access denied')

        #Get team_name
        try:
            team_name = self.decode_url(req.GET['team'])
        except Exception:
            raise BadRequestError('Lack team name')

        #find team folder
        #Get tenants data from cache or keystone
        try:
            _key = 'tenant_' + user_info['tenant_id']
            tenants = json.loads(self.cache.get(_key))
        except :
            tenants = self._ks_get_user_tenants(user_info['user_id'],
                                                user_info['user_token'])

        _tenant, is_team = \
            self.get_tenant(tenants, team_name, user_info['tenant_name'])

        if not _tenant :
            raise BadRequestError('Can not find this space')
        else :
            _user = user_info.copy()
            _user['tenant_name'] = _tenant['name']
            _user['tenant_id']   = _tenant['id']
            
        #Get response from connector
        #resp, is_dir, change_size = \
        resp = self.fileop.trash_remove(req, _user, _id)

        #Modified resp body
        _body = json.loads(resp.body).copy()
        if is_team :
            _body['path'] = '/team/' + _tenant['name'] + _body['path']
        _body['team'] = team_name
        _path = _body['path']
        
        resp.body = json_dump(_body)

        #Record Activty
        self.db.insert_log(self.modify_userinfo(user_info, _user ,is_team),
                           self.action,
                           method  = 'DELETE',
                           delta   = 'DELETE',
                           to_path = _path,
                           is_team = is_team,
                           result  = self.get_result(resp.status))
        return resp

    @public
    @exception.handle_exceptions()
    def PUT(self, user_info, req, _id = None):

        #check user role
        if not self.check_role(user_info['user_roles'], 'w'):
            raise ForbiddenError('Access denied')

        #Get team_name
        try:
            team_name = self.decode_url(req.GET['team'])
        except Exception:
            raise BadRequestError('Lack team name')

        #find team folder
        #Get tenants data from cache or keystone
        try:
            _key = 'tenant_' + user_info['tenant_id']
            tenants = json.loads(self.cache.get(_key))
        except :
            tenants = self._ks_get_user_tenants(user_info['user_id'],
                                                user_info['user_token'])

        _tenant, is_team = \
            self.get_tenant(tenants, team_name, user_info['tenant_name'])

        if not _tenant :
            raise BadRequestError('Can not find this space')
        else :
            _user = user_info.copy()
            _user['tenant_name'] = _tenant['name']
            _user['tenant_id']   = _tenant['id']

        #Get response from connector
        #resp, is_dir, change_size = \
        resp = self.fileop.trash_restore(req, _user, _id)

        #Modified resp body
        _body = json.loads(resp.body)
        _path = _body['path']
        if is_team :
            resp.body = self.modfied_team_contents(resp.body, team_name)
        resp.body = json_dump(_body)

        #Record Activty
        self.db.insert_log(self.modify_userinfo(user_info, _user ,is_team),
                           self.action,
                           method  = 'PUT',
                           delta   = 'Create',
                           to_path = _path,
                           is_team = is_team,
                           result  = self.get_result(resp.status))
        return resp

    @public
    @exception.handle_exceptions()
    def POST(self, user_info, req, path):

        #check user role
        if not self.check_role(user_info['user_roles'], 'w'):
            raise ForbiddenError('Access denied')

        #Decode path
        path = self.decode_and_check_path(path)

        #Check shared folder
        _user, _path, is_share, is_team = \
            self.check_special_folder(user_info, path, 'write', True)

        #Get response from connector
        resp, is_dir, junk = self.fileop.trash(req, _user, _path)

        #Modified resp body
        if is_share :
            resp.body = self.modfied_shared_contents(resp.body, user_info, path)
        elif is_team :
            # modified team folder contents
            team_name = _user['tenant_name']
            resp.body = self.modfied_team_contents(resp.body, 
                                                   '/team/' + team_name)
        else :
            team_name = _user['tenant_name']

        #Modified resp body
        _body = json.loads(resp.body).copy()
        _body['team'] = team_name
        resp.body = json_dump(_body)
            
        #Record Activty
        self.db.insert_log(self.modify_userinfo(user_info, _user ,is_team),
                           self.action,
                           method   = 'POST',
                           delta    = 'DELETE',
                           to_path  = self.check_path(path),
                           result   = self.get_result(resp.status),
                           is_dir   = is_dir,
                           is_share = is_share,
                           is_team  = is_team)
        return resp
