from monga.controller.base import Controller
from monga.common import response as RESP
from swift.common.utils import public
from monga.common import exception as exception
from monga.common.exception import *
from monga.connector.utils import get_datetime
from monga.common.utils import json_dump
import json

class MetaController(Controller):
    server_type = _('Metadata')

    def __init__(self, app, **kwargs):
        Controller.__init__(self, app)
        self.action = 'Metadata'
        
    def shared_folder_body(self):
        return {"hash": "",
                "bytes": 0,
                "shared_flag" : False,
                "thumb_exists": False, 
                "path": "/shared", 
                "is_dir": True, 
                "icon": "folder_public", 
                "rev": "", 
                "modified": get_datetime(), 
                "size": "0 Bytes", 
                "root": "File Cruiser"}
                
    def team_folder_body(self):
        return {"hash": "",
                "bytes": 0,
                "shared_flag" : False,
                "thumb_exists": False, 
                "path": "/team", 
                "is_dir": True, 
                "icon": "folder_public", 
                "rev": "", 
                "modified": get_datetime(), 
                "size": "0 Bytes", 
                "root": "File Cruiser"}
        
    def get_shared_user_info(self, info):
        return {
            'user_id'     : info['link_user_id'],
            'user_name'   : info['link_user_name'],
            'tenant_id'   : info['link_tenant_id'],
            'tenant_name' : info['link_tenant_name'],
            'domain_id'   : info['link_domain_id'],
            'domain_name' : info['link_domain_name'],
            'client_ip'   : '',
            'device_name' : '',
            'user_roles'  : []}  

    @public
    @exception.handle_exceptions()
    def GET(self, user_info, req, path = '.'):
    
        #check user role
        if not self.check_role(user_info['user_roles'], 'r'):
            raise ForbiddenError('Access denied')
            
        #Decode path
        path = self.decode_url(path)
        
        if path == 'shared' or path =='shared/':
            #Special folder ***shared*** case
            
            #Define flags
            is_share = True
            is_team  = False
            
            #Generate shared folder bofy
            shared_body = self.shared_folder_body()
            shared_body['contents'] = []
            data = self.db.find_shared(user_info, action = 'to')
            for _d in data:
                _s_user = self.get_shared_user_info(_d)
                _resp = self.fileop.get_meta(_s_user, _d['link_path'], req)
                _content = json.loads(_resp.body)
                _content['path'] = _d['shared_path']
                _content['shared_flag'] = True
                if _content.get('contents', None):
                    del _content['contents']
                shared_body['contents'].append(_content)
            resp = RESP.ok(json_dump(shared_body))
            
        elif path == 'team' or path =='team/':
            #Special folder ***team*** case
            
            #Define flags
            is_share = False
            is_team  = True
            
            #Get tenants data from cache or keystone
            try:
                _key = 'tenant_' + user_info['tenant_id']
                tenants = json.loads(self.cache.get(_key))
            except :
                tenants = self._ks_get_user_tenants(user_info['user_id'],
                                                    user_info['user_token'])
                                                    
            #Generate team folder body
            team_body = self.team_folder_body()
            team_body['contents'] = []
            for tenant in tenants:
                if tenant['name'] == req.headers['X-Tenant-Name']:
                    continue
                else :
                    _team = self.team_folder_body()
                    _team['path'] = _team['path'] + '/' + tenant['name']
                    team_body['contents'].append(_team)
                    
            resp = RESP.ok(json_dump(team_body))
        else:
            #Normal casse 
        
            #Check shared/team folder
            _user, _path, is_share, is_team = \
                self.check_special_folder(user_info, path)
                
            #Get response from connector
            resp = self.fileop.get_meta(_user, _path, req)
            
            #check comment number
            _body = json.loads(resp.body)
            _body['comment'] = self.db.find_comment(_user, 
                                                    self.check_path(_path), 
                                                    True)
            if _body.get('contents', None):
                entries = []
                for _content in _body['contents'] :
                    _content['comment'] = \
                        self.db.find_comment(_user, 
                                             self.check_path(_content['path']),
                                             True)
                    entries.append(_content)
                _body['contents'] = entries
            resp.body = json_dump(_body)
            
            # Modified body for special cases
            if path == '.' :
                # ***Root***
                _body = json.loads(resp.body)
                _body['contents'].append(self.shared_folder_body())
                _body['contents'].append(self.team_folder_body())
                resp.body = json_dump(_body)
            elif is_team :
                # ***Team***
                # modified team folder contents
                team_path, junk, junk2 = self.get_team_path(path)
                resp.body = self.modfied_team_contents(resp.body, team_path)
            elif is_share :
                # ***Share***
                resp.body = self.modfied_shared_contents(resp.body, user_info,
                                                         path)

            #If not team folder case, check each path is share or not
            if not is_team :
                #Check each path of shared flag
                _body = json.loads(resp.body)
                _data = self.db.find_shared(user_info, action = 'from', 
                                            path = _body['path'], once = True)
                if _data : 
                    _body['shared_flag'] = True
                else :
                    _body['shared_flag'] = False
                if _body.get('contents', None):
                    entries = []
                    for _content in _body['contents'] :
                        _data = self.db.find_shared(user_info, 
                                                    action = 'from',
                                                    path = _content['path'], 
                                                    once = True)
                        if _data :
                            _content['shared_flag'] = True
                        else :
                            _content['shared_flag'] = False
                        entries.append(_content)
                    _body['contents'] = entries
                resp.body = json_dump(_body)
            
        #Log Activity
        self.db.insert_log(user_info, 
                           self.action, 
                           method   = 'GET',
                           to_path  = path,
                           size     = resp.headers.get('Content-Length', 0),
                           result   = self.get_result(resp.status),
                           is_share = is_share,
                           is_team  = is_team,
                           notifier = False)
        return resp
