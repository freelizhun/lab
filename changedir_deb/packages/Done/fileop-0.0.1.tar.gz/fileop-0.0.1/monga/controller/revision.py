from monga.controller.base import Controller
from monga.common import response as RESP
from swift.common.utils import public
from monga.common import exception as exception
from monga.common.exception import *

class RevisionController(Controller):
    server_type = _('Revision')

    def __init__(self, app, **kwargs):
        Controller.__init__(self, app)
        self.action = 'Revision'

    @public
    @exception.handle_exceptions()
    def GET(self, user_info, req, path):
    
        #check user role
        if not self.check_role(user_info['user_roles'], 'r'):
            raise ForbiddenError('Access denied')
            
        #Decode path
        path = self.decode_and_check_path(path)
        
        #Check shared folder
        _user, _path, is_share, is_team = \
            self.check_special_folder(user_info, path)
            
        #Get response from connector
        resp = self.fileop.revisions(_user, _path, req)
        
        #Modified resp body
        if is_share :
            resp.body = self.modfied_shared_contents(resp.body, user_info, path)
        elif is_team :
            # modified team folder contents
            team_path, junk, junk2 = self.get_team_path(path)
            resp.body = self.modfied_team_contents(resp.body, team_path)
            
        #Log Activity
        self.db.insert_log(user_info, 
                           self.action, 
                           to_path  = self.check_path(path),
                           result   = self.get_result(resp.status),
                           is_share = is_share,
                           is_team  = is_team,
                           notifier = True)
        return resp
