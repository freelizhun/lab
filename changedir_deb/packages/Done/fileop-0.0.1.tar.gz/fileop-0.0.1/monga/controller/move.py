from monga.controller.base import Controller
from monga.common import response as RESP
from swift.common.utils import public
from monga.common import exception as exception
from monga.common.exception import *
import json

class FileMoveController(Controller):
    server_type = _('FileMove')

    def __init__(self, app, **kwargs):
        Controller.__init__(self, app)
        self.action = 'FileMove'

    @public
    @exception.handle_exceptions()
    def POST(self, user_info, req):
    
        #Check role permission
        if not self.check_role(user_info['user_roles'], 'w'):
            raise ForbiddenError('Access denied')
            
        #Get from_path and to_path
        try:
            from_path = self.decode_url(req.GET['from_path'])
            to_path   = self.decode_url(req.GET['to_path'])
        except Exception:
            raise BadRequestError('Lack file path')

        #Check special path
        self.check_special_path(from_path)
        self.check_special_path(to_path)
            
        #Check to_path
        to_user, _to_path, is_share, is_team = \
            self.check_special_folder(user_info, to_path, 'write', True)
            
        #Check from_path
        from_user, _from_path, junk, junk2 = \
            self.check_special_folder(user_info, from_path)
         
        #TODO hard to get size    
        #to_user Check quota
        #get real tenant quota from cache or keystone
        #_quota = self.get_tenant_quota(to_user)
        #_used = self.db.find_quota(to_user).get('used', 0)
        #size = req.headers.get('Content-Length', None)
        #if not size :
        #    raise LengthRequiredError()
        #else : size = int(size)
        #if (_used + size) > _quota:
        #    raise ExceedQuotaError('Exceed Quota Limit')
            
        #Pass to_path, from_path, to_user_info, from_user_info
        #Get response from connector
        resp, is_dir, change_size = \
            self.fileop.move(req, _to_path, _from_path, to_user, from_user,
                             is_copy = False)
                             
        #Modified resp body
        if is_share :
            resp.body = self.modfied_shared_contents(resp.body, user_info,
                                                     to_path)
        elif is_team :
            # modified team folder contents
            team_path, junk, junk2 = self.get_team_path(to_path)
            resp.body = self.modfied_team_contents(resp.body, team_path)
            
        #Record Used
        self.db.update_quota(to_user, change_size)
        self.db.update_quota(from_user, -change_size)
        
        #Record Activty
        self.db.insert_log(self.modify_userinfo(user_info, to_user ,is_team),
                           self.action,
                           method    = 'POST',
                           delta     = 'Create',
                           from_path = self.check_path(from_path),
                           to_path   = self.check_path(to_path),
                           is_dir    = is_dir,
                           size      = change_size,
                           is_share  = is_share,
                           is_team   = is_team,
                           result    = self.get_result(resp.status))
        return resp

