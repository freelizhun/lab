from monga.controller.base import Controller
from monga.common import response as RESP
from swift.common.utils import public
from monga.common import exception as exception
from monga.common.exception import *
from monga.common.utils import json_dump
import uuid, datetime, json
from dateutil.parser import parse as time_parse


class ShareController(Controller):
    server_type = _('Share')

    def __init__(self, app, **kwargs):
        Controller.__init__(self, app)
        self.action = 'PublicLink'
        self.server_addr = app.server_addr
        
    def get_expire_time(self, expired_time):
        try :
            expired_time = time_parse(expired_time)
        except ValueError :
            expired_time = datetime.utcfromtimestamp(expired_time)
        except Exception :
            expired_time = datetime.datetime.now() + \
                              datetime.timedelta(days = 7)
        return expired_time
        
    def get_expire_tag(self, expired_time):
        return datetime.datetime.strftime(expired_time,
                                          "%a, %d %b %Y %H:%M:%S")
        
    @public
    @exception.handle_exceptions()
    def GET(self, user_info, req):
        #check user role
        if not self.check_role(user_info['user_roles'], 's'):
            raise ForbiddenError('Access denied')
        query_data = {
            'tenant_id' : user_info['tenant_id'],
            'user_id'   : user_info['user_id'],
            'domain_id' : user_info['domain_id']}
        data = self.db.find_dlink(query_data, multi = True)
        entries = []
        for _d in data:
            _e = {
                "id"      : str(_d['_id']),
                "url"     : _d['public_url'],
                "expires" : _d['expired_tag'],
                "path"    : _d['file_path'],
                "is_dir"  : _d.get('is_dir', False)
            }
            if _d['pwd']:
                _e['password'] = _d['pwd']
            entries.append(_e)
        self.db.insert_log(user_info, 
                           self.action,
                           method = 'GET',
                           result = self.get_result('200 OK'))
        return RESP.ok(content=json_dump(entries))
        
    @public
    @exception.handle_exceptions()
    def DELETE(self, user_info, req, _id):
        #check user role
        if not self.check_role(user_info['user_roles'], 's'):
            raise ForbiddenError('Access denied')
        #Delete record
        self.db.delete_dlink( _id )
        #Record Activty
        self.db.insert_log(user_info, 
                           self.action,
                           method = 'DELETE',
                           result = 1)
        return RESP.no_content()
        
    @public
    @exception.handle_exceptions()
    def PUT(self, user_info, req, _id):
        #check user role
        if not self.check_role(user_info['user_roles'], 's'):
            raise ForbiddenError('Access denied')
        #Get record
        _link = self.db.find_dlink({}, _id = _id)
        if _link :
            #Read body
            # {'expired_time' : <>, 'password' : <>}
            body = json.loads(req.body)
            pwd = body.get('password', None)
            expired_time = body.get('expired_time', None)
            query = {}
            if pwd :
                query['pwd'] = pwd
            if expired_time :
                expired_time = self.get_expire_time(expired_time)
                expired_tag  = self.get_expire_tag(expired_time)
                query['expired_time'] = int(expired_time.strftime('%s'))
                query['expired_tag'] = expired_tag
            _res = self.db.update_dlink(_id, query)
            if _res.get('ok', None) :
                self.db.insert_log(user_info,
                           self.action,
                           method = 'PUT',
                           result = 1)
                return RESP.created()
            else :
                self.db.insert_log(user_info,
                           self.action,
                           method = 'PUT',
                           result = 0)
                raise InternalServerError('Failed to update db')
        else :
            raise NotFoundError('Link not exist')

    @public
    @exception.handle_exceptions()
    def POST(self, user_info, req, path):
    
        #check user role
        if not self.check_role(user_info['user_roles'], 's'):
            raise ForbiddenError('Access denied')
            
        #Decode path
        path = self.decode_and_check_path(path)
        
        #Check shared/team folder
        _user, _path, is_share, is_team = \
            self.check_special_folder(user_info, path)
        
        #Check file exist or not before gen link
        _resp = self.fileop.get_meta(_user, _path, req)
        if not self.get_result(_resp.status):
            raise NotFoundError('File not exist')
        else :
            is_dir = json.loads(_resp.body).get('is_dir', False)
            
        #Get password, expired time
        pwd = req.headers.get('X-Public-Password',None)
        expired_time = req.headers.get('X-Expired-Time',None)
        if not expired_time :
            expired_time = datetime.datetime.now() + \
                           datetime.timedelta(days = 7)
        else :
            expired_time = self.get_expire_time(expired_time)
        expired_tag  = self.get_expire_tag(expired_time)
        
        #Generate public path
        match_path = '/v1/links/' + str(uuid.uuid4())
        public_path = self.server_addr + match_path
        self.db.insert_dlink(user_info, 
                             self.check_path(path), 
                             public_path, 
                             match_path, 
                             pwd = pwd,  
                             expired_time = int(expired_time.strftime('%s')),
                             expired_tag  = expired_tag,
                             is_dir = is_dir)
                             
        #Record Activty
        self.db.insert_log(user_info, 
                           self.action,
                           method    = 'POST',
                           from_path = self.check_path(path),
                           to_path   = public_path,
                           result    = self.get_result('200 OK'),
                           notifier  = True)
                           
        return RESP.created(content=json_dump({
                                "url" : public_path,
                                "expires" : expired_tag}))

