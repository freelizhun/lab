from monga.controller.base import Controller
from monga.common import response as RESP
from swift.common.utils import public
from monga.common import exception as exception
from monga.common.exception import *
from monga.common.utils import json_dump, current_timestamp
import time, json

class CursorController(Controller):
    server_type = _('Cursor')

    def __init__(self, app, **kwargs):
        Controller.__init__(self, app)
        self.action = 'Cursor'

    @public
    @exception.handle_exceptions()
    def GET(self, user_info, req):
    
        #check user role
        if not self.check_role(user_info['user_roles'], 'r'):
            raise ForbiddenError('Access denied')
            
        #Get curosor body
        resp_body = {'cursor' : current_timestamp()}
        
        #Record Activty
        self.db.insert_log(user_info, 
                           self.action,
                           method   = 'GET',
                           result   = True,
                           notifier = True)
                           
        return RESP.ok(content = json_dump(resp_body))
