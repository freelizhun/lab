from monga.common.utils import current_timestamp

class Comment(object):

    def insert_comment(self, user, comment_user, file_path, msg = '', 
                       db_name = 'comment'):
        #Record real file user's info, rather then comment user
        data = {
            'user_id'      : user.get('user_id', None),
            'user_name'    : user.get('user_name', None),
            'tenant_id'    : user.get('tenant_id', None),
            'tenant_name'  : user.get('tenant_name', None),
            'domain_id'    : user.get('domain_id', None),
            'domain_name'  : user.get('domain_name', None),
            'comment_user' : comment_user.get('user_name', None),
            'user_icon'    : '', #TODO not implement yet
            'msg'          : msg,
            'file_path'    : file_path,
            'updated_time' : current_timestamp(),
        }
        return self.base_insert(db_name, data)
        
    def find_comment(self, user, file_path, count = False, db_name = 'comment'):
        _query = {
            'file_path'   : file_path,
            'user_id'     : user.get('user_id', None),
            'user_name'   : user.get('user_name', None),
            'tenant_id'   : user.get('tenant_id', None),
            'tenant_name' : user.get('tenant_name', None),
            'domain_id'   : user.get('domain_id', None),
            'domain_name' : user.get('domain_name', None),
        }
        return self.base_find('comment', _query, count = count)

    def delete_comment(self, _id, db_name = 'device'):
        return self.direct_delete(db_name, _id)
