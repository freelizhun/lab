from monga.common.utils import current_timestamp
from bson.objectid import ObjectId

class Session(object):

    def insert_session(self, data, db_name = 'session'):
        _data = data.copy()
        return self.base_insert(db_name, _data)

    def delete_session(self, data, db_name = 'session'):
        return self.base_delete(db_name, data)

    def find_session(self, user, domain, once = False, db_name = 'session'):
        _query = {
            'user'   : user,
            'domain' : domain,
        }
        if once :
            return self.base_findone(db_name, _query)
        return self.base_find(db_name, _query)
    

