from monga.common.utils import current_timestamp
from bson.objectid import ObjectId

class Dlink(object):

    def insert_dlink(self, user_info, file_path, public_url,
                     match_url, pwd = None, expired_time = None,
                     expired_tag = None, is_dir = False, db_name = 'dlink'):
        if not expired_time:
            expired_time = int(round(time.time())) + 7*86400
        data = {
            'user_id'      : user_info.get('user_id', None),
            'user_name'    : user_info.get('user_name', None),
            'tenant_id'    : user_info.get('tenant_id', None),
            'tenant_name'  : user_info.get('tenant_name', None),
            'domain_id'    : user_info.get('domain_id', None),
            'domain_name'  : user_info.get('domain_name', None),
            'file_path'    : file_path,
            'public_url'   : public_url,
            'match_url'    : match_url,
            'pwd'          : pwd,
            'is_dir'       : is_dir,
            'expired_time' : expired_time,
            'updated_time' : current_timestamp(),
            'expired_tag'  : expired_tag
        }
        return self.base_insert(db_name, data)

    def find_dlink(self, data, _id = None, multi = False, match = False,
                   db_name = 'dlink'):
        if _id :
            return self.base_findone(db_name, {'_id' : ObjectId(_id)})
        elif multi and match :
            return self.match_find(db_name, data)
        elif multi and not match:
            return self.base_find(db_name, data)
        else :
            return self.base_findone(db_name, data)

    def update_dlink(self, _id, data, db_name = 'dlink'):
        return self.update(db_name, {'_id' : ObjectId(_id)}, {"$set" : data})

    def delete_dlink(self, _id, db_name = 'dlink'):
        return self.direct_delete(db_name, _id)
