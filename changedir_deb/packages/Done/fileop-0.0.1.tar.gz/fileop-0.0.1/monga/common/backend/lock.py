from monga.common.utils import current_timestamp

class Lock(object):

    def insert_lock(self, user_info, file_path, db_name = 'lock'):
        data = {
            'user_id'      : user_info.get('user_id', None),
            'user_name'    : user_info.get('user_name', None),
            'tenant_id'    : user_info.get('tenant_id', None),
            'tenant_name'  : user_info.get('tenant_name', None),
            'domain_id'    : user_info.get('domain_id', None),
            'domain_name'  : user_info.get('domain_name', None),
            'file_path'    : file_path,
            'updated_time' : current_timestamp(),
            'expired_time' : current_timestamp() + 86400
        }
        return self.base_insert(db_name, data)

    def find_lock(self, tenant_id, domain_id, path, db_name = 'lock'):
        result = self.base_find(db_name,
                       {'tenant_id' : tenant_id,
                        'file_path' : path,
                        'domain_id' : domain_id},
                       count = True)
        if result == 0:
            return True
        else:
            return False

    def find_expired_lock(self, query, db_name = 'lock'):
        return self.base_find(db_name, query)

    def delete_expired_lock(self, _id, db_name = 'lock'):
        return self.direct_delete(db_name, _id)

    def find_user_lock(self, user_info, path, db_name = 'lock'):
        result = self.base_findone(db_name, {
                    'user_id'      : user_info.get('user_id', None),
                    'user_name'    : user_info.get('user_name', None),
                    'tenant_id'    : user_info.get('tenant_id', None),
                    'tenant_name'  : user_info.get('tenant_name', None),
                    'domain_id'    : user_info.get('domain_id', None),
                    'domain_name'  : user_info.get('domain_name', None),
                    'file_path'    : path})
        if result:
            return True
        else:
            return False

    def delete_lock(self, user_info, path, db_name = 'lock'):
        return self.base_delete(db_name,
                                {'tenant_id' : user_info['tenant_id'],
                                 'user_id'   : user_info['user_id'],
                                 'file_path' : path,
                                 'domain_id' : user_info['domain_id']})
