from monga.common.utils import current_timestamp
from bson.objectid import ObjectId

class Device(object):

    def insert_device(self, data, db_name = 'device'):
        _data = data.copy()
        del _data['ws_key']
        del _data['remote_ip']
        del _data['token']
        _res = self.base_findone(db_name, _data)
        if not _res :
            _data['updated_time'] = current_timestamp()
            _data['enable'] = True
            _resp = self.base_insert(db_name, _data)
        else :
            _resp = self.update(db_name, _data,
                        {"$set" : {'updated_time' : current_timestamp()}}, True)
        return _resp
        
    def find_device(self, user, domain, agent = None, once = False, 
                    db_name = 'device'):
        _query = {
            'user'   : user,
            'domain' : domain
        }
        if agent :
            _query['agent'] = agent
        if once :
            return self.base_findone(db_name, _query)
        return self.base_find(db_name, _query)

    def find_device_by_id(self, _id, db_name = 'device'):
        _query = {'_id' : ObjectId(_id)}
        return self.base_findone(db_name, _query)

    def delete_device(self, _id, db_name = 'device'):
        return self.direct_delete(db_name, _id)

    def disable_device(self, _id, db_name = 'device'):
        return self.update(db_name, {'_id' : ObjectId(_id)},
                           {"$set" : {'enable' : False}}, True)

    def enable_device(self, _id, db_name = 'device'):
        return self.update(db_name, {'_id' : ObjectId(_id)},
                           {"$set" : {'enable' : True}}, True)
        
