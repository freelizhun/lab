class Quota(object) :

    def update_quota(self, user_info, used = 0, db_name = 'quota'):
        self.update(db_name, {'tenant_id' : user_info['tenant_id']}, 
                        {"$inc" : {'used' : used}}, True)

    def find_quota(self, user_info, multi = False, db_name = 'quota'):
        if multi :
            return self.base_find(db_name, {})
        else :
            res = self.base_findone(db_name, 
                                    {'tenant_id' : user_info['tenant_id']})
            if not res:
                return {'used' : 0, 'tenant_id' : user_info['tenant_id']}
            else :
                del res['_id']
            return res
