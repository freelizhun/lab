import pymongo
from pymongo import Connection
from bson.code import Code
from pymongo.errors import *
import time
import hashlib
import re
from bson.objectid import ObjectId
from monga.common import exception as exception
from monga.common.backend.base import BaseMongoDriver
from monga.common.utils import current_timestamp
#Collection codes
from monga.common.backend.quota   import Quota
from monga.common.backend.log     import Log
from monga.common.backend.lock    import Lock
from monga.common.backend.share   import Share
from monga.common.backend.dlink   import Dlink
from monga.common.backend.comment import Comment
from monga.common.backend.session import Session
from monga.common.backend.device  import Device

class MongoDBConnector(BaseMongoDriver, Quota, Log, Lock, Share, Dlink,
                       Comment, Session, Device):
    
    def __init__(self, path='localhost', port=27017, db_conn = None,
                 tz_aware = True, db_name = 'monga'):
        self.mongo_path = path
        self.mongo_port = port
        self.time_zone = tz_aware
        BaseMongoDriver.__init__(self, path, port, conn = db_conn, 
                                 db_name = db_name)

    def clean_records(self, tenant_id):
        #clean lists
        _list = {
            'log'    : ['tenant_id'],
            'quota'  : ['tenant_id'],
            'dlink'  : ['tenant_id'],
            'lock'   : ['tenant_id'],
            'shared' : ['from_tenant_id', 'to_tenant_id', 'link_tenant_id'],
        }
        for k, v in _list.iteritems() :
            for _v in v:
                self.base_multi_delete(k, { _v : tenant_id })
        return 
