import pymongo
from pymongo import Connection
from pymongo.mongo_client import MongoClient
from bson.code import Code
from bson.objectid import ObjectId
from pymongo.errors import *
import time
import hashlib
import re
from monga.common import exception as exception

class BaseMongoDriver (object):

    '''
    Basic Functions
    '''
    def __init__(self, path, port, tz_aware = True, timeout = 30, 
                 pool_size = 1024, conn = None, db_name = 'monga'):
        self.mongo_path     = path
        self.mongo_port     = port
        self.time_zone      = tz_aware
        self.mongo_timeout  = timeout
        self.mongo_poolsize = pool_size
        self.db_name = db_name
        if conn :
            self.conn = conn
        else :
            self.conn = self.get_connection()
        
    def base_find(self, db_name, data, limit = 0, sort = None, count = False,
                  skip = 0):
        try :
            if not self.conn :
                self.conn = self.get_connection()
            db = self.conn[self.db_name][db_name]
            if count :
                res = db.find(data, limit = limit, sort = sort).count()
            else :
                res = db.find(data, limit = limit, 
                              sort = sort).skip(skip).clone()
            self.conn.end_request()
            return res
        except AutoReconnect:
            self.conn = self.get_connection()
            return  self.base_find(db_name, data, limit, sort, count, skip)
        
    def base_findone(self, db_name, data):
        try :
            if not self.conn :
                self.conn = self.get_connection()
            db = self.conn[self.db_name][db_name]
            res = db.find_one(data)
            if res :
                res = res.copy()
            self.conn.end_request()
            return res
        except AutoReconnect:
            self.conn = self.get_connection()
            return  self.base_findone(db_name, data)

    def base_insert(self, db_name, data):
        try :
            if not self.conn :
                self.conn = self.get_connection()
            db = self.conn[self.db_name][db_name]
            res = db.insert(data)
            self.conn.end_request()
            return res
        except AutoReconnect:
            self.conn = self.get_connection()
            return  self.base_insert(db_name, data)
        
    def direct_delete(self, db_name, _id):
        try :
            if not self.conn :
                self.conn = self.get_connection()
            db = self.conn[self.db_name][db_name]
            db.remove({'_id' : ObjectId(_id)})
            self.conn.end_request()
            return True
        except AutoReconnect:
            self.conn = self.get_connection()
            return  self.direct_delete(db_name, _id)
        except OperationFailure:
            return False

    def base_delete(self, db_name, data):
        try:
            if not self.conn :
                self.conn = self.get_connection()
            db = self.conn[self.db_name][db_name]
            record = db.find_one(data)
            if record :
                db.remove(record['_id'],False)
                self.conn.end_request()
                return True
            self.conn.end_request()
            return False
        except AutoReconnect:
            self.conn = self.get_connection()
            return  self.base_delete(db_name, data)
        except OperationFailure:
            return False
        
    def base_multi_delete(self, db_name, data):
        try :
            if not self.conn :
                self.conn = self.get_connection()
            db = self.conn[self.db_name][db_name]
            res = db.remove(data)
            self.conn.end_request()
            return res
        except AutoReconnect:
            self.conn = self.get_connection()
            return self.base_multi_delete(db_name, data)
        
    def update(self, db_name, obj, new_obj, upsert = False, manipulate = False):
        try :
            if not self.conn :
                self.conn = self.get_connection()
            db = self.conn[self.db_name][db_name]
            res = db.update(obj, new_obj, upsert = upsert,
                      manipulate = manipulate, save = False, multi = False)
            self.conn.end_request()
            return res
        except AutoReconnect:
            self.conn = self.get_connection()
            return self.update(db_name, obj, new_obj, upsert, manipulate)

    def match_find(self, db_name, conditions = None, once = False):
        try :
            if not self.conn :
                self.conn = self.get_connection()
            db = self.conn[self.db_name][db_name]
            if conditions:
                conditions = self._match_all(conditions)
            if once :
                res = db.find_one(conditions)
                if res :
                    res = res.copy()
                self.conn.end_request()
                return res
            else :
                res = db.find(conditions).clone()
                self.conn.end_request()
                return res
        except AutoReconnect:
            self.conn = self.get_connection()
            return self.match_find(db_name, conditions, once)

    def get_connection(self):
        retry = 0
        while retry < 10:
            try:
                conn = Connection(host = self.mongo_path, 
                                  port = self.mongo_port,
                                  max_pool_size = 1,
                                  tz_aware = self.time_zone,
                                  network_timeout = self.mongo_timeout)
                break
            except AutoReconnect :
                retry += 1
                time.sleep(0.5)
                if retry == 10:
                    raise ConnectionFailure()
        return conn

    def _match_all(self, conditions):
        for key, value in conditions.items():
            if type(value)==list:
                _value = []
                for v in value:
                    _value.append(re.compile(v))
                conditions[key] = {'$all' : _value}
            elif type(value)==str:
                conditions[key] = {'$all' : [re.compile(unicode(value),
                                             re.UNICODE)]}
            elif type(value)==unicode :
                conditions[key] = {'$all' : [re.compile(unicode(value),
                                             re.UNICODE)]}
            else:
                conditions[key] = {'$all' : [re.compile(str(value))]}
        return conditions

