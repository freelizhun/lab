from monga.common.utils import current_timestamp

class Log(object):

    def insert_log(self, user_info, action, method = 'GET', from_path = None, 
                   to_path = None, size = 0, is_chunk = False, is_dir = False,
                   chunk_id = None, is_share = False, is_team = False, 
                   result = True, delta = None, notifier = False, 
                   db_name = 'log'):
        data = {
            'user_id'      : user_info.get('user_id', None),
            'user_name'    : user_info.get('user_name', None),
            'tenant_id'    : user_info.get('tenant_id', None),
            'tenant_name'  : user_info.get('tenant_name', None),
            'domain_id'    : user_info.get('domain_id', None),
            'domain_name'  : user_info.get('domain_name', None),
            'action'       : action,
            'method'       : method,
            'from_path'    : from_path,
            'to_path'      : to_path,
            'file_size'    : size,
            'is_chunk'     : is_chunk,
            'is_dir'       : is_dir,
            'chunk_id'     : chunk_id,
            'client_ip'    : user_info.get('client_ip', None), 
            'result'       : result,
            'is_share'     : is_share,
            'is_team'      : is_team,
            'device_name'  : user_info.get('device_name', 'MongaUser'),
            'delta'        : delta,
            'updated_time' : current_timestamp(),
            'notifier'     : notifier
        }
        return self.base_insert(db_name, data)

    def find_log(self, data, limit = 100, sort = False, skip = 0, 
                 db_name = 'log'):
        if not sort :
            sort = [("updated_time", 1)]
        else :
            sort = [("updated_time", -1)]
        return self.base_find(db_name, 
                              data, 
                              limit = limit, 
                              sort  = sort,
                              skip  = skip)
                              
    def find_log_count(self, data, db_name = 'log'):
        return self.base_find(db_name, 
                              data,
                              count = True)
        
    def update_log(self, _id, used = 0, db_name = 'log'):
        self.update(db_name, {'_id' : _id}, 
                    {"$set" :{"notifier" : True}})

    def delete_log(self, data, db_name = 'log'):
        return self.base_delete(db_name, data)
