from monga.common.utils import current_timestamp

class Share(object):

    def insert_shared(self, from_user, to_user, link_user, permission,
                      file_path, shared_path, is_dir = False, confirm = False, 
                      db_name = 'shared'):
        data = {
            #from
            'from_user_id'     : from_user['user_id'],
            'from_user_name'   : from_user['user_name'],
            'from_tenant_id'   : from_user['tenant_id'],
            'from_tenant_name' : from_user['tenant_name'],
            'from_domain_id'   : from_user['domain_id'],
            'from_domain_name' : from_user['domain_name'],
            #to
            'to_user_id'       : to_user['user_id'],
            'to_user_name'     : to_user['user_name'],
            'to_tenant_id'     : to_user['tenant_id'],
            'to_tenant_name'   : to_user['tenant_name'],
            'to_domain_id'     : to_user['domain_id'],
            'to_domain_name'   : to_user['domain_name'],
            #link
            'link_user_id'     : link_user['link_user_id'],
            'link_user_name'   : link_user['link_user_name'],
            'link_tenant_id'   : link_user['link_tenant_id'],
            'link_tenant_name' : link_user['link_tenant_name'],
            'link_domain_id'   : link_user['link_domain_id'],
            'link_domain_name' : link_user['link_domain_name'],
            'link_path'        : link_user['link_path'],
            #attrs
            'permission'       : {'write' : permission['write']},
            'is_dir'           : is_dir,
            'file_path'        : file_path,
            'shared_path'      : shared_path,
            'updated_time'     : current_timestamp(),
            'confirm'          : confirm
        }
        return self.base_insert(db_name, data)

    def find_shared(self, body, action = 'to', path = None, shared_path = None,
                    once = False, match = False, count = False, confirm = True, 
                    db_name = 'shared'):
        data = {
            action + '_user_id'     : body['user_id'],
            action + '_user_name'   : body['user_name'],
            action + '_tenant_id'   : body['tenant_id'],
            action + '_tenant_name' : body['tenant_name'],
            action + '_domain_id'   : body['domain_id'],
            action + '_domain_name' : body['domain_name'],
        }
        if path :
            data['file_path'] = path
        if shared_path :
            data['shared_path'] = shared_path
        if count and not match:
            return self.base_find(db_name, data), \
                self.base_find(db_name, data, count = count)
        elif count and match :
            return self.match_find(db_name, data, once = once), \
                self.base_find(db_name, data, count = count)       
        elif once and not match:
            return self.base_findone(db_name, data)
        elif match:
            return self.match_find(db_name, data, once = once)
        else :
            return self.base_find(db_name, data)

    def find_link_shared(self, data, db_name = 'shared'):
        data = {
            'link_user_id'     : data['link_user_id'],
            'link_user_name'   : data['link_user_name'],
            'link_tenant_id'   : data['link_tenant_id'],
            'link_tenant_name' : data['link_tenant_name'],
            'link_domain_id'   : data['link_domain_id'],
            'link_domain_name' : data['link_domain_name'],
            'link_path'        : data['link_path']
        }
        return self.base_find(db_name, data)

    def check_shared_path(self, user_info, path, confirm = True, 
                          db_name = 'shared'):
        data = {
            'to_user_id'       : user_info.get('user_id', None),
            'to_user_name'     : user_info.get('user_name', None),
            'to_tenant_id'     : user_info.get('tenant_id', None),
            'to_tenant_name'   : user_info.get('tenant_name', None),
            'to_domain_id'     : user_info.get('domain_id', None),
            'to_domain_name'   : user_info.get('domain_name', None),
            'is_dir'           : user_info.get('is_dir', False),
            'shared_path'      : path,
        }
        return self.base_findone(db_name, data)

    def find_mathched_shared_path(self, user_info, path, confirm = True,
                                  db_name = 'shared'):
        data = {
                   'to_user_id'     : user_info.get('user_id', None),
                   'to_user_name'   : user_info.get('user_name', None),
                   'to_tenant_id'   : user_info.get('tenant_id', None),
                   'to_tenant_name' : user_info.get('tenant_name', None),
                   'to_domain_id'   : user_info.get('domain_id', None),
                   'to_domain_name' : user_info.get('domain_name', None),
                   'shared_path'    : path,
        }
        return self.base_findone(db_name, data)

    def delete_shared(self, _id, db_name = 'shared'):
        return self.direct_delete(db_name, _id)

