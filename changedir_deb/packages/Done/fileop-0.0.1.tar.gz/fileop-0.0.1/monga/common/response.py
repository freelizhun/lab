import json
from swift.common.swob import Response
from monga.common.utils import json_dump

from swift.common.swob import HTTPOk, HTTPCreated, HTTPNoContent, \
    HTTPBadRequest, HTTPNotFound, HTTPForbidden, HTTPUnauthorized, \
    HTTPPreconditionFailed, HTTPServerError, HTTPInternalServerError, \
    HTTPServiceUnavailable, HTTPLengthRequired

"""
Successful Messages
"""
def ok(content = None):
    if content :
        return HTTPOk(body = content, content_type='application/json')
    else :
        return HTTPOk()

def created(content = None):
    if content :
        return HTTPCreated(body = content, content_type='application/json')
    else :
        return HTTPCreated()

def no_content():
    return HTTPNoContent()

"""
Fail Messages
"""
def bad_request(error = ''):
    return HTTPBadRequest(
        app_iter = gen_body(content = error),
        content_type = 'application/json')
        
def forbidden(error = ''):
    return HTTPForbidden(
        app_iter = gen_body(content = error),
        content_type = 'application/json')

def service_unavaliable(error = ''):
    return HTTPServiceUnavailable(
        app_iter = gen_body(content = error),
        content_type = 'application/json')

def internal_error(error = ''):
    return HTTPInternalServerError(
        app_iter = gen_body(content = error),
        content_type = 'application/json')
        
def not_found(error = ''):
    return HTTPNotFound(
        app_iter = gen_body(content = error),
        content_type = 'application/json')

def unauthorized(error = ''):
    return HTTPUnauthorized(
        app_iter = gen_body(content = error),
        content_type = 'application/json')

def storageerror(error = ''):
    return HTTPBadRequest(
        app_iter = gen_body(content = error),
        content_type = 'application/json')
    
def uploadtimeout(error = ''):
    return HTTPBadRequest(
        app_iter = gen_body(content = error),
        content_type = 'application/json')

def filebusyerror(error = ''):
    return HTTPBadRequest(
        app_iter = gen_body(content = error),
        content_type = 'application/json')
        
def lengtherror(error = ''):
    return HTTPLengthRequired(
        app_iter = gen_body(content = 'Content length required'),
        content_type = 'application/json')

"""
Send Fail Result
"""
def gen_body(content='', serv_name='monga'):
    data={}
    data['service']=serv_name
    data['details']=str(content)
    return [json_dump({'fault':data})]
