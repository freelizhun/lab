import httplib2
import json
import urlparse
import urllib
import logging
from monga.common.exception import *
log = logging.getLogger(__name__)

class KeystoneClient():

    def __init__(self, path, token, admin = 'admin', pwd = 'admin', 
                 tenant = 'admin', domain = 'Default'):
        self.admin_name = admin
        self.admin_pwd = pwd
        self.admin_tenant = tenant
        self.domain_name = domain
        self.token = ''
        self.path = path
        self.headers = {'X-Auth-Token' : token}

    def verify_token(self, verify_token, admin_token = None):
        if admin_token :
            self.token = admin_token
        _url = self.path + 'auth/tokens'
        headers = {'X-Auth-Token' : self.token, 
                   'X-Subject-Token' : verify_token}
        return self._do_request(_url, headers = headers)
        
    def get_tenant(self, tenant_id, token = None):
        if token :
            self.token = token
        _url = self.path + 'projects/' + tenant_id
        headers = {'X-Auth-Token' : self.token}
        return self._do_request(_url, headers = headers)['project']

    def get_domain(self, domain_id, token = None):
        if token :
            self.token = token
        _url = self.path + 'domains/' + domain_id
        headers = {'X-Auth-Token' : self.token}
        return self._do_request(_url, headers = headers)['domain']
        
    def get_tenant_by_name(self, tenant_name, token = None):
        if token :
            self.token = token
        _url = self.path + 'projects?name=' + urllib.quote(tenant_name)
        headers = {'X-Auth-Token' : self.token}
        return self._do_request(_url, headers = headers)['projects']
        
    def get_user(self, user_name, token = None):
        if token :
            self.token = token
        _url = self.path + 'users?name=' + urllib.quote(user_name)
        headers = {'X-Auth-Token' : self.token}
        return self._do_request(_url, headers = headers)['users']
        
    def get_user_tenants(self, user_id, token = None):
        if token :
            self.token = token
        _url = self.path + 'users/' + user_id+ '/projects'
        headers = {'X-Auth-Token' : self.token}
        return self._do_request(_url, headers = headers)['projects']
        
    def get_tenant_users(self, tenant_id, token = None):
        if token :
            self.token = token
        _path = self.path.replace('v3','v2.0',1)
        _url = _path + 'tenants/' + tenant_id+ '/users'
        headers = {'X-Auth-Token' : self.token}
        return self._do_request(_url, headers = headers)['users']
        
    def get_admin_token(self) :
        _url = self.path + 'auth/tokens'
        auth_body = {
            "auth" : {
                "identity" : {
                    "methods" : ["password"],
                    "password" : {
                        "user" : {
                            "domain" : {
                                "name" : self.domain_name
                            },
                            "name" : self.admin_name,
                            "password" : self.admin_pwd
                        }
                    }
                },
                "scope" : {
                    "project" : {
                        "domain" : {
                            "name" : self.domain_name
                        },
                    "name" : self.admin_name}
                }
            }
        }
        headers = {'Content-Type' : 'application/json'}
        return self._do_request(_url, 
                                method = 'POST', 
                                headers = headers,
                                body = json.dumps(auth_body),
                                token = True)
        
    def _do_request(self, url, method = 'GET', headers = None, body = None, 
                    token = False):
        headers = headers or {}
        conn = httplib2.Http()
        conn.force_exception_to_status_code = True
        headers['User-Agent'] = 'monga-client'
        resp, resp_body = conn.request(url, method, headers = headers, 
                                       body = body)
        if resp.status >= 200 and resp.status < 300:
            if token :
                return resp.get('x-subject-token')
            else :
                return json.loads(resp_body)
        elif resp.status == 401 :
            self.token = self.get_admin_token()
            raise UnauthorizedError(resp_body)
        elif resp.status > 400 and resp.status < 500 :
            raise BadRequestError(resp_body)
        else :
            raise InternalServerError(resp_body)
