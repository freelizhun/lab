import json, time

def json_dump( _obj ):
    return json.dumps(_obj, 
                      sort_keys = True, 
                      indent = 4, 
                      ensure_ascii=False)
                      
def current_timestamp():
    return int(round(time.time()*1000))
    
def split_path(path):
    try:
        _path = path.split('/')
        try:
            _path.remove('')
        except ValueError:
            pass
        return _path
    except Exception :
        return []
