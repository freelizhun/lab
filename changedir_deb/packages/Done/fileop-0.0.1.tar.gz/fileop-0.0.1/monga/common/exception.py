#import logging
from decorator import decorator
from pymongo.errors import *
from monga.common import response as RESP
import sys

class BadRequestError(Exception):
    def __init__(self, value = ''):
        self.value = value
    def __str__(self):
        return repr(self.value)
        
class NotFoundError(Exception):
    def __init__(self, value = ''):
        self.value = value
    def __str__(self):
        return repr(self.value)
        
class ExceedQuotaError(Exception):
    def __init__(self, value = ''):
        self.value = value
    def __str__(self):
        return repr(self.value)
        
class FileNotFoundError(NotFoundError):
    def __init__(self, path = None):
        self.value = 'File Not Found At : {0}'.format(path)

class ForbiddenError(Exception):
    def __init__(self, value = ''):
        self.value = value
    def __str__(self):
        return repr(self.value)

class FileExistError(ForbiddenError):
    def __init__(self, path =None):
        self.value = 'File E xist At : {0}'.format(path)

class InternalServerError(Exception):
    def __init__(self, value = ''):
        self.value = value
    def __str__(self):
        return repr(self.value)

class InvalidParameter(InternalServerError):
    def __init__(self, fn = ''):
        self.value = 'Invalid Input for {0}'.format(fn)

class StorageError(Exception):
    def __init__(self, value = ''):
        self.value = value
    def __str__(self):
        return repr(self.value)

class UploadTimeOut(Exception):
    def __init__(self, value = ''):
        self.value = value
    def __str__(self):
        return repr(self.value)

class FileBusyError(Exception):
    def __init__(self, value = ''):
        self.value = value
    def __str__(self):
        return repr(self.value)

class NotImplementError(Exception):
    def __init__(self, value = ''):
        self.value = value
    def __str__(self):
        return repr(self.value)

class UnauthorizedError(Exception):
    def __init__(self, value = 'Unauthorized'):
        self.value = value
    def __str__(self):
        return repr(self.value)
    
class LengthRequiredError(Exception):
    def __init__(self, value = 'Require file path'):
        self.value = value
    def __str__(self):
        return repr(self.value)

def handle_exceptions():
    def wrapper(func, *args, **kwargs):
        try:
            return func(*args, **kwargs)
        except ValueError as e :
            return RESP.bad_request(e)
        except (BadRequestError) as e:
            return RESP.bad_request(e.value)
        except (NotFoundError, FileNotFoundError, NotImplementError) as e:
            return RESP.not_found(e.value)
        except (ForbiddenError, ExceedQuotaError, FileExistError) as e:
            return RESP.forbidden(e.value)
        except InternalServerError as e:
            return RESP.internal_error(e.value)
        except UnauthorizedError as e:
            return RESP.unauthorized(e.value)
        except LengthRequiredError as e:
            return RESP.lengtherror(e.value)
        except StorageError as e:
            return RESP.storageerror(e.value)
        except UploadTimeOut as e:
            return RESP.uploadtimeout(e.value)
        except FileBusyError as e:
            return RESP.filebusyerror('File is busy %s'%e.value)
        except InvalidId as e:
            return RESP.bad_request('Invaild ID')
        except Exception as e:
            return RESP.internal_error(e)
    return decorator(wrapper)
