import ldap

class AuthDriver():

    def __init__ (self, extra):
        self.addr = extra['auth_url']
        self.type = extra['auth_type']
        self.full_name = extra.get('full_name', '').encode('utf-8')
        if self.type == 'ad':
            self.auth = self._auth_ad
        elif self.type == 'ldap':
            self.auth = self._auth_ldap
        else:
            raise Exception()
            
    def auth(self):
        raise Exception('NotImplement')
        
    def _auth_ad(self, username, password, domain):
        domain = domain.encode('utf-8')
        username = username.encode('utf-8')
        _user = ('%s@'+domain)  % username
        _pwd  = password
        try:
            ldap_client = ldap.initialize(self.addr)
            ldap_client.set_option(ldap.OPT_REFERRALS, 0)
            res = ldap_client.simple_bind_s(_user, _pwd)
        except ldap.INVALID_CREDENTIALS:
            ldap_client.unbind()
            raise ldap.INVALID_CREDENTIALS
        except ldap.SERVER_DOWN:
            raise ldap.SERVER_DOWN
        return True
 
    def _auth_ldap(self, username, password, domain):
        try:
            ldap_client = ldap.initialize(self.addr)
            ldap_client.simple_bind_s(self.full_name, password)
        except IndexError:
            raise ldap.INVALID_CREDENTIALS
        except ldap.INVALID_CREDENTIALS:
            ldap_client.unbind()
            raise ldap.INVALID_CREDENTIALS
        except ldap.SERVER_DOWN:
            raise ldap.SERVER_DOWN
        return True
   
