from latte.migrate.migrate_api import MigrateAPI

_type = 'ldap'

db_addr = 'mysql://root:joe@127.0.0.1/keystone'
total_quota = None
user_quota = 5368709120

if _type == 'ad':
    addr = 'ldap://10.90.0.51'
    domain = 'cs.promise.com.tw'
    user = 'Aisha.Bhari@cs.promise.com.tw'
    pwd = 'Password1'
else :
    addr = 'ldap://10.90.0.145'
    domain = 'example.com'
    user = 'cn=admin, dc=example, dc=com'
    pwd = 'secret'

_m = MigrateAPI(ad_addr     = addr, 
                domain      = domain, 
                db_path     = db_addr, 
                user        = user, 
                pwd         = pwd, 
                backend     = _type, 
                cn          = 'uid')
                 
#_m.list_ous()
#_m.create_domain_and_ous()
#_m.list_user_under_ou('ou=\xe9\x9a\xa8\xe4\xbe\xbf,ou=\xe7\xb8\xbd\xe5\x8b\x99,dc=example,dc=com')
#_m.insert_user_db({'ou': ['\xe7\xb8\xbd\xe5\x8b\x99'], 'cn': ['\xe9\x99\xb3 \xe5\xb0\x8f\xe6\x98\x8e'], 'name': 'uid=\xe9\x99\xb3 \xe5\xb0\x8f\xe6\x98\x8e,ou=\xe7\xb8\xbd\xe5\x8b\x99,dc=example,dc=com', 'dc': ['example', 'com']}, 1)
