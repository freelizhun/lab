from keystone import config
from keystone.identity.backends.sql import Identity
from keystone.common import controller
from keystone.exception import Conflict, ProjectNotFound
import uuid

CONF = config.CONF

class KeystoneDBDriver(controller.V3Controller):
    
    def __init__(self, db_path, _type, _url):
        CONF.sql.connection = db_path
        self.identity_api = Identity()
        self.roles = {}
        self.domains = {}
        self._type = _type
        self._url  = _url
        
    def _assign_unique_id(self, ref):
        ref = ref.copy()
        ref['id'] = uuid.uuid4().hex
        return ref
        
    def update_domain(self, ref, quota = None, allocated = None):
        query = {}
        if quota :
            query['quota'] = quota
        if allocated :
            query['allocated'] = allocated
        return self.identity_api.update_domain(ref['id'], query)
        
    def update_user(self, ref, full_name = None):
        query = {}
        if full_name :
            query['full_name'] = full_name.decode('utf-8')
        return self.identity_api.update_user(ref['id'], query)
        
    def create_domain(self, name):
        try:
            ref = self._assign_unique_id(self._normalize_dict({'name':name}))
            ref = self.identity_api.create_domain(ref['id'], ref)
        except Conflict:
            ref = self.identity_api.get_domain_by_name(name)
        self.domains[name] = ref['id']
        return ref
        
    def check_domain_id(self, domain):
        if not self.domains.get(domain, None):
            try:
                ref = self.identity_api.get_domain_by_name(domain)
                self.domains[domain] = ref['id']
            except Exception as err:
                raise Exception(err)
            
    def create_ou(self, name, domain):
    
        #Get domain_id before create ou
        self.check_domain_id(domain)
        
        try:
            ref = self._assign_unique_id(
                      self._normalize_dict(
                          {'name'        : name, 
                           'domain_id'   : self.domains[domain],
                           'description' : name,
                           'type'        : self._type.upper() }))
            ref = self.identity_api.create_group(ref['id'], ref)
        except Conflict:
            refs = self.identity_api.list_groups()
            for _ref in refs:
                if _ref['name'].encode('utf-8') == name :
                    ref = _ref
                    break
        return ref
        
    def list_groups_for_user(self, user_id):
        return self.identity_api.list_groups_for_user(user_id)
        
    def remove_user_from_group(self, user_id, group_id):
        return self.identity_api.remove_user_from_group(user_id, group_id)
        
    def find_ou(self, name):
        refs = self.identity_api.list_groups()
        ref = None
        for _ref in refs:
            if _ref['name'].encode('utf-8') == name :
                ref = _ref
                break
        return ref
        
    def create_project(self, name, domain, quota = 5368709120):
    
        #Get domain_id before create ou
        self.check_domain_id(domain)
        self.get_roles()
    
        _new = True
        try:
            ref = self._assign_unique_id(
                      self._normalize_dict(
                          {'name'        : name, 
                           'enabled'     : 1,
                           'quota'       : quota,
                           'domain_id'   : self.domains[domain],
                           'description' : name}))
            ref = self.identity_api.create_project(ref['id'], ref)
        except Conflict:
            _new = False
            ref = self.identity_api.get_project_by_name(
                      name, self.domains[domain])
        return ref, _new
        
    def add_user_to_group(self, user_id, ou):
    
        #get ou from db
        if ou == '':
            return
        try:
            self.identity_api.add_user_to_group(user_id, self.find_ou(ou)['id'])
        except Conflict:
            pass
        
    def create_grant(self, role, domain, user_id = None, 
                     tenant_id = None, ou = None, under_ou = False):
                     
        #Get domain_id before create ou
        self.check_domain_id(domain)
        self.get_roles()
                     
        domain_id = self.domains[domain]
        if ou :
            group_id = self.find_ou(ou)['id']
        else:
            group_id = None
            
        if under_ou:
            try:
                tenant_id = self.identity_api.get_project_by_name(
                                ou, self.domains[domain])['id']
            except ProjectNotFound:
                pass
                                        
        try:
            return self.identity_api.create_grant(
                       self.roles[role]['id'], user_id, group_id,
                       domain_id, tenant_id)
        except Conflict:
            return 
    
    def create_user(self, name, domain, tenant_id, full_name = '', enabled = 0,
                    admin = False, password = 'password'):
    
        #Get domain_id before create ou
        self.check_domain_id(domain)
    
        try:
            _dict = {
                'name'      : name,
                'domain_id' : self.domains[domain],
                'password'  : password,
                'enabled'   : enabled,
                'tenantId'  : tenant_id,
                
                'default_project_id' : tenant_id,
            }
            if not admin :
                _dict['full_name'] = full_name
                _dict['email'] = name + '@' + domain
                _dict['auth_type'] = self._type
                _dict['auth_url'] = self._url
        
            ref = self._assign_unique_id(self._normalize_dict(_dict))
            ref = self.identity_api.create_user(ref['id'], ref)
        except Conflict:
            ref = self.identity_api.get_user_by_name(name, self.domains[domain])
            if not admin:
                self.update_user(ref, full_name)
        return ref
            
    def get_roles(self, admin=None, member=None):
        _roles = self.identity_api.list_roles()
        for _r in _roles :
            if not member and _r['name'] == 'member':
                member = _r
            if not admin and _r['name'] == 'admin':
                admin = _r
        if not admin:
            ref = self._assign_unique_id(
                      self._normalize_dict({'name':'admin'}))
            ref = self.identity_api.create_role(ref['id'], ref)
            return self.get_roles(admin)
        if not member:
            ref = self._assign_unique_id(self._normalize_dict(
                                             {'name':'member'}))
            ref = self.identity_api.create_role(ref['id'], ref)
            return self.get_roles(admin, member)
        self.roles = {'admin' : admin, 'member': member}
