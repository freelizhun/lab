import ldap, sys
from ldap.dn import str2dn
import uuid
from latte.migrate.migrate_db import KeystoneDBDriver as KsDB
import datetime
from urllib import unquote
import json

class MigrateAPI(object):
    
    def __init__(self, ad_addr, domain, db_path, user = None, pwd = None, 
                 backend = 'ad', cn = 'cn'):
        self.user    = user
        self.pwd     = pwd
        self.addr    = ad_addr
        self.dn      = self.split_dn(domain)
        self.backend = backend
        self.db_path = db_path
        self.db      = KsDB(self.db_path, self.backend, self.addr)
        self.cn      = cn
        
    def split_dn(self, dn):
        return ','.join(["dc=%s" % (k) for k in dn.split('.')])
        
    def get_domain_entity(self, conn):
        try:
            res = conn.search_s(self.dn, 0, '(objectClass=*)', None)
            return str2dn(res[0][0])
        except ldap.LDAPError as e:
            raise Exception(e)
    
    def get_detail_infos(self, _data, keep_cn = True):
        cn = []
        ou = []
        dc = []
        #gen user_login string
        user_string = []
        for _d in _data:
            if _d[0][0].lower() == self.cn :
                cn.append(unquote(_d[0][1]))
                user_string.append(self.cn + '='+_d[0][1])
            elif _d[0][0].lower() == 'ou' :
                ou.append(unquote(_d[0][1]))
                user_string.append('ou='+_d[0][1])
            elif _d[0][0].lower() == 'dc' :
                dc.append(unquote(_d[0][1]))
                user_string.append('dc='+_d[0][1])
        result = {'cn'   : cn,
                  'ou'   : ou,
                  'dc'   : dc,
                  'name' : unquote(','.join(user_string))}
        if not keep_cn :
            del result['cn']
        return result
               
    def get_child_users(self, data, conn):
        if self.backend == 'ad':
            _rule = '(|(objectClass=User))'
        else:
            _rule = '(|(objectClass=inetOrgPerson))'
        try:
            attrs = ['sAMAccountName']
            res= conn.search_s(data, 1, _rule, attrs)
            return res
        except ldap.LDAPError as e:
            raise Exception(e)
            
    def get_child_ous(self, data, conn):
        if self.backend == 'ad':
            _rule = '(|(objectClass=organizationalUnit))'
        else:
            _rule = '(|(objectClass=organizationalUnit))'
        try:
            attrs = ['sAMAccountName']
            res= conn.search_s(data, 1, _rule, attrs)
            return res
        except ldap.LDAPError as e:
            raise Exception(e)
            
    def get_conn(self):
        conn = ldap.initialize(self.addr)
        conn.set_option(ldap.OPT_REFERRALS, 0)
        if self.backend == 'ad' :
            conn.bind_s(self.user, self.pwd)
        else:
            conn.simple_bind_s(self.user, self.pwd)
        return conn
        
    def list_user_under_ou(self, ou):
        users = []
        conn  = self.get_conn()
        res = self.get_child_users(ou, conn)
        for _data, _attr in res:
            if _data == None:
                continue
            else :
                _data_parts = str2dn(_data)
                _info = self.get_detail_infos(_data_parts, True)
                if _attr.has_key('sAMAccountName'):
                    _info['cn'] = _attr['sAMAccountName'][0]
                users.append(_info.copy())
        #print json.dumps(users, indent = 4, ensure_ascii=False)
        return users
        
    def insert_user_db(self, _user, quota = 5368709120, enabled = 0):
        def reformat(data):
            data['cn'] = '.'.join(data['cn'])
            data['ou'] = '.'.join(data['ou'])
            data['dc'] = '.'.join(data['dc'])
            return data
            
        def find_ad_group(_groups): 
            for _g in _groups :
                if _g.get('type'):
                    if _g['type'] == self.backend.upper():
                        return _g
            return None
           
        data = reformat(_user.copy())
        ref_project, _new = \
            self.db.create_project(data['cn'], data['dc'], quota)
        ref_user = self.db.create_user(data['cn'], data['dc'], 
                                       ref_project['id'], data['name'], enabled)
        if _new :
            #Add admin role to user's own project
            self.db.create_grant(role = 'admin', 
                                 domain = data['dc'], 
                                 user_id = ref_user['id'], 
                                 tenant_id = ref_project['id'])
            #Add member role into domain
            self.db.create_grant(role = 'member', 
                                 domain = data['dc'], 
                                 user_id = ref_user['id'])
            #Add user into OU
            self.db.add_user_to_group(user_id = ref_user['id'], 
                                      ou = data['ou'])
            #Grant role of user into OU
            self.db.create_grant(role = 'member', 
                                 domain = data['dc'], 
                                 user_id = ref_user['id'], 
                                 ou = data['ou'],
                                 under_ou=True)
        else :
            #Find user's previous OU
            _groups = self.db.list_groups_for_user(ref_user['id'])
            _group = find_ad_group(_groups)
            if _group :
                if _group['name'].encode('utf-8') != data['ou'] :
                    #print _group['name'] ,data['ou']
                    old_ou_ref = self.db.find_ou(_group['name'])
                    self.db.remove_user_from_group(ref_user['id'],
                                                   old_ou_ref['id'])
                else :
                    pass
            #Add user into OU
            self.db.add_user_to_group(user_id = ref_user['id'], 
                                      ou = data['ou'])
            #Grant role of user into OU
            self.db.create_grant(role = 'member', 
                                 domain = data['dc'], 
                                 user_id = ref_user['id'], 
                                 ou = data['ou'],
                                 under_ou=True)
     
    def create_domain_and_ous(self):
        conn  = self.get_conn()
        _domain = self.get_domain_entity(conn)
        _dict = self.get_detail_infos(_domain)
        ref = self.db.create_domain('.'.join(_dict['dc']))
        self.db.get_roles()
        self._create_domain_and_ous(self.dn, conn)
        return ref
        
    def _create_domain_and_ous(self, data, conn):
        res = self.get_child_ous(data, conn)
        for _data, _attr in res:
            if _data == None:
                continue
            else :
                _data_parts = str2dn(_data)
                _info = self.get_detail_infos(_data_parts, False)
                self.db.create_ou('.'.join(_info['ou']), 
                                  '.'.join(_info['dc']))
                self._create_domain_and_ous(_data, conn)
            
    def list_ous(self):
        conn  = self.get_conn()
        ou_map = self.list_ou_loop(self.dn, conn)
        #print json.dumps(ou_map, indent = 4, ensure_ascii=False)
        return ou_map
             
    def list_ou_loop(self, data, conn):
        ou_map = []
        res = self.get_child_ous(data, conn)
        for _data, _attr in res:
            if _data == None:
                continue
            else :
                _data_parts = str2dn(_data)
                _info = self.get_detail_infos(_data_parts, False)
                if _attr.has_key('sAMAccountName'):
                    _info['cn'] = _attr['sAMAccountName'][0]
                _ou_map = _info.copy()
                _ou_map['child'] = self.list_ou_loop(_data, conn)
                ou_map.append(_ou_map)
        return ou_map
