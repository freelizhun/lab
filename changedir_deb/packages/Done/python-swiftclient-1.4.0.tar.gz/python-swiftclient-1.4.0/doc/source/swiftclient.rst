.. _swiftclient_package:

swiftclient
==============

.. automodule:: swiftclient
    :members:
    :undoc-members:
    :show-inheritance:

swiftclient.client
==================

.. automodule:: swiftclient.client
    :members:
    :undoc-members:
    :show-inheritance:
