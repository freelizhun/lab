pbr - Python Build Reasonableness
=================================

A library for managing setuptools packaging needs in a consistent manner.

PBR is not a library about beer.

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
